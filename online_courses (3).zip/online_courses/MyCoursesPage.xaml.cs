using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Controls;

namespace online_courses
{
    public partial class MyCoursesPage : Page, IPageRefresh
    {
        private user _currentUser;

        // Класс для представления курса с дополнительной информацией
        private class CourseWithRating
        {
            public course_grades CourseGrade { get; set; }
            public cours Course { get; set; }
            public double Rating { get; set; }
            public string RatingText { get; set; }
            public double Progress { get; set; }
            public string ProgressText { get; set; }
            public int Grade { get; set; }
            public string GradeText { get; set; }
        }

        public MyCoursesPage(user user)
        {
            InitializeComponent();
            _currentUser = user;
            
            // Обновляем контекст для получения свежих данных
            Entities.ResetContext();
            
            LoadCourses();
        }

        public void RefreshData()
        {
            // Обновляем контекст для получения свежих данных
            Entities.ResetContext();
            LoadCourses();
        }

        private void LoadCourses()
        {
            try
            {
                // Используем новый контекст для получения свежих данных
                using (var context = new Entities())
                {
                    // Получаем курсы, на которые записан студент
                    var enrolledCourses = context.course_grades
                        .Where(cg => cg.users_ID == _currentUser.users_ID)
                        .ToList();

                    var coursesWithRatings = new List<CourseWithRating>();

                    foreach (var courseGrade in enrolledCourses)
                    {
                        // Получаем информацию о курсе
                        var course = context.courses.FirstOrDefault(c => c.course_ID == courseGrade.course_ID);
                        if (course == null) continue;

                        System.Diagnostics.Debug.WriteLine($"[MyCoursesPage] Обработка курса: {course.course_name}, ID={course.course_ID}");

                        // Создаем локальную копию курса с загруженными навигационными свойствами
                        var courseWithDetails = new cours
                        {
                            course_ID = course.course_ID,
                            course_name = course.course_name,
                            course_description = course.course_description,
                            course_author = course.course_author,
                            course_category = course.course_category
                        };
                        
                        // Загружаем автора курса
                        if (course.course_author.HasValue)
                        {
                            var author = context.users.FirstOrDefault(u => u.users_ID == course.course_author);
                            if (author != null)
                            {
                                // Создаем копию для предотвращения проблем с контекстом
                                courseWithDetails.user = new user
                                {
                                    users_ID = author.users_ID,
                                    users_login = author.users_login
                                };
                            }
                        }
                        
                        // Загружаем категорию курса
                        if (course.course_category.HasValue)
                        {
                            var cat = context.categories.FirstOrDefault(c => c.category_ID == course.course_category);
                            if (cat != null)
                            {
                                // Создаем копию для предотвращения проблем с контекстом
                                courseWithDetails.category = new category
                                {
                                    category_ID = cat.category_ID,
                                    category_name = cat.category_name
                                };
                            }
                        }

                        // Вычисляем рейтинг на основе отзывов для каждого курса
                        string ratingText = "Нет оценок";
                        double rating = 0;

                        var reviews = context.course_reviews
                            .Where(r => r.course_ID == courseGrade.course_ID);

                        if (reviews.Any())
                        {
                            rating = reviews.Average(r => r.rating);
                            ratingText = rating.ToString("0.0");
                        }

                        // Вычисляем прогресс курса с использованием CourseGradeHelper
                        double progress = 0;
                        string progressText = "0%";
                        
                        CourseGradeHelper gradeHelper = new CourseGradeHelper(context);
                        var progressInfo = gradeHelper.CalculateCourseProgress(course.course_ID, _currentUser.users_ID);
                        
                        progress = progressInfo.ProgressPercentage;
                        progressText = $"{progress:F1}% ({progressInfo.CompletedModules}/{progressInfo.TotalModules})";
                        
                        System.Diagnostics.Debug.WriteLine($"[MyCoursesPage] Курс: {course.course_name}, Прогресс: {progressText}");

                        // Получаем оценку курса
                        int grade = (int)courseGrade.grade;
                        string gradeText = grade > 0 ? grade.ToString() : "Нет оценки";

                        var courseWithRating = new CourseWithRating
                        {
                            CourseGrade = courseGrade,
                            Course = courseWithDetails,
                            Rating = rating,
                            RatingText = ratingText,
                            Progress = progress,
                            ProgressText = progressText,
                            Grade = grade,
                            GradeText = gradeText
                        };

                        System.Diagnostics.Debug.WriteLine($"[MyCoursesPage] Добавляем курс в список: {course.course_name}, " +
                            $"Прогресс={progress:F1}%, Оценка={grade}");
                        
                        coursesWithRatings.Add(courseWithRating);
                    }

                    myCoursesListView.ItemsSource = coursesWithRatings;

                    // Показываем информацию, если студент не записан ни на один курс
                    if (enrolledCourses.Count == 0)
                    {
                        MessageBox.Show("Вы еще не записаны ни на один курс. Перейдите в раздел 'Курсы', чтобы найти интересующие вас курсы.");
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при загрузке курсов: {ex.Message}\n\nStackTrace: {ex.StackTrace}");
            }
        }

        private void ContinueCourseButton_Click(object sender, RoutedEventArgs e)
        {
            if (sender is Button button && button.Tag is int courseId)
            {
                try
                {
                    // Загружаем курс и полностью инициализируем его до закрытия контекста
                    cours selectedCourse = null;
                    
                    using (var context = new Entities())
                    {
                        selectedCourse = context.courses.FirstOrDefault(c => c.course_ID == courseId);
                        
                        if (selectedCourse != null)
                        {
                            // Принудительно загружаем необходимые связанные данные
                            var modules = context.modules
                                .Where(m => m.course_ID == selectedCourse.course_ID)
                                .ToList();
                                
                            // Предзагружаем тесты для модулей
                            foreach (var module in modules)
                            {
                                var tests = context.tests
                                    .Where(t => t.module_ID == module.module_ID)
                                    .ToList();
                            }
                            
                            // Предзагружаем экзамены для курса
                            var exams = context.exams
                                .Where(exam => exam.course_ID == selectedCourse.course_ID)
                                .ToList();
                        }
                    }
                    
                    // Сбрасываем контекст
                    Entities.ResetContext();
                    
                    // Только после полной загрузки и закрытия контекста выполняем навигацию
                    if (selectedCourse != null)
                    {
                        // Создаем полностью независимую копию объекта курса
                        var courseToNavigate = new cours
                        {
                            course_ID = selectedCourse.course_ID,
                            course_name = selectedCourse.course_name,
                            course_description = selectedCourse.course_description,
                            course_author = selectedCourse.course_author,
                            course_category = selectedCourse.course_category
                        };
                        
                        // Создаем новую страницу с копией курса
                        var contentPage = new CourseContentPage(_currentUser, courseToNavigate);
                        NavigationService.Navigate(contentPage);
                    }
                    else
                    {
                        MessageBox.Show("Курс не найден.");
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Ошибка при открытии курса: {ex.Message}\n\nStackTrace: {ex.StackTrace}");
                }
            }
        }
    }
} 