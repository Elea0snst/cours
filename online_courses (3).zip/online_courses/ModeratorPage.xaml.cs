using System;
using System.Windows;
using System.Windows.Controls;

namespace online_courses
{
    public partial class ModeratorPage : Window
    {
        private user _currentUser;

        public ModeratorPage(user user)
        {
            InitializeComponent();
            _currentUser = user;
            Title = $"Личный кабинет модератора: {_currentUser.users_login}";
            
            // По умолчанию показываем страницу с жалобами
            MainFrame.Navigate(new ModeratorComplaintsPage(_currentUser));
        }

        private void MainFrame_IsVisibleChanged(object sender, DependencyPropertyChangedEventArgs e)
        {
            if (MainFrame.Content is Page currentPage && currentPage is IPageRefresh pageWithRefresh)
            {
                pageWithRefresh.RefreshData();
            }
        }

        private void ComplaintsButton_Click(object sender, RoutedEventArgs e)
        {
            MainFrame.Navigate(new ModeratorComplaintsPage(_currentUser));
        }

        private void ProfileButton_Click(object sender, RoutedEventArgs e)
        {
            MainFrame.Navigate(new ProfilePage(_currentUser));
        }

        private void SupportButton_Click(object sender, RoutedEventArgs e)
        {
            MainFrame.Navigate(new SupportChatPage(_currentUser));
        }

        private void LogoutButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                LoginPage loginPage = new LoginPage();
                loginPage.Show();
                this.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при выходе из системы: {ex.Message}");
            }
        }
    }
} 