using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Data.Entity;
using System.Windows.Media;
using System.Data.SqlClient;
using System.Data;

namespace online_courses
{
    public partial class ExamEditPage : Page, IPageRefresh
    {
        private readonly user _currentUser;
        private readonly exam _exam;
        private ObservableCollection<QuestionItem> _questions = new ObservableCollection<QuestionItem>();

        public class QuestionItem
        {
            public int QuestionID { get; set; }
            public string Question { get; set; }
            public string Options { get; set; }
            public string CorrectAnswer { get; set; }
            public List<string> OptionsList { get; set; }
            public bool IsNew { get; set; }
            public int Index { get; set; }
            
            public override string ToString()
            {
                return Question;
            }
        }

        public ExamEditPage(user currentUser, exam exam)
        {
            InitializeComponent();
            _currentUser = currentUser ?? throw new ArgumentNullException(nameof(currentUser));
            
            // Create a detached copy of the exam to prevent Entity Framework tracking issues
            _exam = new exam
            {
                exam_ID = exam.exam_ID,
                course_ID = exam.course_ID,
                duration = exam.duration,
                attempts = exam.attempts,
                exam_date = exam.exam_date
            };
            
            questionsListView.ItemsSource = _questions;
            LoadData();
        }

        public void RefreshData()
        {
            LoadData();
        }

        private void LoadData()
        {
            try
            {
                using (var context = new Entities())
                {
                    // Получаем ID экзамена локально
                    int examId = _exam.exam_ID;
                    
                    // Загружаем данные экзамена с помощью SQL запроса
                    var examData = context.Database.SqlQuery<exam>(
                        "SELECT * FROM exams WHERE exam_ID = @p0", 
                        examId).FirstOrDefault();

                    if (examData != null)
                    {
                        // Заполняем поля формы
                        durationTextBox.Text = examData.duration.ToString();
                        attemptsTextBox.Text = examData.attempts.ToString();
                        
                        // Загружаем тесты для экзамена по специальной метке в вопросе
                        // Формат: "EX_{examId}_: вопрос..." - метка в начале текста вопроса
                        var examQuestions = context.Database.SqlQuery<test>(
                            @"SELECT * FROM tests 
                            WHERE module_ID IS NULL 
                            AND question LIKE 'EX_" + examId + "_%'").ToList();
                        
                        // Если не нашли вопросы с нашей меткой, ищем через таблицу exam_results (обратная совместимость)
                        if (examQuestions.Count == 0)
                        {
                            // Получаем все тесты, связанные с попытками сдачи этого экзамена
                            var testIds = context.Database.SqlQuery<int>(
                                @"SELECT DISTINCT t.test_ID 
                                FROM tests t 
                                JOIN test_results tr ON t.test_ID = tr.test_ID
                                JOIN exam_results er ON tr.result_date = er.result_date AND tr.users_ID = er.users_ID
                                WHERE er.exam_ID = @p0", 
                                examId).ToList();
                            
                            if (testIds.Count > 0)
                            {
                                // Загружаем тесты по найденным ID
                                foreach (var testId in testIds)
                                {
                                    var question = context.Database.SqlQuery<test>(
                                        "SELECT * FROM tests WHERE test_ID = @p0", 
                                        testId).FirstOrDefault();
                                    
                                    if (question != null)
                                    {
                                        examQuestions.Add(question);
                                    }
                                }
                            }
                        }
                        
                        System.Diagnostics.Debug.WriteLine($"[ExamEditPage] Загружено {examQuestions.Count} вопросов для экзамена ID={examId}");
                        
                        // Очищаем существующий список вопросов
                        _questions.Clear();
                        
                        foreach (var question in examQuestions)
                        {
                            // Удаляем метку экзамена из вопроса перед отображением
                            if (question.question.StartsWith($"EX_{examId}_:"))
                            {
                                question.question = question.question.Substring(($"EX_{examId}_:").Length).Trim();
                            }
                            
                            ProcessQuestionForDisplay(question);
                        }
                        
                        // Обновляем индексы всех вопросов
                        UpdateQuestionIndices();
                    }
                    else
                    {
                        MessageBox.Show($"Экзамен с ID={examId} не найден.");
                        System.Diagnostics.Debug.WriteLine($"[ExamEditPage] Экзамен с ID={examId} не найден в базе данных");
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при загрузке данных: {ex.Message}");
                System.Diagnostics.Debug.WriteLine($"[ExamEditPage] Ошибка при загрузке данных: {ex.Message}\n{ex.StackTrace}");
            }
        }

        // Вспомогательный метод для обработки вопроса
        private void ProcessQuestionForDisplay(test question)
        {
            // Пропускаем вопросы, у которых отсутствуют критически важные данные
            if (string.IsNullOrEmpty(question.question) || string.IsNullOrEmpty(question.answer_options))
            {
                System.Diagnostics.Debug.WriteLine($"[ExamEditPage] Пропущен некорректный вопрос ID={question.test_ID} (отсутствуют данные)");
                return;
            }
            
            // Проверяем, существует ли уже вопрос с таким ID
            bool exists = false;
            foreach (var q in _questions)
            {
                if (q.QuestionID == question.test_ID)
                {
                    exists = true;
                    break;
                }
            }
            
            if (!exists)
            {
                try
                {
                    var optionsList = question.answer_options?.Split(';').ToList() ?? new List<string>();
                    
                    // Проверка формата правильного ответа
                    int correctAnswerValue;
                    if (!int.TryParse(question.correct_answer, out correctAnswerValue) || 
                        correctAnswerValue < 1 || 
                        correctAnswerValue > optionsList.Count)
                    {
                        // Если некорректный формат ответа, устанавливаем первый вариант как правильный
                        System.Diagnostics.Debug.WriteLine($"[ExamEditPage] Обнаружен некорректный формат правильного ответа '{question.correct_answer}' для вопроса ID={question.test_ID}, исправлено на '1'");
                        question.correct_answer = "1";
                    }
                    
                    _questions.Add(new QuestionItem
                    {
                        QuestionID = question.test_ID,
                        Question = question.question,
                        Options = question.answer_options,
                        CorrectAnswer = question.correct_answer,
                        OptionsList = optionsList,
                        IsNew = false,
                        Index = _questions.Count + 1
                    });
                    
                    System.Diagnostics.Debug.WriteLine($"[ExamEditPage] Загружен вопрос ID={question.test_ID}: '{question.question.Substring(0, Math.Min(30, question.question.Length))}...'");
                }
                catch (Exception ex)
                {
                    System.Diagnostics.Debug.WriteLine($"[ExamEditPage] Ошибка при обработке вопроса ID={question.test_ID}: {ex.Message}");
                }
            }
        }

        private void SaveButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (!int.TryParse(durationTextBox.Text, out int duration) || duration <= 0)
                {
                    MessageBox.Show("Введите корректную длительность экзамена (в минутах)");
                    return;
                }
                
                if (!int.TryParse(attemptsTextBox.Text, out int attempts) || attempts <= 0)
                {
                    MessageBox.Show("Введите корректное количество попыток");
                    return;
                }

                // 1. Сначала обновляем экзамен
                using (var context = new Entities())
                {
                    // Получаем ID экзамена локально
                    int examId = _exam.exam_ID;
                    
                    // Обновляем экзамен напрямую через SQL
                    int result = context.Database.ExecuteSqlCommand(
                        "UPDATE exams SET duration = @p0, attempts = @p1 WHERE exam_ID = @p2",
                        duration, attempts, examId);
                    
                    if (result > 0)
                    {
                        System.Diagnostics.Debug.WriteLine($"[ExamEditPage] Сохранены основные данные экзамена: ID={examId}, Duration={duration}, Attempts={attempts}");
                    }
                    else
                    {
                        MessageBox.Show($"Экзамен с ID={examId} не найден в базе данных.");
                        System.Diagnostics.Debug.WriteLine($"[ExamEditPage] Ошибка: экзамен с ID={examId} не найден в базе данных");
                        return;
                    }
                }
                
                // Получаем ID экзамена и сохраняем локально
                int currentExamId = _exam.exam_ID;
                string examPrefix = $"EX_{currentExamId}_: ";
                
                // 2. Теперь сохраняем новые вопросы без привязки к модулям
                int newQuestionsAdded = 0;
                foreach (var questionItem in _questions)
                {
                    if (questionItem.IsNew)
                    {
                        using (var newContext = new Entities())
                        {
                            try 
                            {
                                // Добавляем метку экзамена к тексту вопроса
                                string questionText = examPrefix + questionItem.Question;
                                
                                // Создаем вопрос без привязки к модулю (NULL в module_ID)
                                var queryParams = new SqlParameter[]
                                {
                                    new SqlParameter("@module_ID", DBNull.Value),
                                    new SqlParameter("@question", questionText),
                                    new SqlParameter("@options", questionItem.Options),
                                    new SqlParameter("@answer", questionItem.CorrectAnswer)
                                };
                                
                                var sql = @"
                                    INSERT INTO tests (module_ID, question, answer_options, correct_answer)
                                    OUTPUT INSERTED.test_ID
                                    VALUES (@module_ID, @question, @options, @answer)";
                                
                                var newId = newContext.Database.SqlQuery<int>(sql, queryParams).FirstOrDefault();
                                
                                // Обновляем ID вопроса после сохранения
                                questionItem.QuestionID = newId;
                                questionItem.IsNew = false;
                                
                                newQuestionsAdded++;
                                System.Diagnostics.Debug.WriteLine($"[ExamEditPage] Создан новый вопрос ID={newId} для экзамена ID={currentExamId}");
                            }
                            catch (Exception ex)
                            {
                                System.Diagnostics.Debug.WriteLine($"[ExamEditPage] Ошибка при добавлении вопроса '{questionItem.Question}': {ex.Message}");
                            }
                        }
                    }
                }
                
                // 3. Обновляем существующие вопросы, оставляя их без привязки к модулю
                int existingQuestionsUpdated = 0;
                foreach (var questionItem in _questions)
                {
                    if (!questionItem.IsNew)
                    {
                        using (var updateContext = new Entities())
                        {
                            try
                            {
                                // Добавляем метку экзамена к тексту вопроса
                                string questionText = examPrefix + questionItem.Question;
                                
                                // Обновляем существующий вопрос
                                int result = updateContext.Database.ExecuteSqlCommand(
                                    @"UPDATE tests 
                                    SET question = @p0, answer_options = @p1, correct_answer = @p2, module_ID = NULL
                                    WHERE test_ID = @p3",
                                    questionText, questionItem.Options, questionItem.CorrectAnswer, 
                                    questionItem.QuestionID);
                                
                                if (result > 0)
                                {
                                    existingQuestionsUpdated++;
                                    System.Diagnostics.Debug.WriteLine($"[ExamEditPage] Обновлен существующий вопрос ID={questionItem.QuestionID}");
                                }
                                else
                                {
                                    System.Diagnostics.Debug.WriteLine($"[ExamEditPage] Вопрос ID={questionItem.QuestionID} не найден в базе данных");
                                }
                            }
                            catch (Exception ex)
                            {
                                System.Diagnostics.Debug.WriteLine($"[ExamEditPage] Ошибка при обновлении вопроса ID={questionItem.QuestionID}: {ex.Message}");
                            }
                        }
                    }
                }
                
                // 4. Дополнительная проверка: убеждаемся, что все вопросы корректно обновлены
                using (var checkContext = new Entities())
                {
                    try
                    {
                        // Загружаем все вопросы для этого экзамена с нашей специальной меткой
                        var examQuestions = checkContext.Database.SqlQuery<test>(
                            @"SELECT * FROM tests 
                            WHERE module_ID IS NULL 
                            AND question LIKE 'EX_" + currentExamId + "_%'").ToList();
                        
                        System.Diagnostics.Debug.WriteLine($"[ExamEditPage] Проверка после сохранения: найдено {examQuestions.Count} вопросов для экзамена ID={currentExamId}");
                        
                        // Выводим детальную информацию о каждом вопросе
                        foreach (var q in examQuestions)
                        {
                            System.Diagnostics.Debug.WriteLine($"[ExamEditPage] Вопрос ID={q.test_ID}: Текст={q.question?.Substring(0, Math.Min(30, q.question?.Length ?? 0))}...");
                        }
                    }
                    catch (Exception ex)
                    {
                        System.Diagnostics.Debug.WriteLine($"[ExamEditPage] Ошибка при проверке вопросов после сохранения: {ex.Message}");
                    }
                }

                // Отображаем информацию о результатах сохранения
                string message = "Экзамен успешно сохранен";
                if (newQuestionsAdded > 0 || existingQuestionsUpdated > 0)
                {
                    message += $"\nДобавлено новых вопросов: {newQuestionsAdded}\nОбновлено существующих вопросов: {existingQuestionsUpdated}";
                }
                MessageBox.Show(message);
                System.Diagnostics.Debug.WriteLine($"[ExamEditPage] Итоги сохранения экзамена: добавлено {newQuestionsAdded}, обновлено {existingQuestionsUpdated}");
                
                // Очищаем кэш контекста между операциями
                Entities.ResetContext();
                
                // Возвращаемся на предыдущую страницу
                if (NavigationService.CanGoBack)
                {
                    NavigationService.GoBack();
                    
                    // Обновляем страницу курса
                    if (NavigationService.Content is CourseEditPage coursePage)
                    {
                        coursePage.RefreshData();
                    }
                }
            }
            catch (Exception error)
            {
                MessageBox.Show($"Ошибка при сохранении экзамена: {error.Message}\n\nStackTrace: {error.StackTrace}");
                System.Diagnostics.Debug.WriteLine($"[ExamEditPage] Критическая ошибка при сохранении: {error.Message}\n{error.StackTrace}");
            }
        }

        private void CancelButton_Click(object sender, RoutedEventArgs e)
        {
            if (NavigationService.CanGoBack)
            {
                NavigationService.GoBack();
            }
        }

        private void AddQuestionButton_Click(object sender, RoutedEventArgs e)
        {
            // Создаем новый вопрос без отрицательного ID
            _questions.Add(new QuestionItem
            {
                QuestionID = 0, // 0 для обозначения новых вопросов
                Question = "Новый вопрос",
                Options = "Вариант 1;Вариант 2;Вариант 3;Вариант 4",
                CorrectAnswer = "1",
                OptionsList = new List<string> { "Вариант 1", "Вариант 2", "Вариант 3", "Вариант 4" },
                IsNew = true,
                Index = _questions.Count + 1
            });
            
            // Обновляем индексы всех вопросов
            UpdateQuestionIndices();
            
            // Прокручиваем список к новому вопросу
            questionsListView.ScrollIntoView(_questions[_questions.Count - 1]);
        }

        private void EditQuestionButton_Click(object sender, RoutedEventArgs e)
        {
            var button = sender as Button;
            if (button != null && button.Tag != null)
            {
                // Берем индекс из тега кнопки (начиная с 1)
                int displayIndex = (int)button.Tag;
                
                // Найдем вопрос с соответствующим индексом
                QuestionItem questionToEdit = null;
                foreach (var q in _questions)
                {
                    if (q.Index == displayIndex)
                    {
                        questionToEdit = q;
                        break;
                    }
                }
                
                if (questionToEdit != null)
                {
                    EditQuestion(questionToEdit);
                }
                else
                {
                    // Если почему-то не нашли, то пытаемся использовать старый метод
                    int index = displayIndex - 1; // Преобразуем в 0-индексацию
                    if (index >= 0 && index < _questions.Count)
                    {
                        EditQuestion(_questions[index]);
                    }
                }
            }
        }

        private void DeleteQuestionButton_Click(object sender, RoutedEventArgs e)
        {
            var button = sender as Button;
            if (button != null && button.Tag != null)
            {
                // Берем индекс из тега кнопки (начиная с 1)
                int displayIndex = (int)button.Tag;
                
                // Найдем вопрос с соответствующим индексом
                QuestionItem questionToDelete = null;
                foreach (var q in _questions)
                {
                    if (q.Index == displayIndex)
                    {
                        questionToDelete = q;
                        break;
                    }
                }
                
                int actualIndex = -1;
                
                if (questionToDelete != null)
                {
                    // Найдем реальный индекс в коллекции
                    actualIndex = _questions.IndexOf(questionToDelete);
                }
                else
                {
                    // Если почему-то не нашли, то пытаемся использовать старый метод
                    int index = displayIndex - 1; // Преобразуем в 0-индексацию
                    if (index >= 0 && index < _questions.Count)
                    {
                        questionToDelete = _questions[index];
                        actualIndex = index;
                    }
                }
                
                if (actualIndex >= 0 && questionToDelete != null)
                {
                    var dialogResult = MessageBox.Show("Вы уверены, что хотите удалить этот вопрос?", 
                        "Подтверждение удаления", MessageBoxButton.YesNo, MessageBoxImage.Warning);
                        
                    if (dialogResult == MessageBoxResult.Yes)
                    {
                        _questions.RemoveAt(actualIndex);
                        
                        // Обновляем индексы всех вопросов после удаления
                        UpdateQuestionIndices();
                        
                        // Если это не новый вопрос, удаляем его из базы данных
                        if (!questionToDelete.IsNew)
                        {
                            try
                            {
                                using (var context = new Entities())
                                {
                                    // Удаляем связанные результаты тестов с помощью SQL запроса
                                    int questId = questionToDelete.QuestionID;
                                    context.Database.ExecuteSqlCommand(
                                        "DELETE FROM test_results WHERE test_ID = @p0", 
                                        questId);
                                    
                                    // Удаляем сам вопрос
                                    context.Database.ExecuteSqlCommand(
                                        "DELETE FROM tests WHERE test_ID = @p0", 
                                        questId);
                                    
                                    System.Diagnostics.Debug.WriteLine($"[ExamEditPage] Удален вопрос ID={questId}");
                                }
                            }
                            catch (Exception ex)
                            {
                                MessageBox.Show($"Ошибка при удалении вопроса: {ex.Message}");
                            }
                        }
                    }
                }
            }
        }

        private void EditQuestion(QuestionItem questionItem)
        {
            try
            {
                // Создаем копию вопроса перед редактированием
                var originalQuestion = questionItem.Question;
                var originalOptions = questionItem.Options;
                var originalAnswer = questionItem.CorrectAnswer;
                
                // Создаем диалоговое окно для редактирования вопроса
                var editWindow = new Window
                {
                    Title = "Редактирование вопроса",
                    Width = 600,
                    Height = 500,
                    WindowStartupLocation = WindowStartupLocation.CenterScreen,
                    Owner = Window.GetWindow(this) // Установка владельца окна
                };
                
                var grid = new Grid();
                grid.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
                grid.RowDefinitions.Add(new RowDefinition { Height = new GridLength(100) });
                grid.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
                grid.RowDefinitions.Add(new RowDefinition { Height = new GridLength(150) });
                grid.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
                grid.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
                grid.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
                
                // Вопрос
                var questionLabel = new TextBlock
                {
                    Text = "Вопрос:",
                    Margin = new Thickness(10, 10, 10, 5),
                    FontWeight = FontWeights.Bold
                };
                Grid.SetRow(questionLabel, 0);
                
                var questionTextBox = new TextBox
                {
                    Text = questionItem.Question,
                    Margin = new Thickness(10),
                    AcceptsReturn = true,
                    TextWrapping = TextWrapping.Wrap
                };
                Grid.SetRow(questionTextBox, 1);
                
                // Варианты ответов
                var optionsLabel = new TextBlock
                {
                    Text = "Варианты ответов (каждый с новой строки):",
                    Margin = new Thickness(10, 10, 10, 5),
                    FontWeight = FontWeights.Bold
                };
                Grid.SetRow(optionsLabel, 2);
                
                var optionsTextBox = new TextBox
                {
                    Text = string.Join(Environment.NewLine, questionItem.Options.Split(';')),
                    Margin = new Thickness(10),
                    AcceptsReturn = true,
                    TextWrapping = TextWrapping.Wrap
                };
                Grid.SetRow(optionsTextBox, 3);
                
                // Правильный ответ
                var correctAnswerLabel = new TextBlock
                {
                    Text = "Номер правильного ответа (начиная с 1):",
                    Margin = new Thickness(10, 10, 10, 5),
                    FontWeight = FontWeights.Bold
                };
                Grid.SetRow(correctAnswerLabel, 4);
                
                var correctAnswerTextBox = new TextBox
                {
                    Text = questionItem.CorrectAnswer,
                    Margin = new Thickness(10)
                };
                Grid.SetRow(correctAnswerTextBox, 5);
                
                // Кнопки
                var buttonsPanel = new StackPanel
                {
                    Orientation = Orientation.Horizontal,
                    HorizontalAlignment = HorizontalAlignment.Right,
                    Margin = new Thickness(10)
                };
                Grid.SetRow(buttonsPanel, 6);
                
                var saveButton = new Button
                {
                    Content = "Сохранить",
                    Padding = new Thickness(10, 5, 10, 5),
                    Margin = new Thickness(5),
                    IsDefault = true // Сделаем кнопку действием по умолчанию
                };
                
                var cancelButton = new Button
                {
                    Content = "Отмена",
                    Padding = new Thickness(10, 5, 10, 5),
                    Margin = new Thickness(5),
                    IsCancel = true // Сделаем кнопку отмены
                };
                
                buttonsPanel.Children.Add(saveButton);
                buttonsPanel.Children.Add(cancelButton);
                
                // Добавляем элементы в сетку
                grid.Children.Add(questionLabel);
                grid.Children.Add(questionTextBox);
                grid.Children.Add(optionsLabel);
                grid.Children.Add(optionsTextBox);
                grid.Children.Add(correctAnswerLabel);
                grid.Children.Add(correctAnswerTextBox);
                grid.Children.Add(buttonsPanel);
                
                // Обработчики событий
                saveButton.Click += (s, args) =>
                {
                    try
                    {
                        // Валидация
                        if (string.IsNullOrWhiteSpace(questionTextBox.Text))
                        {
                            MessageBox.Show("Введите текст вопроса");
                            return;
                        }
                        
                        var options = optionsTextBox.Text.Split(new[] { Environment.NewLine }, StringSplitOptions.RemoveEmptyEntries);
                        if (options.Length < 2)
                        {
                            MessageBox.Show("Введите не менее двух вариантов ответа");
                            return;
                        }
                        
                        int correctAnswer;
                        if (!int.TryParse(correctAnswerTextBox.Text, out correctAnswer) || correctAnswer < 1 || correctAnswer > options.Length)
                        {
                            MessageBox.Show($"Введите корректный номер правильного ответа (от 1 до {options.Length})");
                            return;
                        }
                        
                        // Обновляем вопрос
                        questionItem.Question = questionTextBox.Text;
                        questionItem.Options = string.Join(";", options);
                        questionItem.CorrectAnswer = correctAnswer.ToString();
                        questionItem.OptionsList = options.ToList();
                        
                        // Логируем изменения
                        if (questionItem.Question != originalQuestion)
                            System.Diagnostics.Debug.WriteLine($"[ExamEditPage] Изменен текст вопроса ID={questionItem.QuestionID}: '{originalQuestion}' -> '{questionItem.Question}'");
                        
                        if (questionItem.Options != originalOptions)
                            System.Diagnostics.Debug.WriteLine($"[ExamEditPage] Изменены варианты ответов для вопроса ID={questionItem.QuestionID}");
                        
                        if (questionItem.CorrectAnswer != originalAnswer)
                            System.Diagnostics.Debug.WriteLine($"[ExamEditPage] Изменен правильный ответ для вопроса ID={questionItem.QuestionID}: {originalAnswer} -> {questionItem.CorrectAnswer}");
                        
                        // Обновляем интерфейс
                        questionsListView.Items.Refresh();
                        
                        editWindow.DialogResult = true;
                        editWindow.Close();
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show($"Ошибка при сохранении вопроса: {ex.Message}");
                        System.Diagnostics.Debug.WriteLine($"[ExamEditPage] Ошибка при редактировании вопроса ID={questionItem.QuestionID}: {ex.Message}");
                    }
                };
                
                cancelButton.Click += (s, args) => editWindow.Close();
                
                // Показываем окно
                editWindow.Content = grid;
                editWindow.ShowDialog();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при открытии редактора вопросов: {ex.Message}");
            }
        }

        // Добавляем новый метод для обновления индексов всех вопросов
        private void UpdateQuestionIndices()
        {
            for (int i = 0; i < _questions.Count; i++)
            {
                _questions[i].Index = i + 1; // Индексация с 1 для удобства пользователя
            }
            questionsListView.Items.Refresh();
        }
    }
} 
