using System;
using System.Windows.Data;

namespace online_courses
{
    public static class Converters
    {
        // Static instances of all converters for easy access
        public static readonly GetIndexConverter GetIndex = new GetIndexConverter();
        
        // Other converters can be added here
        // public static readonly StatusToColorConverter StatusToColor = new StatusToColorConverter();
        // public static readonly RoleToColorConverter RoleToColor = new RoleToColorConverter();
        // public static readonly BoolToAlignmentConverter BoolToAlignment = new BoolToAlignmentConverter();
    }
} 