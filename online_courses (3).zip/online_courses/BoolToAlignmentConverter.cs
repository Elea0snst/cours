using System;
using System.Globalization;
using System.Windows;
using System.Windows.Data;

namespace online_courses
{
    /// <summary>
    /// Конвертер для преобразования булевого значения в HorizontalAlignment
    /// Используется в чате для выравнивания сообщений влево или вправо
    /// </summary>
    public class BoolToAlignmentConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            if (value is bool isOwn && isOwn)
            {
                return HorizontalAlignment.Right;
            }
            
            return HorizontalAlignment.Left;
        }

        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            if (value is HorizontalAlignment alignment)
            {
                return alignment == HorizontalAlignment.Right;
            }
            
            return false;
        }
    }
} 