using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.IO;

namespace online_courses
{
    // Класс для отображения данных в DataGrid
    public class UserViewModel
    {
        public int UsersID { get; set; }
        public string Login { get; set; }
        public string RoleName { get; set; }
        public string Email { get; set; }
        public string FullName { get; set; }
        public int RoleID { get; set; }
        
        // Скрытые поля для хранения оригинальных объектов
        public user OriginalUser { get; set; }
    }

    // Класс для кодов доступа
    public class RoleAccessCode
    {
        public int RoleID { get; set; }
        public string RoleName { get; set; }
        public string AccessCode { get; set; }
        public DateTime GenerationDate { get; set; }

        private static Dictionary<int, RoleAccessCode> _activeCodes = new Dictionary<int, RoleAccessCode>();

        public string GenerateAccessCode()
        {
            if (RoleID != 1 && RoleID != 4 && RoleID != 5)
            {
                throw new InvalidOperationException("Код доступа может быть сгенерирован только для ролей Admin, Moderator и Support");
            }

            // Генерируем код доступа на основе роли, текущего года, месяца и случайного числа
            string rolePrefix = RoleID == 1 ? "ADM" : (RoleID == 4 ? "MOD" : "SUP");
            string yearMonth = DateTime.Now.ToString("yyMM");
            string randomPart = new Random().Next(1000, 9999).ToString();
            AccessCode = $"{rolePrefix}{yearMonth}{randomPart}";
            GenerationDate = DateTime.Now;

            // Сохраняем код в словаре
            _activeCodes[RoleID] = this;

            return AccessCode;
        }

        public static bool VerifyAccessCode(int roleId, string code)
        {
            if (!_activeCodes.ContainsKey(roleId))
            {
                return false;
            }

            var storedCode = _activeCodes[roleId];
            
            // Проверяем, не устарел ли код (например, если прошло больше 24 часов)
            if ((DateTime.Now - storedCode.GenerationDate).TotalHours > 24)
            {
                _activeCodes.Remove(roleId);
                return false;
            }

            return storedCode.AccessCode == code;
        }
    }

    public partial class AdminUsersPage : Page, IPageRefresh
    {
        private user _currentUser;
        private List<UserViewModel> _userViewModels = new List<UserViewModel>();
        private UserViewModel _selectedUserViewModel;
        private string _searchText = "";

        public AdminUsersPage(user user)
        {
            InitializeComponent();
            
            // Создаем безопасную копию текущего пользователя
            _currentUser = new user
            {
                users_ID = user.users_ID,
                users_login = user.users_login,
                users_password = user.users_password,
                users_role_ID = user.users_role_ID
            };

            try
            {
                // Сбрасываем контекст Entity Framework перед любыми операциями
                Entities.ResetContext();
                
                // Загружаем роли
            LoadRoles();
                
                // Инициализируем состояние кнопок
            UpdateButtonsState();
                
                // Загружаем данные
                RefreshData();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при инициализации страницы: {ex.Message}", 
                              "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void Page_Loaded(object sender, RoutedEventArgs e)
        {
            try
            {
                // Проверяем, есть ли уже загруженные данные
                if (_userViewModels == null || !_userViewModels.Any())
                {
                    // Если нет, загружаем данные
            RefreshData();
                }
                else
                {
                    // Иначе просто обновляем UI
                    ApplyFilter();
                    UpdateButtonsState();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при загрузке страницы: {ex.Message}", 
                              "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void LoadRoles()
        {
            try
            {
                // Сбрасываем контекст перед загрузкой ролей
                Entities.ResetContext();
                
                using (var context = new Entities())
                {
                    // Загружаем список ролей для фильтрации
                    var roles = context.roles.ToList();
                    
                    if (roles != null && roles.Any())
                    {
                // Добавляем опцию "Все роли"
                roles.Insert(0, new role { role_ID = 0, role_name = "Все роли" });

                roleFilterComboBox.ItemsSource = roles;
                roleFilterComboBox.SelectedIndex = 0;
                    }
                    else
                    {
                        // Если роли не загрузились, создаем минимальную коллекцию
                        var defaultRoles = new List<role>
                        {
                            new role { role_ID = 0, role_name = "Все роли" }
                        };
                        roleFilterComboBox.ItemsSource = defaultRoles;
                        roleFilterComboBox.SelectedIndex = 0;
                        
                        MessageBox.Show("Не удалось загрузить список ролей. Используется ограниченный список.",
                                      "Предупреждение", MessageBoxButton.OK, MessageBoxImage.Warning);
                    }
                }
            }
            catch (Exception ex)
            {
                // Более детальное логирование ошибки
                MessageBox.Show($"Ошибка при загрузке списка ролей: {ex.Message}\nStackTrace: {ex.StackTrace}");
                
                // Создаем минимальную коллекцию, чтобы интерфейс не сломался
                var defaultRoles = new List<role>
                {
                    new role { role_ID = 0, role_name = "Все роли" }
                };
                roleFilterComboBox.ItemsSource = defaultRoles;
                roleFilterComboBox.SelectedIndex = 0;
            }
        }

        public void RefreshData()
        {
            try
            {
                // Сбрасываем контекст перед загрузкой данных
                Entities.ResetContext();
                
                using (var context = new Entities())
                {
                    // Очищаем существующий список
                    _userViewModels.Clear();
                    
                    // Загружаем базовый список пользователей
                    var users = context.users.ToList();
                    
                    foreach (var user in users)
                    {
                        // Получаем связанные данные
                        var role = context.roles.FirstOrDefault(r => r.role_ID == user.users_role_ID);
                        var profile = context.user_profiles.FirstOrDefault(p => p.users_ID == user.users_ID);
                        
                        // Создаем модель представления
                        var viewModel = new UserViewModel
                        {
                            UsersID = user.users_ID,
                            Login = user.users_login,
                            RoleName = role?.role_name ?? "Не указана",
                            RoleID = user.users_role_ID ?? 0,
                            Email = profile?.users_email ?? "Не указан",
                            FullName = GetFullName(profile),
                            OriginalUser = user
                        };
                        
                        _userViewModels.Add(viewModel);
                    }

                // Применяем фильтрацию
                ApplyFilter();

                // Обновляем состояние кнопок
                UpdateButtonsState();
                }
            }
            catch (Exception ex)
            {
                // Детальное логирование ошибки
                MessageBox.Show($"Ошибка при загрузке списка пользователей: {ex.Message}\nStackTrace: {ex.StackTrace}");
                
                // Создаем пустой список пользователей, если произошла ошибка
                _userViewModels.Clear();
                usersDataGrid.ItemsSource = _userViewModels;
                
                // Обновляем состояние кнопок
                UpdateButtonsState();
            }
        }

        private string GetFullName(user_profiles profile)
        {
            if (profile == null)
                return "Не указано";
                
            string firstName = profile.users_name ?? "";
            string lastName = profile.users_surname ?? "";
            
            if (string.IsNullOrWhiteSpace(firstName) && string.IsNullOrWhiteSpace(lastName))
                return "Не указано";
                
            return $"{firstName} {lastName}".Trim();
        }

        private void ApplyFilter()
        {
            try
            {
                // Проверяем наличие выбранной роли
            var selectedRole = roleFilterComboBox.SelectedItem as role;
            if (selectedRole == null)
                {
                    usersDataGrid.ItemsSource = null;
                    return;
                }

                // Проверяем, что список инициализирован
                if (_userViewModels == null)
                {
                    _userViewModels = new List<UserViewModel>();
                    usersDataGrid.ItemsSource = _userViewModels;
                return;
                }

                // Создаем копию списка для фильтрации
                IEnumerable<UserViewModel> filteredUsers = new List<UserViewModel>(_userViewModels);

            // Применяем фильтр по роли
            if (selectedRole.role_ID != 0)
            {
                    filteredUsers = filteredUsers.Where(u => u.RoleID == selectedRole.role_ID);
            }

            // Применяем фильтр по поисковому запросу
            if (!string.IsNullOrWhiteSpace(_searchText))
            {
                    filteredUsers = filteredUsers.Where(u => u.Login != null && 
                        u.Login.ToLower().Contains(_searchText.ToLower()));
            }

            // Исключаем текущего пользователя
                filteredUsers = filteredUsers.Where(u => u.UsersID != _currentUser.users_ID);

            // Устанавливаем отфильтрованные данные
            usersDataGrid.ItemsSource = filteredUsers.ToList();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при применении фильтра: {ex.Message}", 
                                "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                
                // Устанавливаем пустой список при ошибке
                usersDataGrid.ItemsSource = new List<UserViewModel>();
            }
        }

        private void UpdateButtonsState()
        {
            // Получаем выбранного пользователя
            _selectedUserViewModel = usersDataGrid.SelectedItem as UserViewModel;
            
            if (_selectedUserViewModel == null)
            {
                viewButton.IsEnabled = false;
                editButton.IsEnabled = false;
                deleteButton.IsEnabled = false;
                reportsButton.IsEnabled = false;
                accessCodeButton.IsEnabled = false;
                return;
            }

            // Нельзя редактировать или удалять самого себя
            bool isSelf = _selectedUserViewModel.UsersID == _currentUser.users_ID;

            viewButton.IsEnabled = true;
            editButton.IsEnabled = !isSelf;
            deleteButton.IsEnabled = !isSelf;
            reportsButton.IsEnabled = true;
            
            // Включаем кнопку кода доступа только для ролей Admin (1), Moderator (4) и Support (5)
            accessCodeButton.IsEnabled = _selectedUserViewModel.RoleID == 1 || 
                                       _selectedUserViewModel.RoleID == 4 || 
                                       _selectedUserViewModel.RoleID == 5;
        }

        private void RoleFilterComboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            ApplyFilter();
        }

        private void SearchTextBox_TextChanged(object sender, TextChangedEventArgs e)
        {
            _searchText = searchTextBox.Text.Trim();
            ApplyFilter();
        }

        private void UsersDataGrid_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            _selectedUserViewModel = usersDataGrid.SelectedItem as UserViewModel;
            UpdateButtonsState();
        }

        private void AddButton_Click(object sender, RoutedEventArgs e)
        {
            // Просто возвращаемся без сообщений
            return;
        }

        private void ViewButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (_selectedUserViewModel == null)
                return;

                // Сбрасываем контекст и создаем новый
                Entities.ResetContext();
                
                using (var db = new Entities())
                {
                    // Получаем пользователя заново из базы данных
                    var user = db.users.FirstOrDefault(u => u.users_ID == _selectedUserViewModel.UsersID);
                    if (user == null)
                    {
                        MessageBox.Show("Пользователь не найден в базе данных.", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                        return;
                    }

            // Получаем профиль пользователя для отображения дополнительных данных
                    var userProfile = db.user_profiles.FirstOrDefault(p => p.users_ID == user.users_ID);
                    
                    // Получаем роль пользователя
                    var role = db.roles.FirstOrDefault(r => r.role_ID == user.users_role_ID);
                    string roleName = role?.role_name ?? "Не указана";

                    // Создаем текст сообщения
                    var messageBuilder = new StringBuilder();
                    messageBuilder.AppendLine("Профиль пользователя:");
                    messageBuilder.AppendLine();
                    messageBuilder.AppendLine($"ID: {user.users_ID}");
                    messageBuilder.AppendLine($"Логин: {user.users_login ?? "Не указан"}");
                    messageBuilder.AppendLine($"Роль: {roleName}");
                    
                    if (userProfile != null)
                    {
                        messageBuilder.AppendLine($"Email: {userProfile.users_email ?? "Не указан"}");
                        messageBuilder.AppendLine($"Имя: {userProfile.users_name ?? "Не указано"}");
                        messageBuilder.AppendLine($"Фамилия: {userProfile.users_surname ?? "Не указана"}");
                    }
                    else
                    {
                        messageBuilder.AppendLine("Профиль пользователя не заполнен.");
                    }

            // Отображаем информацию о пользователе
                    MessageBox.Show(messageBuilder.ToString(), "Информация о пользователе", 
                                   MessageBoxButton.OK, MessageBoxImage.Information);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при отображении информации о пользователе: {ex.Message}", 
                               "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void EditButton_Click(object sender, RoutedEventArgs e)
        {
            // Создаем окно редактирования пользователя на лету
            if (_selectedUserViewModel == null)
                return;

            try
            {
                // Создаем окно редактирования пользователя напрямую вместо использования UserEditWindow
                Window editWindow = new Window
                {
                    Title = "Редактирование пользователя",
                    Width = 500,
                    Height = 450,
                    WindowStartupLocation = WindowStartupLocation.CenterScreen,
                    ResizeMode = ResizeMode.NoResize
                };

                // Получаем данные пользователя
                int userId = _selectedUserViewModel.UsersID;
                string login = _selectedUserViewModel.Login;
                int roleId = _selectedUserViewModel.RoleID;
                string email = _selectedUserViewModel.Email;
                string fullName = _selectedUserViewModel.FullName;

                // Создаем содержимое окна
                Grid mainGrid = new Grid { Margin = new Thickness(15) };
                mainGrid.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
                mainGrid.RowDefinitions.Add(new RowDefinition { Height = new GridLength(1, GridUnitType.Star) });
                mainGrid.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });

                // Заголовок
                TextBlock titleBlock = new TextBlock
                {
                    Text = "Редактирование данных пользователя",
                    FontSize = 18,
                    FontWeight = FontWeights.Bold,
                    Margin = new Thickness(0, 0, 0, 15)
                };
                Grid.SetRow(titleBlock, 0);
                mainGrid.Children.Add(titleBlock);

                // Создаем форму
                ScrollViewer scrollViewer = new ScrollViewer { VerticalScrollBarVisibility = ScrollBarVisibility.Auto };
                StackPanel formPanel = new StackPanel();
                scrollViewer.Content = formPanel;
                Grid.SetRow(scrollViewer, 1);
                mainGrid.Children.Add(scrollViewer);

                // ID пользователя
                formPanel.Children.Add(new TextBlock { Text = "Идентификатор:", Margin = new Thickness(0, 10, 0, 5) });
                TextBox idTextBox = new TextBox { IsReadOnly = true, Margin = new Thickness(0, 0, 0, 15), Text = userId.ToString() };
                formPanel.Children.Add(idTextBox);

                // Логин
                formPanel.Children.Add(new TextBlock { Text = "Логин:", Margin = new Thickness(0, 0, 0, 5) });
                TextBox loginTextBox = new TextBox { Margin = new Thickness(0, 0, 0, 15), Text = login };
                formPanel.Children.Add(loginTextBox);

                // Роль
                formPanel.Children.Add(new TextBlock { Text = "Роль:", Margin = new Thickness(0, 0, 0, 5) });
                ComboBox roleComboBox = new ComboBox { Margin = new Thickness(0, 0, 0, 15) };
                List<role> roles = null;

                // Загружаем роли из базы данных
                Entities.ResetContext();
                using (var context = new Entities())
                {
                    roles = context.roles.ToList();
                    roleComboBox.ItemsSource = roles;
                    roleComboBox.DisplayMemberPath = "role_name";
                    roleComboBox.SelectedValuePath = "role_ID";
                    roleComboBox.SelectedValue = roleId;
                }
                formPanel.Children.Add(roleComboBox);

                // Email
                formPanel.Children.Add(new TextBlock { Text = "Email:", Margin = new Thickness(0, 0, 0, 5) });
                TextBox emailTextBox = new TextBox { Margin = new Thickness(0, 0, 0, 15), Text = email };
                formPanel.Children.Add(emailTextBox);

                // Имя и фамилия - разбираем из полного имени
                string firstName = string.Empty;
                string lastName = string.Empty;
                string patronymic = string.Empty;
                
                if (!string.IsNullOrEmpty(fullName) && fullName != "Не указано")
                {
                    var nameParts = fullName.Split(' ');
                    if (nameParts.Length > 0)
                        firstName = nameParts[0];
                    if (nameParts.Length > 1)
                        lastName = nameParts[1];
                }

                formPanel.Children.Add(new TextBlock { Text = "Имя:", Margin = new Thickness(0, 0, 0, 5) });
                TextBox nameTextBox = new TextBox { Margin = new Thickness(0, 0, 0, 15), Text = firstName };
                formPanel.Children.Add(nameTextBox);

                formPanel.Children.Add(new TextBlock { Text = "Фамилия:", Margin = new Thickness(0, 0, 0, 5) });
                TextBox surnameTextBox = new TextBox { Margin = new Thickness(0, 0, 0, 15), Text = lastName };
                formPanel.Children.Add(surnameTextBox);

                // Добавляю поле для отчества
                formPanel.Children.Add(new TextBlock { Text = "Отчество:", Margin = new Thickness(0, 0, 0, 5) });
                TextBox patronymicTextBox = new TextBox { Margin = new Thickness(0, 0, 0, 15) };
                formPanel.Children.Add(patronymicTextBox);

                // Пароль
                formPanel.Children.Add(new TextBlock { Text = "Новый пароль (оставьте пустым, чтобы не менять):", Margin = new Thickness(0, 0, 0, 5) });
                PasswordBox passwordBox = new PasswordBox { Margin = new Thickness(0, 0, 0, 15) };
                formPanel.Children.Add(passwordBox);

                formPanel.Children.Add(new TextBlock { Text = "Подтверждение пароля:", Margin = new Thickness(0, 0, 0, 5) });
                PasswordBox confirmPasswordBox = new PasswordBox { Margin = new Thickness(0, 0, 0, 15) };
                formPanel.Children.Add(confirmPasswordBox);

                // Кнопки
                StackPanel buttonsPanel = new StackPanel
                {
                    Orientation = Orientation.Horizontal,
                    HorizontalAlignment = HorizontalAlignment.Right,
                    Margin = new Thickness(0, 15, 0, 0)
                };
                Grid.SetRow(buttonsPanel, 2);
                mainGrid.Children.Add(buttonsPanel);

                Button saveButton = new Button { Content = "Сохранить", Width = 100, Margin = new Thickness(0, 0, 10, 0) };
                Button cancelButton = new Button { Content = "Отмена", Width = 100 };
                buttonsPanel.Children.Add(saveButton);
                buttonsPanel.Children.Add(cancelButton);

                // Результат диалога
                bool dialogResult = false;

                // Обработчики кнопок
                saveButton.Click += (s, args) =>
                {
                    try
                    {
                        // Валидация
                        if (string.IsNullOrWhiteSpace(loginTextBox.Text))
                        {
                            MessageBox.Show("Логин не может быть пустым.", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                            loginTextBox.Focus();
                            return;
                        }

                        if (roleComboBox.SelectedValue == null)
                        {
                            MessageBox.Show("Необходимо выбрать роль.", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                            roleComboBox.Focus();
                            return;
                        }

                        // Проверка формата email только если поле не пустое
                        if (!string.IsNullOrWhiteSpace(emailTextBox.Text))
                        {
                            string emailPattern = @"^[^@\s]+@[^@\s]+\.[^@\s]+$";
                            if (!System.Text.RegularExpressions.Regex.IsMatch(emailTextBox.Text, emailPattern))
                            {
                                MessageBox.Show("Указан некорректный формат email.", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                                emailTextBox.Focus();
                                return;
                            }
                        }

                        // Проверка паролей
                        string newPassword = passwordBox.Password;
                        string confirmPassword = confirmPasswordBox.Password;

                        if (!string.IsNullOrEmpty(newPassword))
                        {
                            if (newPassword.Length < 6)
                            {
                                MessageBox.Show("Пароль должен содержать не менее 6 символов.", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                                passwordBox.Focus();
                                return;
                            }

                            if (newPassword != confirmPassword)
                            {
                                MessageBox.Show("Пароли не совпадают.", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                                confirmPasswordBox.Focus();
                return;
                            }
                        }

                        // Сохраняем изменения
                        Entities.ResetContext();
                        using (var context = new Entities())
                        {
                            // Получаем пользователя
                            var user = context.users.FirstOrDefault(u => u.users_ID == userId);
                            if (user == null)
                            {
                                throw new InvalidOperationException("Пользователь не найден в базе данных.");
                            }

                            // Обновляем данные пользователя
                            user.users_login = loginTextBox.Text;
                            user.users_role_ID = (int)roleComboBox.SelectedValue;

                            // Обновляем пароль, если он был изменен
                            if (!string.IsNullOrEmpty(newPassword))
                            {
                                user.users_password = newPassword;
                            }

                            // Получаем или создаем профиль пользователя
                            var profile = context.user_profiles.FirstOrDefault(p => p.users_ID == userId);
                            if (profile == null)
                            {
                                profile = new user_profiles { users_ID = userId };
                                context.user_profiles.Add(profile);
                            }

                            // Обновляем данные профиля
                            profile.users_email = string.IsNullOrWhiteSpace(emailTextBox.Text) ? null : emailTextBox.Text;
                            profile.users_name = nameTextBox.Text;
                            profile.users_surname = surnameTextBox.Text;
                            profile.users_patronymic = patronymicTextBox.Text;

                            // Сохраняем изменения
                            context.SaveChanges();
                        }

                        dialogResult = true;
                        editWindow.Close();
                    }
                    catch (System.Data.Entity.Validation.DbEntityValidationException ex)
                    {
                        var errorMessages = ex.EntityValidationErrors
                            .SelectMany(x => x.ValidationErrors)
                            .Select(x => $"{x.PropertyName}: {x.ErrorMessage}");
                        string fullError = "Ошибка валидации:\n" + string.Join("\n", errorMessages);
                        MessageBox.Show(fullError, "Ошибка валидации", MessageBoxButton.OK, MessageBoxImage.Error);
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show($"Ошибка при сохранении данных: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                    }
                };

                cancelButton.Click += (s, args) =>
                {
                    dialogResult = false;
                    editWindow.Close();
                };

                // Устанавливаем содержимое окна
                editWindow.Content = mainGrid;

                // Показываем окно
                editWindow.ShowDialog();

                // Обновляем данные, если редактирование было успешным
                if (dialogResult)
                {
                    RefreshData();
                    MessageBox.Show("Данные пользователя успешно обновлены.", "Информация", MessageBoxButton.OK, MessageBoxImage.Information);
                }
                }
                catch (Exception ex)
                {
                MessageBox.Show($"Ошибка при редактировании пользователя: {ex.Message}", 
                               "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void DeleteButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (_selectedUserViewModel == null || _selectedUserViewModel.UsersID == _currentUser.users_ID)
                return;

            // Запрашиваем подтверждение удаления
                var result = MessageBox.Show($"Вы действительно хотите удалить пользователя {_selectedUserViewModel.Login}?\n" +
                                       "Это действие нельзя отменить и все данные пользователя будут удалены.",
                                       "Подтверждение удаления", MessageBoxButton.YesNo, MessageBoxImage.Warning);

            if (result == MessageBoxResult.Yes)
            {
                try
                {
                        var userId = _selectedUserViewModel.UsersID;
                        
                    // Проверяем, есть ли зависимые данные, которые нужно удалить
                        var hasRelatedData = CheckForRelatedData(userId);

                    if (hasRelatedData)
                    {
                        var confirmResult = MessageBox.Show("У пользователя есть связанные данные (курсы, отзывы, сообщения и т.д.).\n" +
                                                          "Эти данные также будут удалены. Продолжить?",
                                                          "Подтверждение удаления", MessageBoxButton.YesNo, MessageBoxImage.Warning);
                        if (confirmResult != MessageBoxResult.Yes)
                            return;
                    }

                        // Сначала удаляем все связанные данные
                        DeleteUserData(userId);
                        
                        // Затем удаляем самого пользователя
                        Entities.ResetContext();
                        using (var db = new Entities())
                        {
                            // Получаем пользователя заново из базы данных
                            var userToDelete = db.users.FirstOrDefault(u => u.users_ID == userId);
                            if (userToDelete != null)
                            {
                                db.users.Remove(userToDelete);
                                db.SaveChanges();
                                MessageBox.Show($"Пользователь {_selectedUserViewModel.Login} успешно удален.");
                            }
                            else
                            {
                                MessageBox.Show($"Пользователь с ID {userId} не найден в базе данных.");
                            }
                        }

                    // Обновляем список пользователей
                    RefreshData();
                }
                catch (Exception ex)
                {
                        MessageBox.Show($"Ошибка при удалении пользователя: {ex.Message}\n{ex.StackTrace}");
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при обработке удаления: {ex.Message}\n{ex.StackTrace}");
            }
        }

        private bool CheckForRelatedData(int userId)
        {
            try
            {
                // Безопасно получаем новый экземпляр контекста
                Entities.ResetContext();
                using (var db = new Entities())
                {
            // Проверяем наличие связанных данных
                    bool hasCourses = db.courses.Any(c => c != null && c.course_author == userId);
                    bool hasReviews = db.course_reviews.Any(r => r != null && r.users_ID == userId);
                    bool hasTestResults = db.test_results.Any(t => t != null && t.users_ID == userId);
                    bool hasMessages = db.chat_messages.Any(m => m != null && 
                        (m.users_ID == userId || m.support_ID == userId));
                    bool hasComplaints = db.complaints.Any(c => c != null && c.users_ID == userId);
            
            return hasCourses || hasReviews || hasTestResults || hasMessages || hasComplaints;
                }
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine($"Ошибка при проверке связанных данных: {ex.Message}");
                return false; // Предполагаем, что данных нет, если произошла ошибка
            }
        }

        private void DeleteUserData(int userId)
        {
            try
            {
                // Используем безопасный подход с новым контекстом
                Entities.ResetContext();
                using (var db = new Entities())
                {
            // Удаляем связанные данные
                    var reviews = db.course_reviews.Where(r => r != null && r.users_ID == userId).ToList();
            foreach (var review in reviews)
            {
                        if (review != null)
                db.course_reviews.Remove(review);
            }
            
                    var testResults = db.test_results.Where(t => t != null && t.users_ID == userId).ToList();
            foreach (var result in testResults)
            {
                        if (result != null)
                db.test_results.Remove(result);
            }
            
                    var messages = db.chat_messages.Where(m => m != null && 
                         (m.users_ID == userId || m.support_ID == userId)).ToList();
            foreach (var message in messages)
            {
                        if (message != null)
                db.chat_messages.Remove(message);
            }
            
                    var complaints = db.complaints.Where(c => c != null && c.users_ID == userId).ToList();
            foreach (var complaint in complaints)
            {
                        if (complaint != null)
                db.complaints.Remove(complaint);
            }
                    
                    // Находим пользователя, чтобы определить его роль
                    var user = db.users.FirstOrDefault(u => u.users_ID == userId);
            
            // Для преподавателей нужно обработать курсы
                    if (user != null && user.users_role_ID == 2) // Роль преподавателя
            {
                        var courses = db.courses.Where(c => c != null && c.course_author == userId).ToList();
                foreach (var course in courses)
                        {
                            if (course != null)
                {
                    // Здесь можно либо удалить курс, либо передать его другому преподавателю
                    // Для примера - удаляем
                                DeleteCourseData(course, db);
                    db.courses.Remove(course);
                            }
                }
            }
            
            // Сохраняем изменения
            db.SaveChanges();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при удалении данных пользователя: {ex.Message}", 
                               "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void DeleteCourseData(cours course)
        {
            DeleteCourseData(course, null);
        }

        private void DeleteCourseData(cours course, Entities db = null)
        {
            try
            {
                if (course == null)
                    return;
                
                bool useExistingContext = db != null;
                
                // Если контекст не был передан, создаем новый
                if (!useExistingContext)
                {
                    Entities.ResetContext();
                    db = new Entities();
                }
            
            // Удаляем модули
                var modules = db.modules.Where(m => m != null && m.course_ID == course.course_ID).ToList();
            foreach (var module in modules)
            {
                    if (module == null)
                        continue;
                        
                // Удаляем тесты модуля
                    var tests = db.tests.Where(t => t != null && t.module_ID == module.module_ID).ToList();
                foreach (var test in tests)
                {
                        if (test == null)
                            continue;
                            
                    // Удаляем результаты теста
                        var testResults = db.test_results
                            .Where(r => r != null && r.test_ID.HasValue && r.test_ID.Value == test.test_ID)
                            .ToList();
                    foreach (var result in testResults)
                    {
                            if (result != null)
                        db.test_results.Remove(result);
                    }
                    
                    db.tests.Remove(test);
                }
                
                db.modules.Remove(module);
            }
            
            // Удаляем отзывы к курсу
                var reviews = db.course_reviews.Where(r => r != null && r.course_ID == course.course_ID).ToList();
            foreach (var review in reviews)
            {
                    if (review != null)
                db.course_reviews.Remove(review);
            }
            
            // Удаляем оценки курса
                var grades = db.course_grades.Where(g => g != null && g.course_ID == course.course_ID).ToList();
            foreach (var grade in grades)
            {
                    if (grade != null)
                db.course_grades.Remove(grade);
            }
            
                // Сохраняем изменения, только если это отдельная операция
                if (!useExistingContext)
                {
            db.SaveChanges();
                    db.Dispose();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при удалении данных курса: {ex.Message}",
                               "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void ReportsButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                // Создаем и показываем окно отчетов
                var reportsWindow = new UserReportsWindow(_currentUser);
                reportsWindow.ShowDialog();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при открытии отчетов: {ex.Message}", 
                               "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void RefreshButton_Click(object sender, RoutedEventArgs e)
        {
            RefreshData();
        }

        private void AccessCodeButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                var selectedUser = usersDataGrid.SelectedItem as UserViewModel;
                if (selectedUser == null)
                {
                    MessageBox.Show("Пожалуйста, выберите пользователя.", 
                                   "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                    return;
                }

                // Проверяем, что у пользователя есть право на код доступа
                if (selectedUser.RoleID != 1 && selectedUser.RoleID != 4 && selectedUser.RoleID != 5)
                {
                    MessageBox.Show("Код доступа может быть сгенерирован только для ролей Admin, Moderator и Support.", 
                                   "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                    return;
                }

                // Получаем название роли
                string roleName = selectedUser.RoleName;

                // Генерируем код доступа
                var accessCode = new RoleAccessCode
                {
                    RoleID = selectedUser.RoleID,
                    RoleName = roleName
                };

                string code = accessCode.GenerateAccessCode();

                // Показываем код пользователю
                MessageBox.Show($"Код доступа для {selectedUser.Login} ({roleName}):\n\n{code}", 
                               "Код доступа", MessageBoxButton.OK, MessageBoxImage.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при генерации кода доступа: {ex.Message}", 
                               "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }
    }
} 