using System;
using System.Windows;
using System.Windows.Controls;

namespace online_courses
{
    public partial class ComplaintPage : Page
    {
        private user _currentUser;
        private course_reviews _review;
        private user _contentOwner;

        public ComplaintPage(user user, course_reviews review)
        {
            InitializeComponent();
            _currentUser = user;
            _review = review;
            _contentOwner = review.user;
            
            LoadContentData();
        }

        private void LoadContentData()
        {
            try
            {
                contentTypeTextBlock.Text = "Тип: Отзыв к курсу";
                contentAuthorTextBlock.Text = $"Автор: {_contentOwner.users_login}";
                contentTextTextBlock.Text = $"Содержание: {_review.review_text}";
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при загрузке данных: {ex.Message}");
            }
        }

        private void CancelButton_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.GoBack();
        }

        private void SubmitButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (complaintReasonComboBox.SelectedItem == null)
                {
                    MessageBox.Show("Пожалуйста, выберите причину жалобы.");
                    return;
                }

                if (string.IsNullOrWhiteSpace(complaintDescriptionTextBox.Text))
                {
                    MessageBox.Show("Пожалуйста, опишите проблему.");
                    return;
                }

                string reason = ((ComboBoxItem)complaintReasonComboBox.SelectedItem).Content.ToString();
                string description = complaintDescriptionTextBox.Text;

                // Создаем новую жалобу
                var complaint = new complaint
                {
                    complaint_type = "review",
                    target_ID = _review.review_ID,
                    users_ID = _currentUser.users_ID,
                    complaint_text = $"Причина: {reason}\nОписание: {description}",
                    complaint_date = DateTime.Now.Date,
                    status = "На рассмотрении"
                };

                try
                {
                    var context = Entities.GetContext();
                    context.complaints.Add(complaint);
                    
                    // Проверяем, что жалоба действительно добавлена в контекст
                    if (!context.complaints.Local.Contains(complaint))
                    {
                        MessageBox.Show("Ошибка: жалоба не была добавлена в контекст базы данных");
                        return;
                    }

                    // Пробуем сохранить изменения
                    int result = context.SaveChanges();
                    
                    if (result > 0)
                    {
                        MessageBox.Show($"Жалоба успешно отправлена. ID: {complaint.complaint_ID}");
                        NavigationService.GoBack();
                    }
                    else
                    {
                        MessageBox.Show("Ошибка: изменения не были сохранены в базе данных");
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Ошибка при сохранении жалобы: {ex.Message}\n\nВнутреннее исключение: {ex.InnerException?.Message}");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при отправке жалобы: {ex.Message}");
            }
        }
    }
} 