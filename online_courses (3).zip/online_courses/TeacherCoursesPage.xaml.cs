using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Controls;

namespace online_courses
{
    public partial class TeacherCoursesPage : Page, IPageRefresh
    {
        private user _currentUser;
        private List<cours> _allCourses;

        // Класс для отображения информации о курсе
        private class CourseViewModel
        {
            public int course_ID { get; set; }
            public string course_name { get; set; }
            public string course_description { get; set; }
            public category category { get; set; }
            public double AverageRating { get; set; }
            public int StudentsCount { get; set; }
        }

        public TeacherCoursesPage(user user)
        {
            InitializeComponent();
            _currentUser = user ?? throw new ArgumentNullException(nameof(user));
            RefreshData();
        }

        public void RefreshData()
        {
            try
            {
                // Сбрасываем контекст для получения свежих данных
                Entities.ResetContext();

                using (var context = new Entities())
                {
                    // Убедимся, что все кэшированные изменения сбрасываются
                    context.Dispose();
                }

                using (var newContext = new Entities())
                {
                    // Получаем все курсы текущего преподавателя с дополнительной информацией
                    var coursesWithInfo = newContext.courses
                        .Where(c => c.course_author == _currentUser.users_ID)
                        .Select(c => new CourseViewModel
                        {
                            course_ID = c.course_ID,
                            course_name = c.course_name,
                            course_description = c.course_description,
                            category = c.category,
                            // Вычисляем средний рейтинг
                            AverageRating = newContext.course_reviews
                                .Where(r => r.course_ID == c.course_ID)
                                .Select(r => (double?)r.rating)
                                .DefaultIfEmpty()
                                .Average() ?? 0.0,
                            // Подсчитываем количество студентов
                            StudentsCount = newContext.course_grades
                                .Count(cg => cg.course_ID == c.course_ID)
                        })
                        .ToList();

                    _allCourses = coursesWithInfo
                        .Select(cvm => new cours
                        {
                            course_ID = cvm.course_ID,
                            course_name = cvm.course_name,
                            course_description = cvm.course_description,
                            category = cvm.category,
                            course_author = _currentUser.users_ID
                        })
                        .ToList();

                    // Применяем фильтры
                    ApplyFilters(coursesWithInfo);

                    // Показываем сообщение, если у преподавателя нет курсов
                    bool hasAnyCourses = coursesWithInfo.Any();
                    coursesListView.Visibility = hasAnyCourses ? Visibility.Visible : Visibility.Collapsed;
                    noCourseTextBlock.Visibility = hasAnyCourses ? Visibility.Collapsed : Visibility.Visible;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при загрузке курсов: {ex.Message}\n\nStackTrace: {ex.StackTrace}");
            }
        }

        private void ApplyFilters(List<CourseViewModel> courses = null)
        {
            try
            {
                if (courses == null)
                {
                    using (var context = new Entities())
                    {
                        courses = context.courses
                            .Where(c => c.course_author == _currentUser.users_ID)
                            .Select(c => new CourseViewModel
                            {
                                course_ID = c.course_ID,
                                course_name = c.course_name,
                                course_description = c.course_description,
                                category = c.category,
                                AverageRating = context.course_reviews
                                    .Where(r => r.course_ID == c.course_ID)
                                    .Select(r => (double?)r.rating)
                                    .DefaultIfEmpty()
                                    .Average() ?? 0.0,
                                StudentsCount = context.course_grades
                                    .Count(cg => cg.course_ID == c.course_ID)
                            })
                            .ToList();
                    }
                }

                // Применяем фильтр по поисковому запросу
                var filteredCourses = courses;
                string searchText = searchTextBox?.Text?.ToLower() ?? string.Empty;

                if (!string.IsNullOrWhiteSpace(searchText))
                {
                    filteredCourses = courses
                        .Where(c => (c.course_name?.ToLower().Contains(searchText) ?? false) ||
                                  (c.course_description?.ToLower().Contains(searchText) ?? false))
                        .ToList();
                }

                coursesListView.ItemsSource = filteredCourses;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при применении фильтров: {ex.Message}\n\nStackTrace: {ex.StackTrace}");
            }
        }

        private void SearchTextBox_TextChanged(object sender, TextChangedEventArgs e)
        {
            ApplyFilters();
        }

        private void SearchButton_Click(object sender, RoutedEventArgs e)
        {
            ApplyFilters();
        }

        private void CreateCourseButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                NavigationService.Navigate(new CourseCreationPage(_currentUser));
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при переходе к созданию курса: {ex.Message}");
            }
        }

        private void CoursesListView_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            // Можно добавить дополнительную логику при необходимости
        }

        private void EditCourseButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (sender is Button button && button.Tag is int courseId)
                {
                    var selectedCourse = _allCourses?.FirstOrDefault(c => c.course_ID == courseId);
                    if (selectedCourse != null)
                    {
                        // Создаем безопасную копию курса для редактирования
                        var courseCopy = new cours
                        {
                            course_ID = selectedCourse.course_ID,
                            course_name = selectedCourse.course_name,
                            course_description = selectedCourse.course_description,
                            course_author = selectedCourse.course_author,
                            course_category = selectedCourse.course_category
                        };

                        NavigationService.Navigate(new CourseEditPage(_currentUser, courseCopy));
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при переходе к редактированию курса: {ex.Message}");
            }
        }

        private void ReportsButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (sender is Button button && button.Tag is int courseId)
                {
                    var selectedCourse = _allCourses?.FirstOrDefault(c => c.course_ID == courseId);
                    if (selectedCourse != null)
                    {
                        // Создаем безопасную копию курса для отчетов
                        var courseCopy = new cours
                        {
                            course_ID = selectedCourse.course_ID,
                            course_name = selectedCourse.course_name,
                            course_description = selectedCourse.course_description,
                            course_author = selectedCourse.course_author,
                            course_category = selectedCourse.course_category
                        };

                        NavigationService.Navigate(new CourseReportsPage(_currentUser, courseCopy));
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при переходе к отчетам курса: {ex.Message}");
            }
        }

        private void DeleteCourseButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (sender is Button button && button.Tag is int courseId)
                {
                    var selectedCourse = _allCourses?.FirstOrDefault(c => c.course_ID == courseId);
                    if (selectedCourse != null)
                    {
                        // Запрашиваем подтверждение удаления
                        var confirmResult = MessageBox.Show(
                            "Вы действительно хотите удалить этот курс? Будут также удалены все связанные модули, тесты и результаты студентов. Это действие нельзя отменить.",
                            "Подтверждение удаления",
                            MessageBoxButton.YesNo,
                            MessageBoxImage.Warning);

                        if (confirmResult == MessageBoxResult.Yes)
                        {
                            using (var context = new Entities())
                            {
                                // Находим курс в базе данных
                                var courseToDelete = context.courses.FirstOrDefault(c => c.course_ID == courseId);
                                if (courseToDelete != null)
                                {
                                    // Находим все модули курса
                                    var modules = context.modules.Where(m => m.course_ID == courseId).ToList();
                                    
                                    foreach (var module in modules)
                                    {
                                        // Находим связанные тесты
                                        var tests = context.tests.Where(t => t.module_ID == module.module_ID).ToList();
                                        
                                        // Удаляем результаты тестов
                                        foreach (var test in tests)
                                        {
                                            var testResults = context.test_results.Where(tr => tr.test_ID == test.test_ID).ToList();
                                            foreach (var testResult in testResults)
                                            {
                                                context.test_results.Remove(testResult);
                                            }
                                            
                                            // Удаляем сам тест
                                            context.tests.Remove(test);
                                        }
                                        
                                        // Удаляем модуль
                                        context.modules.Remove(module);
                                    }
                                    
                                    // Удаляем оценки курса
                                    var courseGrades = context.course_grades.Where(cg => cg.course_ID == courseId).ToList();
                                    foreach (var grade in courseGrades)
                                    {
                                        context.course_grades.Remove(grade);
                                    }
                                    
                                    // Удаляем отзывы о курсе
                                    var courseReviews = context.course_reviews.Where(cr => cr.course_ID == courseId).ToList();
                                    foreach (var review in courseReviews)
                                    {
                                        context.course_reviews.Remove(review);
                                    }
                                    
                                    // Удаляем экзамены курса
                                    var exams = context.exams.Where(exam => exam.course_ID == courseId).ToList();
                                    foreach (var exam in exams)
                                    {
                                        // Создаем локальную переменную для ID экзамена
                                        int examIdLocal = exam.exam_ID;
                                        
                                        // Удаляем результаты экзаменов - загружаем все и фильтруем в памяти
                                        var allExamResults = context.exam_results.ToList();
                                        var examResults = allExamResults.Where(er => er.exam_ID == examIdLocal).ToList();
                                        foreach (var examResult in examResults)
                                        {
                                            context.exam_results.Remove(examResult);
                                        }
                                        
                                        // Удаляем сам экзамен
                                        context.exams.Remove(exam);
                                    }

                                    // Удаляем сам курс
                                    context.courses.Remove(courseToDelete);
                                    context.SaveChanges();

                                    MessageBox.Show("Курс успешно удален");
                                    
                                    // Обновляем список курсов
                                    RefreshData();
                                }
                                else
                                {
                                    MessageBox.Show("Курс не найден в базе данных.");
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при удалении курса: {ex.Message}");
            }
        }
    }
}