using System;
using System.Globalization;
using System.Windows.Data;
using System.Windows.Media;

namespace online_courses
{
    /// <summary>
    /// Конвертер для преобразования роли пользователя в соответствующий цвет
    /// Используется в чате для отображения имени отправителя разным цветом в зависимости от роли
    /// </summary>
    public class RoleToColorConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            if (value is string role)
            {
                switch (role.ToLower())
                {
                    case "admin":
                    case "администратор":
                        return new SolidColorBrush(Colors.Red);
                        
                    case "teacher":
                    case "преподаватель":
                        return new SolidColorBrush(Colors.Blue);
                        
                    case "moderator":
                    case "модератор":
                        return new SolidColorBrush(Colors.Purple);
                        
                    case "support":
                    case "поддержка":
                        return new SolidColorBrush(Colors.Green);
                        
                    case "student":
                    case "студент":
                    default:
                        return new SolidColorBrush(Colors.Black);
                }
            }
            
            return new SolidColorBrush(Colors.Black);
        }

        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            throw new NotImplementedException();
        }
    }
} 