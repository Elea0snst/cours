using System;
using System.Linq;
using System.Windows;
using System.Windows.Controls;

namespace online_courses
{
    public partial class CourseDetailsPage : Page
    {
        private user _currentUser;
        private cours _course;
        private bool _isEnrolled;

        public CourseDetailsPage(user user, cours course)
        {
            InitializeComponent();
            _currentUser = user;
            _course = course;
            
            // Обновляем базу данных
            Entities.ResetContext();
            
            LoadCourseData();
            CheckEnrollmentStatus();
            LoadModules();
            LoadReviews();
        }

        private void LoadCourseData()
        {
            try
            {
                courseNameTextBlock.Text = _course.course_name;
                courseDescriptionTextBlock.Text = _course.course_description;
                authorTextBlock.Text = _course.user?.users_login ?? "Не указан";
                categoryTextBlock.Text = _course.category?.category_name ?? "Не указана";
                
                // Используем локальный контекст вместо глобального
                using (var context = new Entities())
                {
                    // Вычисляем рейтинг на основе отзывов, так как в cours нет свойства course_rating
                    var reviews = context.course_reviews.Where(r => r.course_ID == _course.course_ID);
                    if (reviews.Any())
                    {
                        double avgRating = reviews.Average(r => r.rating);
                        ratingTextBlock.Text = avgRating.ToString("0.0");
                    }
                    else
                    {
                        ratingTextBlock.Text = "Нет оценок";
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при загрузке данных курса: {ex.Message}");
            }
        }

        private void CheckEnrollmentStatus()
        {
            try
            {
                bool isEnrolled = false;
                
                // Используем локальный контекст вместо глобального
                using (var context = new Entities())
                {
                    // Проверяем, записан ли уже студент на курс
                    isEnrolled = context.course_grades
                        .Any(cg => cg.course_ID == _course.course_ID && cg.users_ID == _currentUser.users_ID);
                }
                
                _isEnrolled = isEnrolled;

                if (isEnrolled)
                {
                    enrollButton.Visibility = Visibility.Collapsed;
                    continueButton.Visibility = Visibility.Visible;
                    startCourseButton.Visibility = Visibility.Visible;
                }
                else
                {
                    enrollButton.Visibility = Visibility.Visible;
                    continueButton.Visibility = Visibility.Collapsed;
                    startCourseButton.Visibility = Visibility.Collapsed;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при проверке статуса записи: {ex.Message}");
            }
        }

        private void LoadModules()
        {
            try
            {
                // Используем локальный контекст вместо глобального
                using (var context = new Entities())
                {
                    var modules = context.modules.Where(m => m.course_ID == _course.course_ID).ToList();
                    modulesListView.ItemsSource = modules;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при загрузке модулей: {ex.Message}");
            }
        }

        private void LoadReviews()
        {
            try
            {
                // Используем локальный контекст вместо глобального
                using (var context = new Entities())
                {
                    var reviews = context.course_reviews
                        .Where(r => r.course_ID == _course.course_ID)
                        .OrderByDescending(r => r.review_date)
                        .ToList();
                    
                    reviewsListView.ItemsSource = reviews;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при загрузке отзывов: {ex.Message}");
            }
        }

        private void BackButton_Click(object sender, RoutedEventArgs e)
        {
            // Переходим на страницу "Мои курсы" вместо перехода назад
            NavigationService.Navigate(new MyCoursesPage(_currentUser));
        }

        private void EnrollButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                // Проверка на null
                if (_course == null || _currentUser == null)
                {
                    MessageBox.Show("Ошибка: информация о курсе или пользователе отсутствует.");
                    return;
                }

                // Используем локальный контекст вместо глобального
                using (var context = new Entities())
                {
                    // Записываем студента на курс
                    var courseGrade = new course_grades
                    {
                        course_ID = _course.course_ID,
                        users_ID = _currentUser.users_ID,
                        grade = 0, // Используем 0 как начальное значение вместо null, т.к. grade не nullable
                        grade_date = DateTime.Now // Используем grade_date как дату записи на курс
                    };

                    context.course_grades.Add(courseGrade);
                    context.SaveChanges();
                }

                MessageBox.Show("Вы успешно записались на курс!");
                CheckEnrollmentStatus();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при записи на курс: {ex.Message}");
            }
        }

        private void ContinueButton_Click(object sender, RoutedEventArgs e)
        {
            NavigateToCourseContent();
        }

        private void StartCourseButton_Click(object sender, RoutedEventArgs e)
        {
            NavigateToCourseContent();
        }

        private void NavigateToCourseContent()
        {
            try
            {
                // Проверка на null
                if (_course == null || _currentUser == null)
                {
                    MessageBox.Show("Ошибка: информация о курсе или пользователе отсутствует.");
                    return;
                }

                // Загружаем свежие данные о курсе из базы перед навигацией
                cours courseToNavigate = null;
                
                using (var context = new Entities())
                {
                    // Получаем свежие данные о курсе
                    var dbCourse = context.courses.FirstOrDefault(c => c.course_ID == _course.course_ID);
                    
                    if (dbCourse != null)
                    {
                        // Предзагружаем необходимые данные
                        var modules = context.modules
                            .Where(m => m.course_ID == dbCourse.course_ID)
                            .ToList();
                            
                        // Загружаем другие связанные данные если необходимо
                        
                        // Создаем полностью независимую копию объекта курса
                        courseToNavigate = new cours
                        {
                            course_ID = dbCourse.course_ID,
                            course_name = dbCourse.course_name,
                            course_description = dbCourse.course_description,
                            course_author = dbCourse.course_author,
                            course_category = dbCourse.course_category
                        };
                    }
                }
                
                // Сбрасываем контекст перед навигацией
                Entities.ResetContext();
                
                // Навигация только после закрытия контекста
                if (courseToNavigate != null)
                {
                    NavigationService.Navigate(new CourseContentPage(_currentUser, courseToNavigate));
                }
                else
                {
                    MessageBox.Show("Ошибка: не удалось загрузить данные о курсе для навигации.");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при переходе к содержимому курса: {ex.Message}\n\nStackTrace: {ex.StackTrace}");
            }
        }

        private void ModulesListView_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (!_isEnrolled)
            {
                MessageBox.Show("Для просмотра модулей запишитесь на курс.");
                modulesListView.SelectedItem = null;
                return;
            }

            if (modulesListView.SelectedItem is module selectedModule)
            {
                // Проверка на null
                if (_course == null || _currentUser == null)
                {
                    MessageBox.Show("Ошибка: информация о курсе или пользователе отсутствует.");
                    modulesListView.SelectedItem = null;
                    return;
                }

                try
                {
                    // Загружаем свежие данные о модуле из базы перед навигацией
                    module moduleToNavigate = null;
                    
                    using (var context = new Entities())
                    {
                        // Получаем свежие данные о модуле
                        moduleToNavigate = context.modules.FirstOrDefault(m => m.module_ID == selectedModule.module_ID);
                        
                        // Предзагружаем необходимые данные если нужно
                    }
                    
                    // Навигация только после закрытия контекста
                    if (moduleToNavigate != null)
                    {
                        NavigationService.Navigate(new ModuleContentPage(_currentUser, _course, moduleToNavigate));
                    }
                    else
                    {
                        MessageBox.Show("Ошибка: не удалось загрузить данные о модуле для навигации.");
                        modulesListView.SelectedItem = null;
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Ошибка при переходе к содержимому модуля: {ex.Message}");
                    modulesListView.SelectedItem = null;
                }
            }
        }

        private void AddReviewButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (!_isEnrolled)
                {
                    MessageBox.Show("Только записанные на курс студенты могут оставлять отзывы.");
                    return;
                }

                if (ratingComboBox.SelectedItem == null)
                {
                    MessageBox.Show("Пожалуйста, выберите оценку.");
                    return;
                }

                if (string.IsNullOrWhiteSpace(reviewTextBox.Text))
                {
                    MessageBox.Show("Пожалуйста, напишите текст отзыва.");
                    return;
                }

                int rating = int.Parse(((ComboBoxItem)ratingComboBox.SelectedItem).Content.ToString());

                // Используем локальный контекст вместо глобального
                using (var context = new Entities())
                {
                    // Проверяем, не оставлял ли студент уже отзыв на этот курс
                    var existingReview = context.course_reviews
                        .FirstOrDefault(r => r.course_ID == _course.course_ID && r.users_ID == _currentUser.users_ID);

                    if (existingReview != null)
                    {
                        // Обновляем существующий отзыв
                        existingReview.review_text = reviewTextBox.Text;
                        existingReview.rating = rating;
                        existingReview.review_date = DateTime.Now;
                    }
                    else
                    {
                        // Создаем новый отзыв
                        var newReview = new course_reviews
                        {
                            course_ID = _course.course_ID,
                            users_ID = _currentUser.users_ID,
                            review_text = reviewTextBox.Text,
                            rating = rating,
                            review_date = DateTime.Now
                        };

                        context.course_reviews.Add(newReview);
                    }
                    
                    // Сохраняем изменения
                    context.SaveChanges();
                }

                MessageBox.Show("Ваш отзыв успешно отправлен!");
                reviewTextBox.Text = "";
                ratingComboBox.SelectedIndex = -1;
                
                // Обновляем список отзывов и данные курса после успешного добавления отзыва
                LoadReviews();
                LoadCourseData(); // Это обновит и отображение рейтинга
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при отправке отзыва: {ex.Message}");
            }
        }

        private void ComplaintButton_Click(object sender, RoutedEventArgs e)
        {
            if (sender is Button button && button.Tag is int reviewId)
            {
                using (var context = new Entities())
                {
                    var review = context.course_reviews.FirstOrDefault(r => r.review_ID == reviewId);
                    if (review != null)
                    {
                        NavigationService.Navigate(new ComplaintPage(_currentUser, review));
                    }
                }
            }
        }
    }
} 