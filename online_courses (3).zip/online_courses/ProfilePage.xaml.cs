using System;
using System.Linq;
using System.Windows;
using System.Windows.Controls;

namespace online_courses
{
    public partial class ProfilePage : Page, IPageRefresh
    {
        private user _currentUser;
        private user_profiles _userProfile;

        public ProfilePage(user user)
        {
            InitializeComponent();
            _currentUser = user;
            RefreshData();
        }

        public void RefreshData()
        {
            try
            {
                // Загружаем профиль пользователя
                _userProfile = Entities.GetContext().user_profiles
                    .FirstOrDefault(up => up.users_ID == _currentUser.users_ID);

                if (_userProfile == null)
                {
                    // Создаем новый профиль, если он отсутствует
                    _userProfile = new user_profiles
                    {
                        users_ID = _currentUser.users_ID,
                        users_name = "",
                        users_surname = "",
                        users_patronymic = "",
                        users_email = "",
                        users_phone = ""
                    };
                    Entities.GetContext().user_profiles.Add(_userProfile);
                    Entities.GetContext().SaveChanges();
                }

                // Заполняем поля формы
                firstNameTextBox.Text = _userProfile.users_name ?? "";
                lastNameTextBox.Text = _userProfile.users_surname ?? "";
                patronymicTextBox.Text = _userProfile.users_patronymic ?? "";
                loginTextBox.Text = _currentUser.users_login;
                emailTextBox.Text = _userProfile.users_email ?? "";
                phoneTextBox.Text = _userProfile.users_phone ?? "";
                
                var role = Entities.GetContext().roles.FirstOrDefault(r => r.role_ID == _currentUser.users_role_ID);
                roleTextBox.Text = role?.role_name ?? "Не определена";
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при загрузке профиля: {ex.Message}");
            }
        }

        private void SaveProfileButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                // Обновляем данные профиля
                _userProfile.users_name = firstNameTextBox.Text;
                _userProfile.users_surname = lastNameTextBox.Text;
                _userProfile.users_patronymic = patronymicTextBox.Text;
                _userProfile.users_email = emailTextBox.Text;
                _userProfile.users_phone = phoneTextBox.Text;

                Entities.GetContext().SaveChanges();
                MessageBox.Show("Данные профиля успешно сохранены!");
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при сохранении профиля: {ex.Message}");
            }
        }

        private void ChangePasswordButton_Click(object sender, RoutedEventArgs e)
        {
            // Здесь будет реализация изменения пароля
            MessageBox.Show("Функция изменения пароля будет доступна в следующей версии!");
        }
    }
} 