﻿using System;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Text.RegularExpressions;
using System.Windows;
using System.Windows.Controls;

namespace online_courses
{
    public partial class RegisterPage : Window
    {
        public RegisterPage()
        {
            InitializeComponent();
            registerButton.IsEnabled = false;
            Loaded += RegisterPage_Loaded;
        }

        private void RegisterPage_Loaded(object sender, RoutedEventArgs e)
        {
            registerButton.IsEnabled = true;
        }

        private void RegisterButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                string login = loginTextBox.Text.Trim();
                string password = passwordBox.Password.Trim();
                string confirmPassword = confirmPasswordBox.Password.Trim();
                int roleId = studentRadioButton.IsChecked == true ? 3 : 2;

                // Валидация
                if (string.IsNullOrEmpty(login) || string.IsNullOrEmpty(password) || string.IsNullOrEmpty(confirmPassword))
                {
                    MessageBox.Show("Все поля должны быть заполнены.");
                    return;
                }

                if (login.Length < 6 || login.Length > 20)
                {
                    MessageBox.Show("Логин должен содержать от 6 до 20 символов.");
                    return;
                }

                if (password.Length < 8 || password.Length > 20)
                {
                    MessageBox.Show("Пароль должен содержать от 8 до 20 символов.");
                    return;
                }

                if (password != confirmPassword)
                {
                    MessageBox.Show("Пароли не совпадают.");
                    return;
                }

                if (!Regex.IsMatch(login, @"^[a-zA-Z0-9]+$"))
                {
                    MessageBox.Show("Логин должен содержать только латинские буквы и цифры.");
                    return;
                }

                if (!Regex.IsMatch(password, @"^(?=.*[a-zA-Z])(?=.*\d).+$"))
                {
                    MessageBox.Show("Пароль должен содержать хотя бы одну букву и одну цифру.");
                    return;
                }

                if (login.Contains(" ") || password.Contains(" "))
                {
                    MessageBox.Show("Логин и пароль не должны содержать пробелов.");
                    return;
                }

                if (Regex.IsMatch(login, @"[а-яА-Я]") || Regex.IsMatch(password, @"[а-яА-Я]"))
                {
                    MessageBox.Show("Логин и пароль должны содержать только латинские буквы.");
                    return;
                }

                using (var context = Entities.GetContext())
                {
                    if (context.users.Any(u => u.users_login == login))
                    {
                        MessageBox.Show("Логин уже занят.");
                        return;
                    }

                    var user = new user
                    {
                        users_login = login,
                        users_password = GetHash(password),
                        users_role_ID = roleId,
                        access_code = null
                    };

                    context.users.Add(user);
                    context.SaveChanges();
                }

                MessageBox.Show("Регистрация прошла успешно!");
                NavigateToLoginPage();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка: {ex.Message}");
            }
        }

        private void BackButton_Click(object sender, RoutedEventArgs e)
        {
            NavigateToLoginPage();
        }

        private void NavigateToLoginPage()
        {
            try
            {
                var loginPage = new LoginPage();
                loginPage.Show();
                this.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при переходе на страницу входа: {ex.Message}");
            }
        }

        private string GetHash(string input)
        {
            using (SHA256 sha256Hash = SHA256.Create())
            {
                byte[] bytes = sha256Hash.ComputeHash(Encoding.UTF8.GetBytes(input));
                StringBuilder builder = new StringBuilder();
                for (int i = 0; i < bytes.Length; i++)
                {
                    builder.Append(bytes[i].ToString("x2"));
                }
                return builder.ToString();
            }
        }

        private void ShowPasswordToggle_Click(object sender, RoutedEventArgs e)
        {
            if (showPasswordToggle.IsChecked == true)
            {
                ShowPassword(passwordBox);
                ShowPassword(confirmPasswordBox);
            }
            else
            {
                HidePassword(passwordBox);
                HidePassword(confirmPasswordBox);
            }
        }

        private void ShowPassword(PasswordBox passwordBox)
        {
            var textBox = new TextBox
            {
                Text = passwordBox.Password,
                Width = passwordBox.Width,
                VerticalAlignment = VerticalAlignment.Center
            };
            passwordBox.Tag = textBox;
            ((StackPanel)passwordBox.Parent).Children.Insert(0, textBox);
            passwordBox.Visibility = Visibility.Collapsed;
        }

        private void HidePassword(PasswordBox passwordBox)
        {
            var textBox = (TextBox)passwordBox.Tag;
            passwordBox.Password = textBox.Text;
            ((StackPanel)passwordBox.Parent).Children.Remove(textBox);
            passwordBox.Visibility = Visibility.Visible;
        }
    }
}