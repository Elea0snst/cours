﻿using System;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Text.RegularExpressions;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;

namespace online_courses
{
    public partial class LoginPage : Window
    {
        private int _failedAttempts = 0;
        private string _currentCaptchaText = "";
        private const int MaxAttemptsBeforeCaptcha = 3;
        private const int MinLoginLength = 6;
        private const int MaxLoginLength = 20;
        private const int MinPasswordLength = 8;
        private const int MaxPasswordLength = 20;

        public LoginPage()
        {
            InitializeComponent();
            captchaPanel.Visibility = Visibility.Collapsed;
            attemptsTextBlock.Visibility = Visibility.Collapsed;
        }

        private void LoginButton_Click(object sender, RoutedEventArgs e)
        {
            string login = loginTextBox.Text.Trim();
            string password = passwordBox.Password.Trim();

            if (!ValidateCredentials(login, password))
            {
                MessageBox.Show("Неверные учетные данные. Проверьте введенные данные.");
                return;
            }

            if (captchaPanel.Visibility == Visibility.Visible && !ValidateCaptcha())
            {
                MessageBox.Show("Неверно введена CAPTCHA. Попробуйте снова.");
                return;
            }

            try
            {
                using (var context = new Entities())
                {
                    string hashedPassword = GetHash(password);
                    if (hashedPassword == null) return;

                    var user = context.users.FirstOrDefault(u =>
                        u.users_login == login &&
                        u.users_password == hashedPassword);

                    if (user != null)
                    {
                        // Перенаправляем пользователя в зависимости от его роли
                        NavigateBasedOnRole(user);
                    }
                    else
                    {
                        HandleFailedAttempt();
                        MessageBox.Show("Неверный логин или пароль");
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при входе: {ex.Message}");
            }
        }

        private void NavigateBasedOnRole(user user)
        {
            try
            {
                Window nextWindow = null;

                // Определяем роль пользователя и открываем соответствующее окно
                switch (user.users_role_ID)
                {
                    case 1: // Администратор
                        nextWindow = new AdminPage(user);
                        break;
                    case 2: // Преподаватель
                        nextWindow = new TeacherPage(user);
                        break;
                    case 3: // Студент
                        nextWindow = new StudentPage(user);
                        break;
                    case 4: // Модератор
                        nextWindow = new ModeratorPage(user);
                        break;
                    case 5: // Оператор технической поддержки
                        nextWindow = new SupportPage(user);
                        break;
                    default:
                        MessageBox.Show("Не удалось определить роль пользователя.");
                        return;
                }

                if (nextWindow != null)
                {
                    nextWindow.Show();
                    this.Close();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при перенаправлении: {ex.Message}");
            }
        }

        private bool ValidateCredentials(string login, string password)
        {
            if (string.IsNullOrWhiteSpace(login)) return false;
            if (string.IsNullOrWhiteSpace(password)) return false;
            if (login.Length < MinLoginLength || login.Length > MaxLoginLength) return false;
            if (password.Length < MinPasswordLength || password.Length > MaxPasswordLength) return false;
            if (!Regex.IsMatch(login, @"^[a-zA-Z0-9]+$")) return false;
            return true;
        }

        private bool ValidateCaptcha()
        {
            return captchaTextBox.Text == _currentCaptchaText;
        }

        private void HandleFailedAttempt()
        {
            _failedAttempts++;
            attemptsTextBlock.Text = $"Неверная попытка входа ({_failedAttempts} из {MaxAttemptsBeforeCaptcha})";
            attemptsTextBlock.Visibility = Visibility.Visible;

            if (_failedAttempts >= MaxAttemptsBeforeCaptcha)
            {
                GenerateCaptcha();
                captchaPanel.Visibility = Visibility.Visible;
                captchaTextBox.Focus();
            }
        }

        private void GenerateCaptcha()
        {
            captchaCanvas.Children.Clear();
            const string chars = "ABCDEFGHJKLMNPQRSTUVWXYZabcdefghjkmnpqrstuvwxyz23456789";
            var random = new Random();
            _currentCaptchaText = new string(Enumerable.Repeat(chars, 6)
                .Select(s => s[random.Next(s.Length)]).ToArray());

            for (int i = 0; i < _currentCaptchaText.Length; i++)
            {
                var textBlock = new TextBlock
                {
                    Text = _currentCaptchaText[i].ToString(),
                    FontSize = 20 + random.Next(5),
                    FontWeight = FontWeights.Bold,
                    Foreground = new SolidColorBrush(Color.FromRgb(
                        (byte)random.Next(100, 200),
                        (byte)random.Next(100, 200),
                        (byte)random.Next(100, 200)))
                };
                Canvas.SetLeft(textBlock, 10 + i * 30 + random.Next(-5, 5));
                Canvas.SetTop(textBlock, 15 + random.Next(-10, 10));
                captchaCanvas.Children.Add(textBlock);
            }
            captchaTextBox.Text = "";
        }

        private void ShowPasswordToggle_Click(object sender, RoutedEventArgs e)
        {
            if (showPasswordToggle.IsChecked == true)
                ShowPassword(passwordBox);
            else
                HidePassword(passwordBox);
        }

        private void RegisterButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                var registerWindow = new RegisterPage();
                registerWindow.Show();
                this.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при открытии страницы регистрации: {ex.Message}");
            }
        }
        private void ShowPassword(PasswordBox passwordBox)
        {
            var textBox = new TextBox
            {
                Text = passwordBox.Password,
                Width = passwordBox.Width,
                VerticalAlignment = VerticalAlignment.Center
            };
            passwordBox.Tag = textBox;
            ((StackPanel)passwordBox.Parent).Children.Insert(0, textBox);
            passwordBox.Visibility = Visibility.Collapsed;
        }

        private void HidePassword(PasswordBox passwordBox)
        {
            if (passwordBox.Tag is TextBox textBox)
            {
                passwordBox.Password = textBox.Text;
                ((StackPanel)passwordBox.Parent).Children.Remove(textBox);
                passwordBox.Visibility = Visibility.Visible;
            }
        }

        private static string GetHash(string input)
        {
            using (SHA256 sha256Hash = SHA256.Create())
            {
                byte[] bytes = sha256Hash.ComputeHash(Encoding.UTF8.GetBytes(input));
                StringBuilder builder = new StringBuilder();
                foreach (byte b in bytes)
                {
                    builder.Append(b.ToString("x2"));
                }
                return builder.ToString();
            }
        }
    }
}