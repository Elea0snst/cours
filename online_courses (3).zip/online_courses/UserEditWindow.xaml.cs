using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;
using System.Windows;

namespace online_courses
{
    public partial class UserEditWindow : Window
    {
        private UserViewModel _userViewModel;
        private user _originalUser;
        private List<role> _roles;

        public UserEditWindow(UserViewModel userViewModel)
        {
            InitializeComponent();
            
            _userViewModel = userViewModel ?? throw new ArgumentNullException(nameof(userViewModel));
            
            // Загружаем данные
            LoadData();
        }

        private void LoadData()
        {
            try
            {
                // Сбрасываем контекст
                Entities.ResetContext();
                
                using (var context = new Entities())
                {
                    // Загружаем оригинального пользователя из базы данных
                    _originalUser = context.users.FirstOrDefault(u => u.users_ID == _userViewModel.UsersID);
                    if (_originalUser == null)
                    {
                        MessageBox.Show("Пользователь не найден в базе данных.", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                        this.Close();
                        return;
                    }
                    
                    // Загружаем роли
                    _roles = context.roles.ToList();
                    
                    // Загружаем профиль пользователя
                    var profile = context.user_profiles.FirstOrDefault(p => p.users_ID == _originalUser.users_ID);
                    
                    // Заполняем поля формы
                    userIdTextBox.Text = _originalUser.users_ID.ToString();
                    loginTextBox.Text = _originalUser.users_login;
                    
                    // Настраиваем комбобокс ролей
                    roleComboBox.ItemsSource = _roles;
                    roleComboBox.SelectedValue = _originalUser.users_role_ID;
                    
                    // Заполняем данные профиля, если они есть
                    if (profile != null)
                    {
                        emailTextBox.Text = profile.users_email ?? "";
                        nameTextBox.Text = profile.users_name ?? "";
                        surnameTextBox.Text = profile.users_surname ?? "";
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при загрузке данных пользователя: {ex.Message}", 
                               "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                this.DialogResult = false;
                this.Close();
            }
        }

        private void SaveButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                // Проверяем, что логин не пустой
                if (string.IsNullOrWhiteSpace(loginTextBox.Text))
                {
                    MessageBox.Show("Логин не может быть пустым.", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                    loginTextBox.Focus();
                    return;
                }
                
                // Проверяем, что роль выбрана
                if (roleComboBox.SelectedValue == null)
                {
                    MessageBox.Show("Необходимо выбрать роль.", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                    roleComboBox.Focus();
                    return;
                }
                
                // Проверяем формат email, если он указан
                if (!string.IsNullOrWhiteSpace(emailTextBox.Text))
                {
                    string emailPattern = @"^[^@\s]+@[^@\s]+\.[^@\s]+$";
                    if (!Regex.IsMatch(emailTextBox.Text, emailPattern))
                    {
                        MessageBox.Show("Указан некорректный формат email.", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                        emailTextBox.Focus();
                        return;
                    }
                }
                
                // Проверяем пароли
                string newPassword = passwordBox.Password;
                string confirmPassword = confirmPasswordBox.Password;
                
                if (!string.IsNullOrEmpty(newPassword))
                {
                    // Проверяем, что пароль не слишком короткий
                    if (newPassword.Length < 6)
                    {
                        MessageBox.Show("Пароль должен содержать не менее 6 символов.", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                        passwordBox.Focus();
                        return;
                    }
                    
                    // Проверяем совпадение паролей
                    if (newPassword != confirmPassword)
                    {
                        MessageBox.Show("Пароли не совпадают.", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                        confirmPasswordBox.Focus();
                        return;
                    }
                }
                
                // Сохраняем изменения
                SaveChanges(newPassword);
                
                this.DialogResult = true;
                this.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при сохранении данных: {ex.Message}", 
                               "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void SaveChanges(string newPassword)
        {
            // Сбрасываем контекст перед сохранением
            Entities.ResetContext();
            
            using (var context = new Entities())
            {
                // Получаем пользователя из базы данных
                var user = context.users.FirstOrDefault(u => u.users_ID == _originalUser.users_ID);
                if (user == null)
                {
                    throw new InvalidOperationException("Пользователь не найден в базе данных.");
                }
                
                // Обновляем основные данные пользователя
                user.users_login = loginTextBox.Text;
                user.users_role_ID = (int)roleComboBox.SelectedValue;
                
                // Обновляем пароль, если он указан
                if (!string.IsNullOrEmpty(newPassword))
                {
                    user.users_password = newPassword;
                }
                
                // Получаем или создаем профиль пользователя
                var profile = context.user_profiles.FirstOrDefault(p => p.users_ID == user.users_ID);
                if (profile == null)
                {
                    profile = new user_profiles { users_ID = user.users_ID };
                    context.user_profiles.Add(profile);
                }
                
                // Обновляем данные профиля
                profile.users_email = emailTextBox.Text;
                profile.users_name = nameTextBox.Text;
                profile.users_surname = surnameTextBox.Text;
                
                // Сохраняем изменения
                context.SaveChanges();
            }
        }

        private void CancelButton_Click(object sender, RoutedEventArgs e)
        {
            this.DialogResult = false;
            this.Close();
        }
    }
} 