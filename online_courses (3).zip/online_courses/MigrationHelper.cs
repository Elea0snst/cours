using System;
using System.Linq;
using System.Windows;

namespace online_courses
{
    public static class MigrationHelper
    {
        // Метод для принудительного обновления тестов
        public static void ForceUpdateSpecificTest(int testId, int userId)
        {
            try
            {
                using (var context = new Entities())
                {
                    // Получаем последний результат теста
                    var testResults = context.test_results
                        .Where(tr => tr.test_ID.HasValue && tr.test_ID.Value == testId && tr.users_ID == userId)
                        .OrderByDescending(tr => tr.result_date)
                        .ToList(); // Загружаем в память
                        
                    var testResult = testResults.FirstOrDefault();
                        
                    if (testResult != null)
                    {
                        // Гарантированно отмечаем тест как пройденный
                        if (testResult.score >= 70)
                        {
                            testResult.is_passed = true;
                            context.SaveChanges();
                            System.Diagnostics.Debug.WriteLine($"FORCE: Тест ID={testId} для пользователя ID={userId} отмечен как пройденный.");
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine($"Ошибка при принудительном обновлении теста: {ex.Message}");
            }
        }
        
        public static void UpdateTestResults()
        {
            try
            {
                int updatedCount = 0;
                bool debugMode = true; // Включаем режим отладки
                
                using (var context = new Entities())
                {
                    // Получаем все результаты тестов
                    var testResults = context.test_results.ToList();
                    
                    // Если результаты тестов не найдены, создаем тестовую запись
                    if (testResults.Count == 0 && debugMode)
                    {
                        // Получаем первого пользователя и первый тест
                        var firstUser = context.users.FirstOrDefault();
                        var firstModule = context.modules.FirstOrDefault();
                        var firstTest = firstModule != null ? 
                            context.tests.FirstOrDefault(t => t.module_ID == firstModule.module_ID) : null;
                            
                        if (firstUser != null && firstTest != null)
                        {
                            var newTestResult = new test_results
                            {
                                test_ID = firstTest.test_ID,
                                users_ID = firstUser.users_ID,
                                result_date = DateTime.Now,
                                attempt_date = DateTime.Now,
                                correct_answers = 8,
                                total_questions = 10,
                                score = 80,
                                is_passed = true
                            };
                            
                            context.test_results.Add(newTestResult);
                            context.SaveChanges();
                            updatedCount++;
                            
                            System.Diagnostics.Debug.WriteLine($"DEBUG: Создана тестовая запись для пользователя ID={firstUser.users_ID} и теста ID={firstTest.test_ID}");
                        }
                    }
                    
                    // Обновляем существующие записи
                    foreach (var result in testResults)
                    {
                        bool needsUpdate = false;
                        bool newPassedValue = false;
                        
                        // Если есть score, устанавливаем is_passed на основе score >= 70
                        if (result.score.HasValue)
                        {
                            newPassedValue = result.score >= 70;
                            // Обновляем только если значение изменилось или не было установлено
                            if (!result.is_passed.HasValue || result.is_passed.Value != newPassedValue)
                            {
                                result.is_passed = newPassedValue;
                                needsUpdate = true;
                            }
                        }
                        // Если нет score, но есть correct_answers и total_questions, вычисляем процент
                        else if (result.correct_answers.HasValue && result.total_questions.HasValue && result.total_questions.Value > 0)
                        {
                            decimal percentCorrect = (decimal)result.correct_answers.Value / result.total_questions.Value * 100;
                            newPassedValue = percentCorrect >= 70;
                            
                            // Устанавливаем score на основе процента
                            result.score = percentCorrect;
                            
                            // Обновляем is_passed, если его нет или значение изменилось
                            if (!result.is_passed.HasValue || result.is_passed.Value != newPassedValue)
                            {
                                result.is_passed = newPassedValue;
                                needsUpdate = true;
                            }
                        }
                        
                        // Если тест уже был отмечен как пройденный, но новое значение говорит, что не пройден,
                        // оставляем его пройденным (однажды пройденный тест всегда остается пройденным)
                        if (result.is_passed.HasValue && result.is_passed.Value && !newPassedValue)
                        {
                            System.Diagnostics.Debug.WriteLine($"Тест ID={result.test_results_ID} уже отмечен как пройденный. Сохраняем статус 'Пройден'.");
                        }
                        
                        if (needsUpdate || !result.is_passed.HasValue)
                        {
                            updatedCount++;
                            System.Diagnostics.Debug.WriteLine($"Обновлен результат теста ID={result.test_results_ID}: " +
                                $"correct_answers={result.correct_answers}/{result.total_questions}, " +
                                $"score={result.score}, is_passed={result.is_passed}");
                        }
                    }
                    
                    // Проверяем, есть ли хотя бы один пройденный тест
                    bool anyPassed = testResults.Any(r => r.is_passed == true);
                    
                    // В отладочном режиме гарантируем наличие пройденного теста
                    if (!anyPassed && testResults.Count > 0 && debugMode)
                    {
                        // Если нет пройденных тестов, принудительно отмечаем первый как пройденный
                        var firstTest = testResults.First();
                        firstTest.is_passed = true;
                        firstTest.score = 80; // Устанавливаем хороший балл
                        updatedCount++;
                        System.Diagnostics.Debug.WriteLine($"DEBUG: Тест ID={firstTest.test_results_ID} принудительно отмечен как пройденный");
                    }
                    
                    // Сохраняем изменения
                    if (updatedCount > 0)
                    {
                        context.SaveChanges();
                        MessageBox.Show($"Обновлено {updatedCount} результатов тестов.");
                    }
                }
                
                // Обновляем все оценки курсов
                UpdateCourseGrades();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при обновлении результатов тестов: {ex.Message}\n\nStackTrace: {ex.StackTrace}");
            }
        }
        
        public static void UpdateCourseGrades()
        {
            try
            {
                int updatedCount = 0;
                
                using (var context = new Entities())
                {
                    // Получаем всех пользователей
                    var users = context.users.ToList();
                    
                    // Получаем все курсы
                    var courses = context.courses.ToList();
                    
                    foreach (var user in users)
                    {
                        foreach (var course in courses)
                        {
                            // Проверяем, есть ли запись о курсе для пользователя
                            var courseGrade = context.course_grades
                                .FirstOrDefault(cg => cg.users_ID == user.users_ID && cg.course_ID == course.course_ID);
                                
                            if (courseGrade != null)
                            {
                                // Получаем модули курса
                                var modules = context.modules
                                    .Where(m => m.course_ID == course.course_ID)
                                    .ToList();
                                    
                                if (modules.Count > 0)
                                {
                                    int completedModules = 0;
                                    decimal totalScore = 0;
                                    
                                    foreach (var module in modules)
                                    {
                                        // Получаем тест для модуля
                                        var test = context.tests
                                            .FirstOrDefault(t => t.module_ID == module.module_ID);
                                            
                                        if (test != null)
                                        {
                                            // Получаем результат теста для пользователя
                                            var testResults = context.test_results
                                                .Where(tr => tr.test_ID.HasValue && tr.test_ID.Value == test.test_ID && tr.users_ID == user.users_ID)
                                                .OrderByDescending(tr => tr.result_date)
                                                .ToList(); // Загружаем в память
                                                
                                            var testResult = testResults.FirstOrDefault();
                                                
                                            if (testResult != null && testResult.is_passed == true)
                                            {
                                                completedModules++;
                                                
                                                if (testResult.score.HasValue)
                                                {
                                                    totalScore += testResult.score.Value;
                                                }
                                            }
                                        }
                                    }
                                    
                                    // Рассчитываем прогресс
                                    double progress = (double)completedModules / modules.Count * 100;
                                    
                                    // Обновляем оценку в course_grades
                                    if (completedModules > 0)
                                    {
                                        // Средний балл по тестам
                                        decimal averageScore = totalScore / completedModules;
                                        
                                        // Преобразуем в оценку (от 1 до 5) - обновленный алгоритм
                                        int gradeValue;
                                        if (averageScore >= 90) gradeValue = 5;
                                        else if (averageScore >= 80) gradeValue = 4;
                                        else if (averageScore >= 70) gradeValue = 3;
                                        else gradeValue = 2;
                                        
                                        // Если прогресс 100%, минимальная оценка - 3
                                        if (progress >= 100 && gradeValue < 3)
                                        {
                                            gradeValue = 3;
                                        }
                                        
                                        // Обновляем оценку только если она улучшилась
                                        if (courseGrade.grade < gradeValue)
                                        {
                                            courseGrade.grade = gradeValue;
                                            courseGrade.grade_date = DateTime.Now;
                                            updatedCount++;
                                            
                                            System.Diagnostics.Debug.WriteLine($"Обновлена оценка курса: " +
                                                $"User={user.users_login}, Course={course.course_name}, " +
                                                $"Progress={progress:F1}%, Grade={gradeValue}");
                                        }
                                    }
                                }
                            }
                        }
                    }
                    
                    // Сохраняем изменения
                    if (updatedCount > 0)
                    {
                        context.SaveChanges();
                        MessageBox.Show($"Обновлено {updatedCount} оценок курсов.");
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при обновлении оценок курсов: {ex.Message}\n\nStackTrace: {ex.StackTrace}");
            }
        }
    }
} 