using System;
using System.Linq;
using System.Windows;

namespace online_courses
{
    public class CourseGradeHelper
    {
        private readonly Entities _context;

        public class CourseProgressInfo
        {
            public int CompletedModules { get; set; }
            public int TotalModules { get; set; }
            public double ProgressPercentage { get; set; }
        }

        public CourseGradeHelper(Entities context)
        {
            _context = context ?? throw new ArgumentNullException(nameof(context));
        }

        public CourseProgressInfo CalculateCourseProgress(int courseId, int userId)
        {
            try
            {
                // Получаем все модули курса
                var modules = _context.modules
                    .Where(m => m.course_ID == courseId)
                    .ToList();

                if (!modules.Any())
                {
                    return new CourseProgressInfo { CompletedModules = 0, TotalModules = 0, ProgressPercentage = 0 };
                }

                int totalModules = modules.Count;
                int completedModules = 0;
                double totalProgress = 0;

                foreach (var module in modules)
                {
                    // Получаем все тесты для модуля
                    var tests = _context.tests
                        .Where(t => t.module_ID == module.module_ID)
                        .ToList();

                    if (tests != null && tests.Count > 0)
                    {
                        int passedTests = 0;
                        
                        foreach (var test in tests)
                        {
                            // Получаем результаты теста
                            var testResults = _context.test_results
                                .Where(tr => tr.test_ID.HasValue && tr.test_ID.Value == test.test_ID && tr.users_ID == userId)
                                .OrderByDescending(tr => tr.result_date)
                                .ToList();

                            var testResult = testResults.FirstOrDefault();

                            if (testResult != null)
                            {
                                // Проверяем, пройден ли тест
                                if (testResult.is_passed == true)
                                {
                                    passedTests++;
                                    System.Diagnostics.Debug.WriteLine($"[CourseGradeHelper] Тест {test.test_ID} пройден (is_passed=true)");
                                }
                                // Если is_passed не установлен, проверяем score
                                else if (testResult.score.HasValue && testResult.score.Value >= 70)
                                {
                                    passedTests++;
                                    System.Diagnostics.Debug.WriteLine($"[CourseGradeHelper] Тест {test.test_ID} пройден (score={testResult.score.Value})");
                                }
                                else
                                {
                                    System.Diagnostics.Debug.WriteLine($"[CourseGradeHelper] Тест {test.test_ID} не пройден " +
                                        $"(is_passed={testResult.is_passed}, score={testResult.score})");
                                }
                            }
                            else
                            {
                                System.Diagnostics.Debug.WriteLine($"[CourseGradeHelper] Тест {test.test_ID} не пройден (нет результатов)");
                            }
                        }
                        
                        // Модуль считается пройденным, если пройдены все тесты
                        if (passedTests == tests.Count)
                        {
                            completedModules++;
                            System.Diagnostics.Debug.WriteLine($"[CourseGradeHelper] Модуль {module.module_name} пройден (все тесты пройдены: {passedTests}/{tests.Count})");
                        }
                        else
                        {
                            // Вычисляем частичный прогресс модуля: 50% за просмотр + до 50% за тесты
                            double moduleProgress = 0.5;
                            if (tests.Count > 0)
                            {
                                moduleProgress += 0.5 * ((double)passedTests / tests.Count);
                            }
                            
                            // Добавляем частичный прогресс к общему прогрессу
                            totalProgress += moduleProgress;
                            
                            System.Diagnostics.Debug.WriteLine($"[CourseGradeHelper] Модуль {module.module_name} частично пройден " +
                                $"(пройдено тестов: {passedTests}/{tests.Count}, прогресс: {moduleProgress*100:F1}%)");
                        }
                    }
                    else
                    {
                        // Если тестов нет, модуль считается пройденным автоматически
                        completedModules++;
                        System.Diagnostics.Debug.WriteLine($"[CourseGradeHelper] Модуль {module.module_name} пройден (нет тестов)");
                    }
                }

                // Добавляем прогресс от полностью пройденных модулей
                totalProgress += completedModules;
                
                // Вычисляем общий процент прогресса
                double progressPercentage = totalModules > 0 ? (totalProgress / totalModules) * 100 : 0;

                return new CourseProgressInfo
                {
                    CompletedModules = completedModules,
                    TotalModules = totalModules,
                    ProgressPercentage = progressPercentage
                };
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine($"[CourseGradeHelper] Ошибка при расчете прогресса: {ex.Message}\n{ex.StackTrace}");
                throw;
            }
        }

        public static void UpdateCourseGrade(user currentUser, cours course, double testScore)
        {
            try
            {
                using (var context = new Entities())
                {
                    var helper = new CourseGradeHelper(context);
                    var progressInfo = helper.CalculateCourseProgress(course.course_ID, currentUser.users_ID);
                    
                    // Получаем все тесты и их результаты для данного курса и студента
                    decimal totalScore = 0;
                    int totalTestsCompleted = 0;
                    
                    // Получаем все модули курса
                    var modules = context.modules
                        .Where(m => m.course_ID == course.course_ID)
                        .ToList();
                    
                    foreach (var module in modules)
                    {
                        // Получаем все тесты для модуля
                        var tests = context.tests
                            .Where(t => t.module_ID == module.module_ID)
                            .ToList();
                            
                        foreach (var test in tests)
                        {
                            var testResults = context.test_results
                                .Where(tr => tr.test_ID.HasValue && tr.test_ID.Value == test.test_ID && tr.users_ID == currentUser.users_ID)
                                .OrderByDescending(tr => tr.result_date)
                                .ToList();
                                
                            var testResult = testResults.FirstOrDefault();
                                
                            if (testResult != null && 
                                ((testResult.is_passed == true) || 
                                (testResult.score.HasValue && testResult.score.Value >= 70)))
                            {
                                if (testResult.score.HasValue)
                                {
                                    totalScore += testResult.score.Value;
                                }
                                totalTestsCompleted++;
                            }
                        }
                    }
                    
                    // Рассчитываем оценку
                    int gradeValue = 0;
                    
                    if (totalTestsCompleted > 0)
                    {
                        decimal averageScore = totalScore / totalTestsCompleted;
                        
                        // Улучшенный алгоритм расчета оценки
                        if (averageScore >= 90) 
                        {
                            // При 90-100% всегда ставим 5
                            gradeValue = 5;
                        }
                        else if (averageScore >= 80) 
                        {
                            // При 80-89% ставим 4
                            gradeValue = 4;
                        }
                        else if (averageScore >= 70) 
                        {
                            // При 70-79% ставим 3
                            gradeValue = 3;
                        }
                        else
                        {
                            // Ниже 70% - оценка 2
                            gradeValue = 2;
                        }
                        
                        // Если прогресс 100%, минимальная оценка - 3
                        if (progressInfo.ProgressPercentage >= 100 && gradeValue < 3)
                        {
                            gradeValue = 3;
                        }
                        
                        System.Diagnostics.Debug.WriteLine($"Средний балл: {averageScore:F1}, Оценка: {gradeValue}, Прогресс: {progressInfo.ProgressPercentage:F1}%");
                    }
                    
                    // Обновляем или создаем запись о прогрессе курса
                    var courseGrade = context.course_grades
                        .FirstOrDefault(cg => cg.users_ID == currentUser.users_ID && cg.course_ID == course.course_ID);
                        
                    if (courseGrade != null)
                    {
                        if (courseGrade.grade < gradeValue || courseGrade.grade == 0)
                        {
                            courseGrade.grade = gradeValue;
                            courseGrade.grade_date = DateTime.Now;
                            
                            System.Diagnostics.Debug.WriteLine($"Обновлена оценка курса: ID={courseGrade.grade_ID}, " +
                                $"Прогресс={progressInfo.ProgressPercentage:F1}%, Оценка={gradeValue}");
                        }
                    }
                    else
                    {
                        courseGrade = new course_grades
                        {
                            users_ID = currentUser.users_ID,
                            course_ID = course.course_ID,
                            grade = gradeValue,
                            grade_date = DateTime.Now
                        };
                        
                        context.course_grades.Add(courseGrade);
                        System.Diagnostics.Debug.WriteLine($"Создана запись о курсе: " +
                            $"Прогресс={progressInfo.ProgressPercentage:F1}%, Оценка={gradeValue}");
                    }
                    
                    context.SaveChanges();
                    
                    System.Diagnostics.Debug.WriteLine($"Курс ID={course.course_ID}: " +
                        $"Прогресс={progressInfo.ProgressPercentage:F1}% ({progressInfo.CompletedModules}/{progressInfo.TotalModules}), " +
                        $"Оценка={gradeValue}");
                }
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine($"Ошибка при обновлении оценки курса: {ex.Message}\n{ex.StackTrace}");
                MessageBox.Show($"Ошибка при обновлении оценки курса: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }
    }
} 