using System;
using System.Windows;
using System.Windows.Controls;

namespace online_courses
{
    public partial class TeacherPage : Window
    {
        private user _currentUser;

        public TeacherPage(user user)
        {
            InitializeComponent();
            _currentUser = user;
            Title = $"Личный кабинет преподавателя: {_currentUser.users_login}";
            
            // Обработчик события навигации
            MainFrame.Navigated += MainFrame_Navigated;
            
            // По умолчанию показываем страницу с курсами преподавателя
            MainFrame.Navigate(new TeacherCoursesPage(_currentUser));
        }

        private void MainFrame_Navigated(object sender, System.Windows.Navigation.NavigationEventArgs e)
        {
            // При каждой навигации проверяем, нуждается ли страница в обновлении
            if (e.Content is IPageRefresh pageWithRefresh)
            {
                pageWithRefresh.RefreshData();
            }
        }

        private void MyCoursesButton_Click(object sender, RoutedEventArgs e)
        {
            MainFrame.Navigate(new TeacherCoursesPage(_currentUser));
        }

        private void CreateCourseButton_Click(object sender, RoutedEventArgs e)
        {
            MainFrame.Navigate(new CourseCreationPage(_currentUser));
        }

        private void ProfileButton_Click(object sender, RoutedEventArgs e)
        {
            MainFrame.Navigate(new ProfilePage(_currentUser));
        }

        private void SupportButton_Click(object sender, RoutedEventArgs e)
        {
            MainFrame.Navigate(new SupportChatPage(_currentUser));
        }

        private void LogoutButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                LoginPage loginPage = new LoginPage();
                loginPage.Show();
                this.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при выходе из системы: {ex.Message}");
            }
        }
    }
} 