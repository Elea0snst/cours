using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;

namespace online_courses
{
    public partial class ModeratorComplaintsPage : Page, IPageRefresh
    {
        private user _currentUser;
        private List<complaint> _complaints;
        private complaint _selectedComplaint;

        public ModeratorComplaintsPage(user user)
        {
            InitializeComponent();
            _currentUser = user;
            
            // Настройка начального состояния кнопок
            UpdateButtonsState();
        }

        private void Page_Loaded(object sender, RoutedEventArgs e)
        {
            RefreshData();
        }

        public void RefreshData()
        {
            try
            {
                // Загружаем список жалоб из базы данных
                _complaints = Entities.GetContext().complaints.ToList();
                
                // Применяем фильтр при необходимости
                ApplyFilter();

                // Обновляем выделение
                UpdateButtonsState();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при загрузке данных: {ex.Message}");
            }
        }

        private void ApplyFilter()
        {
            if (filterComboBox.SelectedIndex < 0)
            {
                filterComboBox.SelectedIndex = 0;
            }

            IEnumerable<complaint> filteredComplaints = _complaints;

            // Применяем фильтр по типу жалобы
            switch (filterComboBox.SelectedIndex)
            {
                case 1: // Жалобы на отзывы
                    filteredComplaints = _complaints.Where(c => c.complaint_type == "review");
                    break;
                case 2: // Жалобы на пользователей
                    filteredComplaints = _complaints.Where(c => c.complaint_type == "user");
                    break;
                default: // Все жалобы
                    break;
            }

            // Устанавливаем отфильтрованные данные в DataGrid
            complaintsDataGrid.ItemsSource = filteredComplaints.ToList();
        }

        private void FilterComboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            ApplyFilter();
        }

        private void ComplaintsDataGrid_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            _selectedComplaint = complaintsDataGrid.SelectedItem as complaint;
            UpdateButtonsState();
        }

        private void UpdateButtonsState()
        {
            bool isComplaintSelected = _selectedComplaint != null;
            
            viewButton.IsEnabled = isComplaintSelected;
            approveButton.IsEnabled = isComplaintSelected && _selectedComplaint.status == "На рассмотрении";
            rejectButton.IsEnabled = isComplaintSelected && _selectedComplaint.status == "На рассмотрении";
        }

        private void ViewButton_Click(object sender, RoutedEventArgs e)
        {
            if (_selectedComplaint != null)
            {
                // Открываем окно с деталями жалобы
                var detailsWindow = new ComplaintDetailsWindow(_selectedComplaint);
                detailsWindow.ShowDialog();
            }
        }

        private void ApproveButton_Click(object sender, RoutedEventArgs e)
        {
            if (_selectedComplaint != null)
            {
                try
                {
                    var context = Entities.GetContext();
                    // Получаем жалобу из текущего контекста
                    var complaint = context.complaints.FirstOrDefault(c => c.complaint_ID == _selectedComplaint.complaint_ID);
                    if (complaint == null)
                    {
                        MessageBox.Show("Жалоба не найдена в базе данных.");
                        return;
                    }
                    complaint.status = "Одобрена";

                    // Выполняем действия в зависимости от типа жалобы
                    if (complaint.complaint_type == "review")
                    {
                        int reviewId = complaint.target_ID;
                        var review = context.course_reviews.FirstOrDefault(r => r.review_ID == reviewId);
                        if (review != null)
                        {
                            context.course_reviews.Remove(review);
                        }
                    }
                    else if (complaint.complaint_type == "user")
                    {
                        int userId = complaint.target_ID;
                        var targetUser = context.users.FirstOrDefault(u => u.users_ID == userId);
                        if (targetUser != null)
                        {
                            MessageBox.Show($"Пользователь {targetUser.users_login} будет заблокирован.\n(В модели user нет поля блокировки)");
                        }
                    }

                    context.SaveChanges();
                    MessageBox.Show("Жалоба одобрена. Необходимые действия выполнены.");
                    RefreshData();
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Ошибка при обработке жалобы: {ex.Message}");
                }
            }
        }

        private void RejectButton_Click(object sender, RoutedEventArgs e)
        {
            if (_selectedComplaint != null)
            {
                try
                {
                    var context = Entities.GetContext();
                    var complaint = context.complaints.FirstOrDefault(c => c.complaint_ID == _selectedComplaint.complaint_ID);
                    if (complaint == null)
                    {
                        MessageBox.Show("Жалоба не найдена в базе данных.");
                        return;
                    }
                    complaint.status = "Отклонена";
                    context.SaveChanges();
                    MessageBox.Show("Жалоба отклонена.");
                    RefreshData();
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Ошибка при обработке жалобы: {ex.Message}");
                }
            }
        }

        private void RefreshButton_Click(object sender, RoutedEventArgs e)
        {
            RefreshData();
        }
    }
} 