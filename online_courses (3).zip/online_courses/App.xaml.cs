﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Threading.Tasks;
using System.Windows;

namespace online_courses
{
    /// <summary>
    /// Логика взаимодействия для App.xaml
    /// </summary>
    public partial class App : Application
    {
        protected override void OnStartup(StartupEventArgs e)
        {
            base.OnStartup(e);

            // Register all page types to ensure they're loaded
            RegisterTypes();

            // Инициализация базы данных при первом запуске
            try
            {
                using (var context = new Entities())
                {
                    context.Database.Connection.Open();
                    context.Database.Connection.Close();
                }
            }
            catch (System.Exception ex)
            {
                MessageBox.Show($"Ошибка подключения к базе данных: {ex.Message}");
                Current.Shutdown();
            }
        }

        private void RegisterTypes()
        {
            // This forces the types to be loaded
            Type[] types = {
                typeof(TestEditPage),
                typeof(ExamEditPage),
                typeof(GetIndexConverter)
            };
        }
    }
}
