using System;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Data.Entity;
using System.Windows.Data;
using System.Windows.Media;

namespace online_courses
{
    public partial class ModuleEditPage : Page, IPageRefresh
    {
        private readonly user _currentUser;
        private module _module;
        
        public ModuleEditPage(user currentUser, module module)
        {
            InitializeComponent();
            _currentUser = currentUser ?? throw new ArgumentNullException(nameof(currentUser));
            _module = module ?? throw new ArgumentNullException(nameof(module));
            LoadData();
        }

        public void LoadData()
        {
            try
            {
                using (var context = new Entities())
                {
                    // Загружаем модуль с тестами
                    var module = context.modules
                        .Include("tests")
                        .FirstOrDefault(m => m.module_ID == _module.module_ID);

                    if (module != null)
                    {
                        _module = module;
                        moduleNameTextBox.Text = _module.module_name;
                        moduleDescriptionTextBox.Text = _module.module_description;

                        // Загружаем тесты без ограничений
                        var allTests = context.tests.ToList();
                        
                        // Фильтруем только те, которые принадлежат нашему модулю
                        var moduleTests = allTests.Where(t => t.module_ID == _module.module_ID).ToList();
                        
                        System.Diagnostics.Debug.WriteLine($"[ModuleEditPage] Всего тестов в БД: {allTests.Count}");
                        System.Diagnostics.Debug.WriteLine($"[ModuleEditPage] Тестов в модуле ID={_module.module_ID}: {moduleTests.Count}");
                        
                        foreach (var test in moduleTests)
                        {
                            System.Diagnostics.Debug.WriteLine($"[ModuleEditPage] Тест ID={test.test_ID}, вопрос: {test.question}");
                        }

                        // Очищаем список тестов
                        testsListView.Items.Clear();

                        // Добавляем каждый тест как отдельный элемент списка
                        foreach (var test in moduleTests)
                        {
                            // Создаем контейнер для теста
                            var testPanel = new Grid();
                            
                            // Определяем столбцы
                            testPanel.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
                            testPanel.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
                            testPanel.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
                            
                            // Текст вопроса
                            var questionText = new TextBlock
                            {
                                Text = test.question,
                                TextWrapping = TextWrapping.Wrap,
                                VerticalAlignment = VerticalAlignment.Center,
                                Margin = new Thickness(5)
                            };
                            Grid.SetColumn(questionText, 0);
                            
                            // Кнопка редактирования
                            var editButton = new Button
                            {
                                Content = "Редактировать",
                                Margin = new Thickness(5),
                                Tag = test.test_ID
                            };
                            editButton.Click += EditTestButton_Click;
                            Grid.SetColumn(editButton, 1);
                            
                            // Кнопка удаления
                            var deleteButton = new Button
                            {
                                Content = "Удалить",
                                Margin = new Thickness(5),
                                Tag = test.test_ID
                            };
                            deleteButton.Click += DeleteTestButton_Click;
                            Grid.SetColumn(deleteButton, 2);
                            
                            // Добавляем элементы в панель теста
                            testPanel.Children.Add(questionText);
                            testPanel.Children.Add(editButton);
                            testPanel.Children.Add(deleteButton);
                            
                            // Добавляем панель теста в список
                            var item = new ListViewItem();
                            item.Content = testPanel;
                            testsListView.Items.Add(item);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при загрузке данных: {ex.Message}");
            }
        }

        public void RefreshData()
        {
            LoadData();
        }

        private void SaveButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(moduleNameTextBox.Text))
                {
                    MessageBox.Show("Введите название модуля");
                    return;
                }

                using (var context = new Entities())
                {
                    // Получаем модуль из базы данных
                    var moduleToUpdate = context.modules.FirstOrDefault(m => m.module_ID == _module.module_ID);
                    if (moduleToUpdate != null)
                    {
                        // Обновляем данные модуля
                        moduleToUpdate.module_name = moduleNameTextBox.Text;
                        moduleToUpdate.module_description = moduleDescriptionTextBox.Text;

                        // Сохраняем изменения
                        context.SaveChanges();

                        MessageBox.Show("Модуль успешно обновлен");
                        
                        // Возвращаемся на предыдущую страницу
                        if (NavigationService.CanGoBack)
                        {
                            // Сбрасываем контекст базы данных перед навигацией назад
                            Entities.ResetContext();
                            
                            NavigationService.GoBack();
                            
                            // Обновляем страницу редактирования курса
                            if (NavigationService.Content is CourseEditPage courseEditPage)
                            {
                                courseEditPage.RefreshData();
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при сохранении модуля: {ex.Message}");
            }
        }

        private void CancelButton_Click(object sender, RoutedEventArgs e)
        {
            if (NavigationService.CanGoBack)
            {
                // Сбрасываем контекст базы данных перед навигацией назад
                Entities.ResetContext();
                
                NavigationService.GoBack();
                
                // Обновляем страницу редактирования курса
                if (NavigationService.Content is CourseEditPage courseEditPage)
                {
                    courseEditPage.RefreshData();
                }
            }
        }

        private void DeleteButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                // Запрашиваем подтверждение удаления
                var confirmResult = MessageBox.Show(
                    "Вы действительно хотите удалить этот модуль? Будут также удалены все связанные тесты. Это действие нельзя отменить.",
                    "Подтверждение удаления",
                    MessageBoxButton.YesNo,
                    MessageBoxImage.Warning);

                if (confirmResult == MessageBoxResult.Yes)
                {
                    using (var context = new Entities())
                    {
                        // Находим модуль в базе данных
                        var moduleToDelete = context.modules.FirstOrDefault(m => m.module_ID == _module.module_ID);
                        if (moduleToDelete != null)
                        {
                            // Находим связанные тесты
                            var tests = context.tests.Where(t => t.module_ID == _module.module_ID).ToList();
                            
                            // Удаляем результаты тестов
                            foreach (var test in tests)
                            {
                                var testResults = context.test_results.Where(tr => tr.test_ID == test.test_ID).ToList();
                                foreach (var testResult in testResults)
                                {
                                    context.test_results.Remove(testResult);
                                }
                                
                                // Удаляем сам тест
                                context.tests.Remove(test);
                            }

                            // Удаляем модуль
                            context.modules.Remove(moduleToDelete);
                            context.SaveChanges();

                            MessageBox.Show("Модуль успешно удален");

                            // Возвращаемся на предыдущую страницу и обеспечиваем обновление списка
                            if (NavigationService.CanGoBack)
                            {
                                // Сначала сбрасываем контекст базы данных
                                Entities.ResetContext();
                                
                                NavigationService.GoBack();
                                
                                // Обновляем страницу редактирования курса
                                if (NavigationService.Content is CourseEditPage courseEditPage)
                                {
                                    courseEditPage.RefreshData();
                                }
                            }
                        }
                        else
                        {
                            MessageBox.Show("Модуль не найден в базе данных.");
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при удалении модуля: {ex.Message}");
            }
        }

        private void AddTestButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                // Создаем новый тест прямо в диалоговом окне без предварительного сохранения в базе
                var newTest = new test
                {
                    module_ID = _module.module_ID,
                    question = "Введите вопрос",
                    answer_options = "Вариант 1;Вариант 2;Вариант 3;Вариант 4",
                    correct_answer = "1"
                };

                // Открываем диалоговое окно для создания вопроса
                if (EditTestQuestionDialog(newTest, true))
                {
                    // Если диалог был подтвержден, сохраняем новый тест в базе
                    using (var context = new Entities())
                    {
                        context.tests.Add(newTest);
                        context.SaveChanges();
                        System.Diagnostics.Debug.WriteLine($"[ModuleEditPage] Создан новый тест ID={newTest.test_ID} для модуля ID={_module.module_ID}");
                        
                        // Обновляем список тестов
                        LoadData();
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при создании теста: {ex.Message}");
            }
        }

        private void EditTestButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                var button = sender as Button;
                if (button != null && button.Tag != null)
                {
                    int testId = (int)button.Tag;
                    using (var context = new Entities())
                    {
                        var test = context.tests.FirstOrDefault(t => t.test_ID == testId);
                        if (test != null)
                        {
                            // Открываем диалоговое окно для редактирования вопроса
                            EditTestQuestionDialog(test, false);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при редактировании теста: {ex.Message}");
            }
        }

        private bool EditTestQuestionDialog(test testQuestion, bool isNew)
        {
            try
            {
                // Создаем копию объекта для редактирования
                var editedTest = new test
                {
                    test_ID = testQuestion.test_ID,
                    module_ID = testQuestion.module_ID,
                    question = testQuestion.question,
                    answer_options = testQuestion.answer_options,
                    correct_answer = testQuestion.correct_answer
                };
                
                // Создаем диалоговое окно для редактирования вопроса
                var editWindow = new Window
                {
                    Title = isNew ? "Добавление вопроса" : "Редактирование вопроса",
                    Width = 600,
                    Height = 500,
                    WindowStartupLocation = WindowStartupLocation.CenterScreen,
                    Owner = Window.GetWindow(this) // Установка владельца окна
                };
                
                var mainGrid = new Grid();
                mainGrid.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
                mainGrid.RowDefinitions.Add(new RowDefinition { Height = new GridLength(100) });
                mainGrid.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
                mainGrid.RowDefinitions.Add(new RowDefinition { Height = new GridLength(150) });
                mainGrid.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
                mainGrid.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
                mainGrid.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
                
                // Заголовок
                var headerText = new TextBlock
                {
                    Text = isNew ? "Добавление нового вопроса" : "Редактирование вопроса",
                    FontSize = 16,
                    FontWeight = FontWeights.Bold,
                    Margin = new Thickness(10, 10, 10, 15),
                    HorizontalAlignment = HorizontalAlignment.Center
                };
                Grid.SetRow(headerText, 0);
                mainGrid.Children.Add(headerText);
                
                // Вопрос
                var questionLabel = new TextBlock
                {
                    Text = "Вопрос:",
                    Margin = new Thickness(10, 10, 10, 5),
                    FontWeight = FontWeights.Bold
                };
                Grid.SetRow(questionLabel, 1);
                
                var questionTextBox = new TextBox
                {
                    Text = editedTest.question,
                    Margin = new Thickness(10),
                    AcceptsReturn = true,
                    TextWrapping = TextWrapping.Wrap,
                    VerticalScrollBarVisibility = ScrollBarVisibility.Auto
                };
                Grid.SetRow(questionTextBox, 2);
                
                // Варианты ответов
                var optionsLabel = new TextBlock
                {
                    Text = "Варианты ответов (каждый с новой строки):",
                    Margin = new Thickness(10, 10, 10, 5),
                    FontWeight = FontWeights.Bold
                };
                Grid.SetRow(optionsLabel, 3);
                
                var optionsTextBox = new TextBox
                {
                    Text = string.Join(Environment.NewLine, editedTest.answer_options.Split(';')),
                    Margin = new Thickness(10),
                    AcceptsReturn = true,
                    TextWrapping = TextWrapping.Wrap,
                    VerticalScrollBarVisibility = ScrollBarVisibility.Auto
                };
                Grid.SetRow(optionsTextBox, 4);
                
                // Правильный ответ
                var correctAnswerLabel = new TextBlock
                {
                    Text = "Номер правильного ответа (начиная с 1):",
                    Margin = new Thickness(10, 10, 10, 5),
                    FontWeight = FontWeights.Bold
                };
                Grid.SetRow(correctAnswerLabel, 5);
                
                var correctAnswerTextBox = new TextBox
                {
                    Text = editedTest.correct_answer,
                    Margin = new Thickness(10)
                };
                Grid.SetRow(correctAnswerTextBox, 5);
                
                // Кнопки
                var buttonsPanel = new StackPanel
                {
                    Orientation = Orientation.Horizontal,
                    HorizontalAlignment = HorizontalAlignment.Right,
                    Margin = new Thickness(10)
                };
                Grid.SetRow(buttonsPanel, 6);
                
                var saveButton = new Button
                {
                    Content = "Сохранить",
                    Padding = new Thickness(10, 5, 10, 5),
                    Margin = new Thickness(5),
                    IsDefault = true,
                    Background = new SolidColorBrush(Color.FromRgb(0, 122, 204)),
                    Foreground = Brushes.White
                };
                
                var cancelButton = new Button
                {
                    Content = "Отмена",
                    Padding = new Thickness(10, 5, 10, 5),
                    Margin = new Thickness(5),
                    IsCancel = true
                };
                
                buttonsPanel.Children.Add(saveButton);
                buttonsPanel.Children.Add(cancelButton);
                
                // Добавляем элементы в сетку
                mainGrid.Children.Add(questionLabel);
                mainGrid.Children.Add(questionTextBox);
                mainGrid.Children.Add(optionsLabel);
                mainGrid.Children.Add(optionsTextBox);
                mainGrid.Children.Add(correctAnswerLabel);
                mainGrid.Children.Add(correctAnswerTextBox);
                mainGrid.Children.Add(buttonsPanel);
                
                // Результат операции редактирования
                bool editConfirmed = false;
                
                // Обработчики событий
                saveButton.Click += (s, args) =>
                {
                    try
                    {
                        // Валидация
                        if (string.IsNullOrWhiteSpace(questionTextBox.Text))
                        {
                            MessageBox.Show("Введите текст вопроса");
                            return;
                        }
                        
                        var options = optionsTextBox.Text.Split(new[] { Environment.NewLine }, StringSplitOptions.RemoveEmptyEntries);
                        if (options.Length < 2)
                        {
                            MessageBox.Show("Введите не менее двух вариантов ответа");
                            return;
                        }
                        
                        int correctAnswer;
                        if (!int.TryParse(correctAnswerTextBox.Text, out correctAnswer) || correctAnswer < 1 || correctAnswer > options.Length)
                        {
                            MessageBox.Show($"Введите корректный номер правильного ответа (от 1 до {options.Length})");
                            return;
                        }
                        
                        // Обновляем данные исходного вопроса
                        testQuestion.question = questionTextBox.Text;
                        testQuestion.answer_options = string.Join(";", options);
                        testQuestion.correct_answer = correctAnswer.ToString();
                        
                        // Если это редактирование существующего вопроса (не новый), сохраняем изменения
                        if (!isNew)
                        {
                            using (var context = new Entities())
                            {
                                var dbTest = context.tests.FirstOrDefault(t => t.test_ID == testQuestion.test_ID);
                                if (dbTest != null)
                                {
                                    dbTest.question = testQuestion.question;
                                    dbTest.answer_options = testQuestion.answer_options;
                                    dbTest.correct_answer = testQuestion.correct_answer;
                                    context.SaveChanges();
                                    
                                    System.Diagnostics.Debug.WriteLine($"[ModuleEditPage] Обновлен тест ID={testQuestion.test_ID}, вопрос: {testQuestion.question}");
                                    
                                    // Обновляем список тестов
                                    LoadData();
                                }
                            }
                        }
                        
                        // Устанавливаем флаг успешного редактирования
                        editConfirmed = true;
                        
                        // Закрываем окно
                        editWindow.Close();
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show($"Ошибка при сохранении вопроса: {ex.Message}");
                    }
                };
                
                cancelButton.Click += (s, args) => editWindow.Close();
                
                // Показываем окно
                editWindow.Content = mainGrid;
                editWindow.ShowDialog();
                
                // Возвращаем результат операции
                return editConfirmed;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при открытии редактора вопросов: {ex.Message}");
                return false;
            }
        }

        private void DeleteTestButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                var button = sender as Button;
                if (button != null && button.Tag != null)
                {
                    int testId = (int)button.Tag;
                    
                    // Запрашиваем подтверждение удаления
                    var result = MessageBox.Show(
                        "Вы действительно хотите удалить этот вопрос теста?", 
                        "Подтверждение удаления", 
                        MessageBoxButton.YesNo, 
                        MessageBoxImage.Warning);
                        
                    if (result == MessageBoxResult.Yes)
                    {
                        using (var context = new Entities())
                        {
                            // Находим тест
                            var test = context.tests.FirstOrDefault(t => t.test_ID == testId);
                            if (test != null)
                            {
                                // Удаляем связанные результаты теста
                                var testResults = context.test_results.Where(tr => tr.test_ID == testId).ToList();
                                foreach (var testResult in testResults)
                                {
                                    context.test_results.Remove(testResult);
                                }
                                
                                // Удаляем сам тест
                                context.tests.Remove(test);
                                context.SaveChanges();
                                
                                // Обновляем список тестов
                                LoadData();
                                
                                MessageBox.Show("Вопрос успешно удален.");
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при удалении теста: {ex.Message}");
            }
        }
    }
} 