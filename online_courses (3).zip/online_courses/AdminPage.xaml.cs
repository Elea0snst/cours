using System;
using System.Windows;
using System.Windows.Controls;
using System.Collections.Generic;
using System.Text;

namespace online_courses
{
    public partial class AdminPage : Window
    {
        private user _currentUser;

        public AdminPage(user user)
        {
            InitializeComponent();
            _currentUser = user;
            Title = $"Личный кабинет администратора: {_currentUser.users_login}";
            
            try
            {
                // Сбрасываем контекст перед загрузкой страницы
                Entities.ResetContext();
                
                // По умолчанию показываем страницу со списком пользователей
                MainFrame.Navigate(new AdminUsersPage(_currentUser));
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при загрузке страницы администратора: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void MainFrame_IsVisibleChanged(object sender, DependencyPropertyChangedEventArgs e)
        {
            try
            {
                if (MainFrame.Content is Page currentPage && currentPage is IPageRefresh pageWithRefresh)
                {
                    pageWithRefresh.RefreshData();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при обновлении данных: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void UsersButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                Entities.ResetContext();
                
                MainFrame.Navigate(new AdminUsersPage(_currentUser));
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при переходе к странице пользователей: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void ReportButton_Click(object sender, RoutedEventArgs e)
        {
            try 
            {
                // Открываем окно отчетов
                var reportsWindow = new UserReportsWindow(_currentUser);
                reportsWindow.ShowDialog(); // Используем ShowDialog для модального окна
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при открытии отчетов: {ex.Message}", 
                               "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                System.Diagnostics.Debug.WriteLine($"Ошибка при открытии отчетов: {ex.Message}");
            }
        }

        private void SupportButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                // Пытаемся перейти на страницу чата поддержки
                MainFrame.Navigate(new SupportChatPage(_currentUser));
            }
            catch (Exception)
            {
                // Если не удалось, перенаправляем на страницу со списком пользователей
                try {
                    MainFrame.Navigate(new AdminUsersPage(_currentUser));
                }
                catch (Exception ex) {
                    System.Diagnostics.Debug.WriteLine($"Ошибка при навигации: {ex.Message}");
                }
            }
        }

        private void LogoutButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                LoginPage loginPage = new LoginPage();
                loginPage.Show();
                this.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при выходе из системы: {ex.Message}");
            }
        }
    }
} 