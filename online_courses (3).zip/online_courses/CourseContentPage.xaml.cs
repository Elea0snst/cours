using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;

namespace online_courses
{
    public partial class CourseContentPage : Page, IPageRefresh
    {
        private user _currentUser;
        private cours _course;
        private List<ModuleWithStatus> _modules = new List<ModuleWithStatus>();
        private exam _finalExam;

        // Класс для представления модуля с информацией о статусе прохождения и тестах
        private class ModuleWithStatus
        {
            // Основные свойства из класса module
            public int module_ID { get; set; }
            public string module_name { get; set; }
            public string module_description { get; set; }
            public int? course_ID { get; set; }
            
            // Дополнительные свойства для отображения статуса
            public string ModuleStatus { get; set; } = "•"; // По умолчанию - не пройден
            public Brush StatusForeground { get; set; } = Brushes.Gray; // Цвет статуса
            public bool HasTest { get; set; }
            public string TestStatus { get; set; } = "Не пройден";
            public Brush TestStatusForeground { get; set; } = Brushes.Gray; // Цвет статуса теста
            
            // Свойства для хранения связанных данных из базы
            public List<Dictionary<string, object>> TestResults { get; set; } = new List<Dictionary<string, object>>();
        }

        public CourseContentPage(user user, cours course)
        {
            InitializeComponent();
            
            // Создаем локальные копии объектов, чтобы избежать ошибок контекста
            _currentUser = new user
            {
                users_ID = user.users_ID,
                users_login = user.users_login,
                users_password = user.users_password,
                users_role_ID = user.users_role_ID
            };
            
            _course = new cours
            {
                course_ID = course.course_ID,
                course_name = course.course_name,
                course_description = course.course_description,
                course_author = course.course_author,
                course_category = course.course_category
            };
            
            // Сбрасываем контекст
            Entities.ResetContext();
            
            LoadCourseData();
        }

        public void RefreshData()
        {
            // Сбрасываем контекст и очищаем список модулей
            Entities.ResetContext();
            _modules.Clear();
            LoadCourseData();
        }

        private void LoadCourseData()
        {
            try
            {
                if (_course == null || _currentUser == null)
                {
                    MessageBox.Show("Ошибка: Информация о курсе или пользователе отсутствует.");
                    return;
                }

                // Устанавливаем название курса
                courseNameTextBlock.Text = _course.course_name;
                
                // Загружаем данные
                LoadModules();
                LoadFinalExam();
                UpdateCourseProgress();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при загрузке данных курса: {ex.Message}\n\nStackTrace: {ex.StackTrace}");
            }
        }

        private void LoadModules()
        {
            try
            {
                // Получаем ID курса и пользователя локально
                int courseId = _course.course_ID;
                int userId = _currentUser.users_ID;
                
                // Очищаем список
                _modules.Clear();
                
                // Создаем новый контекст
                using (var context = new Entities())
                {
                    // 1. Получаем модули курса за один запрос
                    var dbModules = context.modules
                        .Where(m => m.course_ID == courseId)
                        .OrderBy(m => m.module_ID)
                        .ToList();
                        
                    if (dbModules == null || dbModules.Count == 0)
                    {
                        System.Diagnostics.Debug.WriteLine($"Модули не найдены для курса ID={courseId}");
                        return;
                    }
                    
                    System.Diagnostics.Debug.WriteLine($"Найдено {dbModules.Count} модулей для курса ID={courseId}");
                    
                    // 2. Получаем все тесты для этих модулей за один запрос
                    var moduleIds = dbModules.Select(m => m.module_ID).ToList();
                    var modulesTests = new Dictionary<int, test>();
                    
                    // Безопасно добавляем тесты в словарь, предотвращая дублирование ключей
                    // Загружаем все тесты и фильтруем их в памяти
                    var allTests = context.tests.ToList();
                    foreach (var test in allTests)
                    {
                        if (test.module_ID.HasValue && moduleIds.Contains(test.module_ID.Value))
                        {
                            int moduleId = test.module_ID.Value;
                            if (!modulesTests.ContainsKey(moduleId))
                            {
                                modulesTests.Add(moduleId, test);
                            }
                        }
                    }
                    
                    // Получаем результаты тестов для этих модулей за один запрос
                    var testIds = modulesTests.Values.Select(t => t.test_ID).ToList();
                    
                    // Загружаем все результаты тестов и фильтруем их в памяти
                    var allTestResults = context.test_results.ToList();
                    var testResults = allTestResults
                        .Where(tr => tr.users_ID == userId && tr.test_ID.HasValue && testIds.Contains(tr.test_ID.Value))
                        .OrderByDescending(tr => tr.result_date)
                        .ToList();
                    
                    // Группируем результаты тестов по test_ID, беря только последний результат
                    var latestTestResults = new Dictionary<int?, test_results>();
                    foreach (var result in testResults)
                    {
                        if (result.test_ID.HasValue && !latestTestResults.ContainsKey(result.test_ID))
                        {
                            latestTestResults.Add(result.test_ID, result);
                        }
                    }
                    
                    // 4. Создаем локальные копии модулей со статусами
                    foreach (var dbModule in dbModules)
                    {
                        var moduleWithStatus = new ModuleWithStatus
                        {
                            module_ID = dbModule.module_ID,
                            module_name = dbModule.module_name ?? "Без названия",
                            module_description = dbModule.module_description ?? "Без описания",
                            course_ID = dbModule.course_ID
                        };

                        // Проверяем, есть ли у модуля тест
                        bool hasTest = modulesTests.ContainsKey(dbModule.module_ID);
                        moduleWithStatus.HasTest = hasTest;

                        // Определяем статус модуля и отображение
                        if (hasTest)
                        {
                            var test = modulesTests[dbModule.module_ID];
                            
                            // Проверяем, есть ли результат теста
                            if (latestTestResults.ContainsKey(test.test_ID))
                            {
                                var testResult = latestTestResults[test.test_ID];
                                
                                // Сохраняем данные о результате теста в словаре
                                var resultData = new Dictionary<string, object>();
                                
                                // Безопасное добавление значений с проверкой на наличие ключа
                                resultData["test_ID"] = testResult.test_ID;
                                
                                // Проверяем каждое значение перед добавлением
                                if (testResult.is_passed.HasValue)
                                    resultData["is_passed"] = testResult.is_passed.Value;
                                else
                                    resultData["is_passed"] = null;
                                    
                                if (testResult.score.HasValue)
                                    resultData["score"] = testResult.score.Value;
                                else
                                    resultData["score"] = null;
                                    
                                if (testResult.correct_answers.HasValue)
                                    resultData["correct_answers"] = testResult.correct_answers.Value;
                                else
                                    resultData["correct_answers"] = null;
                                    
                                if (testResult.total_questions.HasValue)
                                    resultData["total_questions"] = testResult.total_questions.Value;
                                else
                                    resultData["total_questions"] = null;
                                
                                moduleWithStatus.TestResults.Add(resultData);
                                
                                // Расчёт процента правильных ответов
                                double percentCorrect = 0;
                                bool isPassed = false;
                                
                                // Проверяем флаг is_passed
                                if (testResult.is_passed.HasValue)
                                {
                                    isPassed = testResult.is_passed.Value;
                                }
                                
                                // Если у нас есть score, используем его для отображения
                                if (testResult.score.HasValue)
                                {
                                    percentCorrect = (double)testResult.score.Value;
                                    
                                    // Если флаг is_passed не установлен, определяем по score
                                    if (!testResult.is_passed.HasValue)
                                    {
                                        isPassed = percentCorrect >= 70;
                                    }
                                }
                                // Иначе вычисляем из correct_answers/total_questions
                                else if (testResult.correct_answers.HasValue && testResult.total_questions.HasValue 
                                        && testResult.total_questions.Value > 0)
                                {
                                    percentCorrect = (double)testResult.correct_answers.Value / testResult.total_questions.Value * 100;
                                    
                                    // Если флаг is_passed не установлен, определяем по проценту
                                    if (!testResult.is_passed.HasValue)
                                    {
                                        isPassed = percentCorrect >= 70;
                                    }
                                }
                                
                                // Устанавливаем статус и стиль в зависимости от прохождения теста
                                if (isPassed)
                                {
                                    // Модуль пройден полностью
                                    moduleWithStatus.ModuleStatus = "✓";
                                    moduleWithStatus.StatusForeground = Brushes.Green;
                                    moduleWithStatus.TestStatus = $"Пройден ({Math.Round(percentCorrect)}%)";
                                    moduleWithStatus.TestStatusForeground = Brushes.Green;
                                }
                                else
                                {
                                    // Модуль изучен, но тест не пройден
                                    moduleWithStatus.ModuleStatus = "◐";
                                    moduleWithStatus.StatusForeground = Brushes.Orange;
                                    moduleWithStatus.TestStatus = $"Не пройден ({Math.Round(percentCorrect)}%)";
                                    moduleWithStatus.TestStatusForeground = Brushes.Red;
                                }
                            }
                            else
                            {
                                // У модуля есть тест, но он еще не пройден
                                moduleWithStatus.ModuleStatus = "○";
                                moduleWithStatus.StatusForeground = Brushes.Gray;
                                moduleWithStatus.TestStatus = "Не пройден";
                                moduleWithStatus.TestStatusForeground = Brushes.Gray;
                            }
                        }
                        else
                        {
                            // У модуля нет теста - считаем его автоматически пройденным после просмотра
                            moduleWithStatus.ModuleStatus = "✓";
                            moduleWithStatus.StatusForeground = Brushes.Green;
                        }
                        
                        _modules.Add(moduleWithStatus);
                    }
                    
                    // 5. Обновляем отображение в ListView
                    modulesListView.ItemsSource = null;
                    modulesListView.ItemsSource = _modules;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при загрузке модулей курса: {ex.Message}\n\nStackTrace: {ex.StackTrace}");
            }
        }

        private void LoadFinalExam()
        {
            try
            {
                // Получаем ID курса и пользователя локально
                int courseId = _course.course_ID;
                int userId = _currentUser.users_ID;
                
                // Создаем локальную копию для хранения найденного экзамена
                exam loadedExam = null;
                
                // Используем новый контекст вместо общего Entities.GetContext()
                using (var dbContext = new Entities())
                {
                    // Ищем итоговый экзамен для курса
                    var dbExam = dbContext.exams
                        .Where(examObj => examObj.course_ID == courseId)
                        .FirstOrDefault();
                    
                    // Если экзамен найден, создаем его копию и загружаем свойства в память
                    if (dbExam != null)
                    {
                        loadedExam = new exam
                        {
                            exam_ID = dbExam.exam_ID,
                            course_ID = dbExam.course_ID,
                            duration = dbExam.duration,
                            attempts = dbExam.attempts,
                            exam_date = dbExam.exam_date
                        };
                        
                        // Создаем локальную переменную для ID экзамена
                        int examIdLocal = dbExam.exam_ID;
                        
                        // Получаем результаты экзамена для текущего пользователя - загружаем все и фильтруем в памяти
                        var allExamResults = dbContext.exam_results.ToList();
                        var examResults = allExamResults
                            .Where(er => er.exam_ID == examIdLocal && er.users_ID == userId)
                            .OrderByDescending(er => er.result_date)
                            .ToList();
                        
                        // Отображаем последний результат экзамена
                        if (examResults.Count > 0)
                        {
                            var lastResult = examResults.First();
                            
                            // Создаем текст для отображения результата
                            decimal score = lastResult.score ?? 0;
                            string resultText = $"Результат экзамена: {score:F1}%";
                            string passStatus = score >= 70 ? "Пройден" : "Не пройден";
                            
                            // Устанавливаем текст в соответствующий элемент UI
                            if (examResultTextBlock != null)
                            {
                                examResultTextBlock.Text = $"{resultText} ({passStatus})";
                                examResultTextBlock.Foreground = score >= 70 ? Brushes.Green : Brushes.Red;
                                examResultTextBlock.Visibility = Visibility.Visible;
                            }
                            
                            // Изменяем текст кнопки экзамена, если экзамен уже пройден
                            if (finalExamButton != null)
                            {
                                bool isPassed = score >= 70;
                                finalExamButton.Content = isPassed ? "Пройти экзамен повторно" : "Пересдать экзамен";
                                
                                // Настраиваем визуальное оформление кнопки в зависимости от результата
                                if (isPassed)
                                {
                                    // Если экзамен пройден, делаем кнопку менее заметной
                                    finalExamButton.Background = new SolidColorBrush(Colors.LightGray);
                                    finalExamButton.BorderBrush = new SolidColorBrush(Colors.Gray);
                                }
                                else
                                {
                                    // Если не пройден, делаем кнопку более заметной
                                    finalExamButton.Background = new SolidColorBrush(Colors.LightCoral);
                                    finalExamButton.BorderBrush = new SolidColorBrush(Colors.Red);
                                }
                            }
                            
                            System.Diagnostics.Debug.WriteLine($"[CourseContentPage] Отображаем результаты экзамена: {score:F1}%");
                        }
                        else
                        {
                            // Если результатов нет, скрываем текст результата
                            if (examResultTextBlock != null)
                            {
                                examResultTextBlock.Visibility = Visibility.Collapsed;
                            }
                            
                            // Настраиваем текст кнопки для первой попытки
                            if (finalExamButton != null)
                            {
                                finalExamButton.Content = "Пройти итоговый экзамен";
                                finalExamButton.Background = new SolidColorBrush(Colors.LightBlue);
                                finalExamButton.BorderBrush = new SolidColorBrush(Colors.Blue);
                            }
                            
                            System.Diagnostics.Debug.WriteLine("[CourseContentPage] Результаты экзамена не найдены");
                        }
                    }
                }
                
                // Сохраняем найденный экзамен в поле класса
                _finalExam = loadedExam;

                // Показываем или скрываем кнопку экзамена
                finalExamButton.Visibility = _finalExam != null ? Visibility.Visible : Visibility.Collapsed;
            }
            catch (Exception exception)
            {
                MessageBox.Show($"Ошибка при загрузке информации об экзамене: {exception.Message}");
            }
        }

        private void UpdateCourseProgress()
        {
            try
            {
                // Использование CourseGradeHelper для расчета прогресса
                using (var context = new Entities())
                {
                    // Создаем helper и получаем информацию о прогрессе
                    var gradeHelper = new CourseGradeHelper(context);
                    var progressInfo = gradeHelper.CalculateCourseProgress(_course.course_ID, _currentUser.users_ID);
                    
                    // Обновляем элементы UI
                    courseProgressBar.Value = progressInfo.ProgressPercentage;
                    progressTextBlock.Text = $"Прогресс: {progressInfo.ProgressPercentage:F1}% ({progressInfo.CompletedModules}/{progressInfo.TotalModules} модулей)";
                    
                    // Обновляем оценку в базе данных
                    CourseGradeHelper.UpdateCourseGrade(_currentUser, _course, progressInfo.ProgressPercentage);
                    
                    // Загружаем текущую оценку и обновляем UI
                    var courseGrade = context.course_grades
                        .FirstOrDefault(cg => cg.users_ID == _currentUser.users_ID && cg.course_ID == _course.course_ID);
                    
                    if (courseGrade != null && courseGrade.grade > 0)
                    {
                        gradeTextBlock.Text = $"Оценка: {courseGrade.grade}";
                    }
                    else
                    {
                        gradeTextBlock.Text = "Оценка: не выставлена";
                    }
                    
                    // Проверяем, все ли модули пройдены для активации экзамена (минимум 70%)
                    if (progressInfo.ProgressPercentage >= 70)
                    {
                        finalExamButton.IsEnabled = true;
                    }
                    else
                    {
                        finalExamButton.IsEnabled = false;
                        finalExamButton.Content = $"Для доступа к экзамену пройдите минимум 70% модулей ({progressInfo.CompletedModules}/{progressInfo.TotalModules})";
                    }
                }
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine($"Ошибка при обновлении прогресса: {ex.Message}");
            }
        }

        private void BackButton_Click(object sender, RoutedEventArgs eventArgs)
        {
            try
            {
                NavigationService.Navigate(new MyCoursesPage(_currentUser));
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при возвращении к списку курсов: {ex.Message}");
            }
        }

        private void ModulesListView_SelectionChanged(object sender, SelectionChangedEventArgs eventArgs)
        {
            try
            {
                // Очищаем выделение
                modulesListView.SelectedItem = null;
            }
            catch (Exception ex)
            {
                // Логирование ошибки, если необходимо
                System.Diagnostics.Debug.WriteLine($"Ошибка при очистке выбора: {ex.Message}");
            }
        }

        private void OpenModuleButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (sender is Button button && button.Tag is int moduleId)
                {
                    // Находим модуль в локальном списке
                    var selectedModule = _modules.FirstOrDefault(m => m.module_ID == moduleId);
                    if (selectedModule != null)
                    {
                        // Создаем новый объект module с данными из локального списка
                        var moduleToNavigate = new module
                        {
                            module_ID = selectedModule.module_ID,
                            module_name = selectedModule.module_name,
                            module_description = selectedModule.module_description,
                            course_ID = selectedModule.course_ID
                        };
                        
                        // Сбрасываем контекст перед навигацией
                        Entities.ResetContext();
                        
                        // Навигация с локальной копией модуля
                        NavigationService.Navigate(new ModuleContentPage(_currentUser, _course, moduleToNavigate));
                    }
                    else
                    {
                        MessageBox.Show("Не удалось найти информацию о модуле.");
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при открытии модуля: {ex.Message}\n\nStackTrace: {ex.StackTrace}");
            }
        }

        private void FinalExamButton_Click(object sender, RoutedEventArgs examEvent)
        {
            try
            {
                // Проверяем доступность экзамена (минимум 70% модулей должны быть пройдены)
                int totalModules = _modules?.Count ?? 0;
                int completedModules = _modules?.Count(m => m.ModuleStatus == "✓") ?? 0;
                
                if (completedModules < totalModules * 0.7)
                {
                    MessageBox.Show($"Для доступа к итоговому экзамену необходимо пройти минимум 70% модулей курса. " +
                                   $"Текущий прогресс: {completedModules} из {totalModules} модулей.",
                                   "Доступ к экзамену", MessageBoxButton.OK, MessageBoxImage.Information);
                    return;
                }
                
                // Проверяем, загружен ли финальный экзамен
                if (_finalExam == null)
                {
                    MessageBox.Show("Итоговый экзамен для данного курса не настроен.", 
                                   "Экзамен недоступен", MessageBoxButton.OK, MessageBoxImage.Information);
                    return;
                }
                
                // Проверяем, уже пройден ли экзамен успешно
                using (var context = new Entities())
                {
                    var existingResult = context.exam_results
                        .Where(er => er.users_ID == _currentUser.users_ID && er.exam_ID == _finalExam.exam_ID && er.score.HasValue && er.score.Value >= 70)
                        .OrderByDescending(er => er.result_date)
                        .FirstOrDefault();
                        
                    if (existingResult != null)
                    {
                        // Экзамен уже успешно пройден
                        var response = MessageBox.Show($"Вы уже успешно сдали итоговый экзамен {existingResult.result_date.Value.ToString("dd.MM.yyyy")} с результатом {existingResult.score}%. Хотите пройти экзамен еще раз?",
                                                    "Экзамен пройден", MessageBoxButton.YesNo, MessageBoxImage.Question);
                        
                        if (response != MessageBoxResult.Yes)
                        {
                            return;
                        }
                    }
                }
                
                // Переходим к экзамену
                Entities.ResetContext();
                
                // Создаем страницу теста для прохождения экзамена
                var testPage = new TestPage(_currentUser, _course, null, _finalExam);
                NavigationService.Navigate(testPage);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при открытии итогового экзамена: {ex.Message}");
            }
        }
    }
} 