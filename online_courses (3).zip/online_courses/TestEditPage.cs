using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Data.Entity;
using System.Windows.Media;

namespace online_courses
{
    /// <summary>
    /// Класс-прокси для обеспечения обратной совместимости
    /// Перенаправляет вызовы TestEditPage на TestEditorPage
    /// </summary>
    public partial class TestEditPage : Page, IPageRefresh
    {
        // UI elements from XAML
        private TextBox testNameTextBox;
        private ListView questionsListView;
        
        private readonly user _currentUser;
        private readonly test _test;
        private ObservableCollection<QuestionItem> _questions = new ObservableCollection<QuestionItem>();

        public class QuestionItem
        {
            public int QuestionID { get; set; }
            public string Question { get; set; }
            public string Options { get; set; }
            public string CorrectAnswer { get; set; }
            public List<string> OptionsList { get; set; }
            public bool IsNew { get; set; }
            
            public override string ToString()
            {
                return Question;
            }
        }

        public TestEditPage(user currentUser, test test)
        {
            InitializeComponent();
            _currentUser = currentUser ?? throw new ArgumentNullException(nameof(currentUser));
            _test = test ?? throw new ArgumentNullException(nameof(test));
            questionsListView.ItemsSource = _questions;
            LoadData();
        }

        private void InitializeComponent()
        {
            // Create main grid
            var mainGrid = new Grid();
            mainGrid.Margin = new Thickness(20);
            
            // Add row definitions
            mainGrid.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
            mainGrid.RowDefinitions.Add(new RowDefinition { Height = new GridLength(1, GridUnitType.Star) });
            mainGrid.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
            
            // Create header panel
            var headerPanel = new StackPanel();
            Grid.SetRow(headerPanel, 0);
            
            // Add header elements
            var titleTextBlock = new TextBlock
            {
                Text = "Редактирование теста",
                FontSize = 24,
                FontWeight = FontWeights.Bold,
                Margin = new Thickness(0, 0, 0, 10)
            };
            
            testNameTextBox = new TextBox
            {
                IsReadOnly = true,
                Margin = new Thickness(0, 0, 0, 10)
            };
            
            var questionsLabel = new TextBlock
            {
                Text = "Вопросы теста:",
                FontWeight = FontWeights.SemiBold,
                Margin = new Thickness(0, 0, 0, 5)
            };
            
            headerPanel.Children.Add(titleTextBlock);
            headerPanel.Children.Add(testNameTextBox);
            headerPanel.Children.Add(questionsLabel);
            
            // Create questions list view
            questionsListView = new ListView
            {
                Margin = new Thickness(0, 5, 0, 15)
            };
            Grid.SetRow(questionsListView, 1);
            
            // Create buttons panel
            var buttonsPanel = new StackPanel
            {
                Orientation = Orientation.Horizontal
            };
            Grid.SetRow(buttonsPanel, 2);
            
            var addButton = new Button
            {
                Content = "Добавить вопрос",
                Width = 150,
                Height = 30,
                Background = new SolidColorBrush(Color.FromRgb(0, 122, 204)),
                Foreground = Brushes.White,
                HorizontalAlignment = HorizontalAlignment.Left,
                Margin = new Thickness(0, 0, 10, 0)
            };
            addButton.Click += AddQuestionButton_Click;
            
            var cancelButton = new Button
            {
                Content = "Отмена",
                Width = 100,
                Height = 30,
                Margin = new Thickness(0, 0, 10, 0)
            };
            cancelButton.Click += CancelButton_Click;
            
            var saveButton = new Button
            {
                Content = "Сохранить",
                Width = 100,
                Height = 30,
                Background = new SolidColorBrush(Color.FromRgb(0, 122, 204)),
                Foreground = Brushes.White
            };
            saveButton.Click += SaveButton_Click;
            
            buttonsPanel.Children.Add(addButton);
            buttonsPanel.Children.Add(cancelButton);
            buttonsPanel.Children.Add(saveButton);
            
            // Add all elements to the grid
            mainGrid.Children.Add(headerPanel);
            mainGrid.Children.Add(questionsListView);
            mainGrid.Children.Add(buttonsPanel);
            
            // Set content
            this.Content = mainGrid;
        }

        public void RefreshData()
        {
            LoadData();
        }

        private void LoadData()
        {
            try
            {
                using (var context = new Entities())
                {
                    // Загружаем связанные данные о тесте
                    var test = context.tests
                        .FirstOrDefault(t => t.test_ID == _test.test_ID);

                    if (test != null)
                    {
                        // Заполняем данные теста
                        testNameTextBox.Text = "Тест для модуля #" + test.module_ID;
                        
                        _questions.Clear(); // Очищаем коллекцию перед добавлением
                        
                        // Основной вопрос из теста
                        if (!string.IsNullOrEmpty(test.question))
                        {
                            var questionItem = new QuestionItem
                            {
                                QuestionID = test.test_ID,
                                Question = test.question,
                                Options = test.answer_options,
                                CorrectAnswer = test.correct_answer,
                                OptionsList = test.answer_options?.Split(';').ToList() ?? new List<string>(),
                                IsNew = false
                            };
                            
                            _questions.Add(questionItem);
                        }
                        
                        // Загружаем дополнительные вопросы для этого теста
                        var additionalQuestions = context.tests
                            .Where(t => t.module_ID == test.module_ID && t.test_ID != test.test_ID)
                            .ToList();
                            
                        foreach (var question in additionalQuestions)
                        {
                            var exists = _questions.Any(q => q.QuestionID == question.test_ID);
                            if (!exists)
                            {
                                _questions.Add(new QuestionItem
                                {
                                    QuestionID = question.test_ID,
                                    Question = question.question,
                                    Options = question.answer_options,
                                    CorrectAnswer = question.correct_answer,
                                    OptionsList = question.answer_options?.Split(';').ToList() ?? new List<string>(),
                                    IsNew = false
                                });
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при загрузке данных: {ex.Message}");
            }
        }

        private void SaveButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                using (var context = new Entities())
                {
                    // Получаем тест из базы данных
                    var testToUpdate = context.tests.FirstOrDefault(t => t.test_ID == _test.test_ID);
                    if (testToUpdate != null && _questions.Count > 0)
                    {
                        // Обновляем основной вопрос теста
                        var mainQuestion = _questions[0];
                        testToUpdate.question = mainQuestion.Question;
                        testToUpdate.answer_options = mainQuestion.Options;
                        testToUpdate.correct_answer = mainQuestion.CorrectAnswer;

                        // Сохраняем или обновляем дополнительные вопросы
                        for (int i = 1; i < _questions.Count; i++)
                        {
                            var questionItem = _questions[i];
                            
                            if (questionItem.IsNew)
                            {
                                // Создаем новый вопрос
                                var newQuestion = new test
                                {
                                    module_ID = testToUpdate.module_ID,
                                    question = questionItem.Question,
                                    answer_options = questionItem.Options,
                                    correct_answer = questionItem.CorrectAnswer
                                };
                                
                                context.tests.Add(newQuestion);
                            }
                            else
                            {
                                // Обновляем существующий вопрос
                                var questionToUpdate = context.tests.FirstOrDefault(q => q.test_ID == questionItem.QuestionID);
                                if (questionToUpdate != null)
                                {
                                    questionToUpdate.question = questionItem.Question;
                                    questionToUpdate.answer_options = questionItem.Options;
                                    questionToUpdate.correct_answer = questionItem.CorrectAnswer;
                                }
                            }
                        }

                        // Сохраняем изменения
                        context.SaveChanges();
                        MessageBox.Show("Тест успешно сохранен");
                        
                        // Возвращаемся на предыдущую страницу
                        if (NavigationService.CanGoBack)
                        {
                            NavigationService.GoBack();
                            
                            // Обновляем страницу модуля
                            if (NavigationService.Content is ModuleEditPage modulePage)
                            {
                                modulePage.RefreshData();
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при сохранении теста: {ex.Message}");
            }
        }

        private void CancelButton_Click(object sender, RoutedEventArgs e)
        {
            if (NavigationService.CanGoBack)
            {
                NavigationService.GoBack();
            }
        }

        private void AddQuestionButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                // Создаем новый вопрос
                var newQuestionItem = new QuestionItem
                {
                    QuestionID = -1 * _questions.Count, // Временный отрицательный ID для новых вопросов
                    Question = "Новый вопрос",
                    Options = "Вариант 1;Вариант 2;Вариант 3;Вариант 4",
                    CorrectAnswer = "1",
                    OptionsList = new List<string> { "Вариант 1", "Вариант 2", "Вариант 3", "Вариант 4" },
                    IsNew = true
                };
                
                // Добавляем вопрос в коллекцию
                _questions.Add(newQuestionItem);
                
                // Создаем объект test для редактирования
                var testToEdit = new test
                {
                    test_ID = newQuestionItem.QuestionID, // Используем временный ID
                    question = newQuestionItem.Question,
                    answer_options = newQuestionItem.Options,
                    correct_answer = newQuestionItem.CorrectAnswer,
                    module_ID = _test.module_ID
                };
                
                // Создаем и показываем страницу TestEditorPage
                var editorPage = new TestEditorPage(_currentUser, testToEdit);
                
                // Создаем окно для отображения редактора
                var editorWindow = new Window
                {
                    Title = "Добавление вопроса",
                    Content = editorPage,
                    Width = 600,
                    Height = 500,
                    WindowStartupLocation = WindowStartupLocation.CenterScreen,
                    Owner = Window.GetWindow(this)
                };
                
                // Обработчик закрытия окна для обновления данных
                editorWindow.Closed += AddQuestionWindow_Closed;
                
                // Показываем окно
                editorWindow.ShowDialog();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при добавлении вопроса: {ex.Message}");
            }
        }

        private void AddQuestionWindow_Closed(object sender, EventArgs e)
        {
            // Обновляем только что добавленный вопрос
            // Примечание: ID вопроса будет обновлен при сохранении
            questionsListView.Items.Refresh();
            // Прокручиваем список к новому вопросу
            questionsListView.ScrollIntoView(_questions[_questions.Count - 1]);
        }

        private void EditQuestionButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                // Получаем кнопку, которая была нажата
                var button = sender as Button;
                if (button != null && button.Tag is QuestionItem questionItem)
                {
                    // Напрямую используем QuestionItem из Tag
                    EditQuestion(questionItem);
                }
                else
                {
                    MessageBox.Show("Не удалось определить редактируемый вопрос. Пожалуйста, попробуйте еще раз.");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при редактировании вопроса: {ex.Message}");
            }
        }

        private void DeleteQuestionButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                var button = sender as Button;
                if (button != null && button.Tag is QuestionItem questionItem)
                {
                    // Не удаляем первый вопрос, если это единственный вопрос в тесте
                    if (_questions.Count <= 1 && _questions[0] == questionItem)
                    {
                        MessageBox.Show("Нельзя удалить единственный вопрос теста. Тест должен содержать хотя бы один вопрос.");
                        return;
                    }
                    
                    var dialogResult = MessageBox.Show("Вы уверены, что хотите удалить этот вопрос?", 
                        "Подтверждение удаления", MessageBoxButton.YesNo, MessageBoxImage.Warning);
                        
                    if (dialogResult == MessageBoxResult.Yes)
                    {
                        // Удаляем вопрос из коллекции
                        _questions.Remove(questionItem);
                        
                        // Если это не новый вопрос, удаляем его из базы данных
                        if (!questionItem.IsNew)
                        {
                            try
                            {
                                using (var context = new Entities())
                                {
                                    var questionToDelete = context.tests.FirstOrDefault(q => q.test_ID == questionItem.QuestionID);
                                    if (questionToDelete != null)
                                    {
                                        // Удаляем связанные результаты тестов
                                        var testResults = context.test_results.Where(tr => tr.test_ID == questionItem.QuestionID).ToList();
                                        foreach (var result in testResults)
                                        {
                                            context.test_results.Remove(result);
                                        }
                                        
                                        // Удаляем сам вопрос
                                        context.tests.Remove(questionToDelete);
                                        context.SaveChanges();
                                    }
                                }
                            }
                            catch (Exception ex)
                            {
                                MessageBox.Show($"Ошибка при удалении вопроса: {ex.Message}");
                            }
                        }
                    }
                }
                else
                {
                    MessageBox.Show("Не удалось определить вопрос для удаления.");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при удалении вопроса: {ex.Message}");
            }
        }

        private void EditQuestion(QuestionItem questionItem)
        {
            try
            {
                // Создаем объект test для редактирования
                var testToEdit = new test
                {
                    test_ID = questionItem.QuestionID,
                    question = questionItem.Question,
                    answer_options = questionItem.Options,
                    correct_answer = questionItem.CorrectAnswer,
                    module_ID = _test.module_ID
                };
                
                // Создаем и показываем страницу TestEditorPage
                var editorPage = new TestEditorPage(_currentUser, testToEdit);
                
                // Создаем окно для отображения редактора
                var editorWindow = new Window
                {
                    Title = "Редактирование вопроса",
                    Content = editorPage,
                    Width = 600,
                    Height = 500,
                    WindowStartupLocation = WindowStartupLocation.CenterScreen,
                    Owner = Window.GetWindow(this)
                };
                
                // Сохраняем ссылку на QuestionItem для использования в обработчике
                editorWindow.Tag = questionItem;
                
                // Обработчик закрытия окна для обновления данных
                editorWindow.Closed += EditorWindow_Closed;
                
                // Показываем окно
                editorWindow.ShowDialog();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при открытии редактора вопросов: {ex.Message}");
            }
        }
        
        private void EditorWindow_Closed(object sender, EventArgs e)
        {
            if (sender is Window window && window.Tag is QuestionItem questionItem)
            {
                // После закрытия окна обновляем данные в нашем списке
                using (var context = new Entities())
                {
                    var updatedTest = context.tests.FirstOrDefault(t => t.test_ID == questionItem.QuestionID);
                    if (updatedTest != null)
                    {
                        questionItem.Question = updatedTest.question;
                        questionItem.Options = updatedTest.answer_options;
                        questionItem.CorrectAnswer = updatedTest.correct_answer;
                        questionItem.OptionsList = updatedTest.answer_options?.Split(';').ToList() ?? new List<string>();
                        
                        // Обновляем интерфейс
                        questionsListView.Items.Refresh();
                    }
                }
            }
        }
    }
} 
