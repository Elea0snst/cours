using System;
using System.Linq;
using System.Windows;
using System.Windows.Controls;

namespace online_courses
{
    public partial class CourseCreationPage : Page
    {
        private readonly user _currentUser;

        public CourseCreationPage(user user)
        {
            InitializeComponent();
            _currentUser = user ?? throw new ArgumentNullException(nameof(user));
            LoadCategories();
        }

        private void LoadCategories()
        {
            try
            {
                using (var context = new Entities())
                {
                    // Загружаем категории
                    var categories = context.categories.ToList();
                    categoryComboBox.ItemsSource = categories;
                    
                    // Выбираем первую категорию по умолчанию, если они есть
                    if (categories.Any())
                    {
                        categoryComboBox.SelectedIndex = 0;
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при загрузке категорий: {ex.Message}");
            }
        }

        private void CancelButton_Click(object sender, RoutedEventArgs e)
        {
            // Возвращаемся на предыдущую страницу
            if (NavigationService.CanGoBack)
            {
                NavigationService.GoBack();
            }
        }

        private void CreateCourseButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                // Проверяем заполнение обязательных полей
                if (string.IsNullOrWhiteSpace(courseNameTextBox.Text))
                {
                    MessageBox.Show("Введите название курса");
                    return;
                }

                if (categoryComboBox.SelectedItem == null)
                {
                    MessageBox.Show("Выберите категорию курса");
                    return;
                }

                using (var context = new Entities())
                {
                    // Создаем новый курс
                    var newCourse = new cours
                    {
                        course_name = courseNameTextBox.Text,
                        course_description = courseDescriptionTextBox.Text,
                        course_author = _currentUser.users_ID,
                        course_category = ((category)categoryComboBox.SelectedItem).category_ID
                    };

                    // Добавляем курс в базу данных
                    context.courses.Add(newCourse);
                    context.SaveChanges();

                    MessageBox.Show("Курс успешно создан");

                    // Создаем копию нового курса для редактирования
                    var courseCopy = new cours
                    {
                        course_ID = newCourse.course_ID,
                        course_name = newCourse.course_name,
                        course_description = newCourse.course_description,
                        course_author = newCourse.course_author,
                        course_category = newCourse.course_category
                    };

                    // Переходим на страницу редактирования курса, чтобы добавить модули
                    NavigationService.Navigate(new CourseEditPage(_currentUser, courseCopy));
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при создании курса: {ex.Message}");
            }
        }
    }
} 