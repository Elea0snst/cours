using System;
using System.Windows;
using System.Windows.Controls;

namespace online_courses
{
    public partial class AccessCodeWindow : Window
    {
        private users _user;

        public AccessCodeWindow(users user)
        {
            InitializeComponent();
            _user = user;
            Title = "Введите код доступа";
        }

        private void VerifyButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                string enteredCode = accessCodeBox.Password.Trim();

                if (string.IsNullOrEmpty(enteredCode))
                {
                    MessageBox.Show("Пожалуйста, введите код доступа.", 
                                   "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                    return;
                }

                // Проверяем код доступа
                if (VerifyAccessCode(enteredCode))
                {
                    DialogResult = true;
                    Close();
                }
                else
                {
                    MessageBox.Show("Неверный код доступа.", 
                                   "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при проверке кода: {ex.Message}", 
                               "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private bool VerifyAccessCode(string enteredCode)
        {
            return RoleAccessCode.VerifyAccessCode(_user.users_role_ID, enteredCode);
        }

        private void CancelButton_Click(object sender, RoutedEventArgs e)
        {
            DialogResult = false;
            Close();
        }
    }
} 