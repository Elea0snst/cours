using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Data.Entity;

namespace online_courses
{
    // Make sure ExamEditPage is referenced
    using ExamPage = online_courses.ExamEditPage;
    
    public partial class CourseEditPage : Page, IPageRefresh
    {
        private readonly user _currentUser;
        private cours _course;
        private List<module> _modules;
        
        // Класс-обертка для отображения модуля с дополнительной информацией
        private class ModuleViewModel
        {
            public int module_ID { get; set; }
            public string module_name { get; set; }
            public string Description { get; set; }
            public int TestCount { get; set; }
            public int course_ID { get; set; }
            
            public static ModuleViewModel FromModule(module m)
            {
                return new ModuleViewModel
                {
                    module_ID = m.module_ID,
                    module_name = m.module_name,
                    Description = m.module_description?.Length > 50 ? 
                        m.module_description.Substring(0, 50) + "..." : 
                        m.module_description,
                    TestCount = m.tests?.Count ?? 0,
                    course_ID = m.course_ID.HasValue ? m.course_ID.Value : 0
                };
            }
        }

        public CourseEditPage(user currentUser, cours course)
        {
            InitializeComponent();
            _currentUser = currentUser ?? throw new ArgumentNullException(nameof(currentUser));
            _course = course ?? throw new ArgumentNullException(nameof(course));
            LoadData();
        }

        public void RefreshData()
        {
            LoadData();
        }

        private void LoadData()
        {
            try
            {
                // Сбрасываем контекст для получения свежих данных
                Entities.ResetContext();
                
                // Получаем ID курса локально
                int courseId = _course.course_ID;
                
                using (var context = new Entities())
                {
                    // Загружаем категории
                    var categories = context.categories.ToList();
                    categoryComboBox.ItemsSource = categories;
                    
                    // Загружаем модули курса с включением связанных данных
                    _modules = context.modules
                        .Include("tests")  // Включаем тесты
                        .Where(m => m.course_ID == courseId)
                        .OrderBy(m => m.module_ID)
                        .ToList();
                    
                    // Загружаем связанные данные курса
                    _course = context.courses
                        .Include("user")
                        .Include("category")
                        .Include("exams")  // Включаем экзамены
                        .FirstOrDefault(c => c.course_ID == courseId);
                    
                    // Проверяем, есть ли модули
                    if (_modules.Count == 0)
                    {
                        modulesListView.Visibility = System.Windows.Visibility.Collapsed;
                    }
                    else
                    {
                        // Создаем список модулей с дополнительной информацией
                        var moduleViewModels = _modules.Select(ModuleViewModel.FromModule).ToList();
                        
                        // Выводим отладочную информацию
                        foreach (var vm in moduleViewModels)
                        {
                            System.Diagnostics.Debug.WriteLine($"[CourseEditPage] Модуль ID={vm.module_ID}, Название={vm.module_name}, Тестов={vm.TestCount}");
                        }
                        
                        modulesListView.Visibility = System.Windows.Visibility.Visible;
                        modulesListView.ItemsSource = moduleViewModels;
                    }

                    // Обновляем статус экзамена
                    var exam = _course.exams.FirstOrDefault();
                    if (exam != null)
                    {
                        examStatusTextBlock.Text = "Экзамен создан";
                        editExamButton.Content = "Редактировать экзамен";
                    }
                    else
                    {
                        examStatusTextBlock.Text = "Экзамен не создан";
                        editExamButton.Content = "Создать экзамен";
                    }

                    // Устанавливаем текущие значения
                    courseNameTextBox.Text = _course.course_name;
                    courseDescriptionTextBox.Text = _course.course_description;
                    categoryComboBox.SelectedItem = categories.FirstOrDefault(c => c.category_ID == _course.course_category);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при загрузке данных: {ex.Message}");
            }
        }

        private void SaveButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(courseNameTextBox.Text))
                {
                    MessageBox.Show("Введите название курса");
                    return;
                }

                if (categoryComboBox.SelectedItem == null)
                {
                    MessageBox.Show("Выберите категорию курса");
                    return;
                }

                // Получаем ID курса локально
                int courseId = _course.course_ID;
                
                using (var context = new Entities())
                {
                    // Получаем курс из базы данных
                    var courseToUpdate = context.courses.FirstOrDefault(c => c.course_ID == courseId);
                    if (courseToUpdate != null)
                    {
                        // Обновляем данные курса
                        courseToUpdate.course_name = courseNameTextBox.Text;
                        courseToUpdate.course_description = courseDescriptionTextBox.Text;
                        courseToUpdate.course_category = ((category)categoryComboBox.SelectedItem).category_ID;

                        // Сохраняем изменения
                        context.SaveChanges();

                        MessageBox.Show("Курс успешно обновлен");
                        
                        // Возвращаемся на страницу курсов
                        if (NavigationService.CanGoBack)
                        {
                            NavigationService.GoBack();
                            
                            // Обновляем страницу курсов
                            if (NavigationService.Content is TeacherCoursesPage coursesPage)
                            {
                                coursesPage.RefreshData();
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при сохранении курса: {ex.Message}");
            }
        }

        private void CancelButton_Click(object sender, RoutedEventArgs e)
        {
            if (NavigationService.CanGoBack)
            {
                NavigationService.GoBack();
            }
        }

        private void DeleteButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                // Запрашиваем подтверждение удаления
                var confirmResult = MessageBox.Show(
                    "Вы действительно хотите удалить этот курс? Будут также удалены все связанные модули, тесты и результаты студентов. Это действие нельзя отменить.",
                    "Подтверждение удаления",
                    MessageBoxButton.YesNo,
                    MessageBoxImage.Warning);

                if (confirmResult == MessageBoxResult.Yes)
                {
                    // Получаем ID курса локально
                    int courseId = _course.course_ID;
                    
                    using (var context = new Entities())
                    {
                        // Находим курс в базе данных
                        var courseToDelete = context.courses.FirstOrDefault(c => c.course_ID == courseId);
                        if (courseToDelete != null)
                        {
                            // Находим все модули курса
                            var modules = context.modules.Where(m => m.course_ID == courseId).ToList();
                            
                            foreach (var module in modules)
                            {
                                // Сохраняем ID модуля локально
                                int moduleId = module.module_ID;
                                
                                // Находим связанные тесты
                                var tests = context.tests.Where(t => t.module_ID == moduleId).ToList();
                                
                                // Удаляем результаты тестов
                                foreach (var test in tests)
                                {
                                    // Сохраняем ID теста локально
                                    int testId = test.test_ID;
                                    
                                    var testResults = context.test_results.Where(tr => tr.test_ID == testId).ToList();
                                    foreach (var testResult in testResults)
                                    {
                                        context.test_results.Remove(testResult);
                                    }
                                    
                                    // Удаляем сам тест
                                    context.tests.Remove(test);
                                }
                                
                                // Удаляем модуль
                                context.modules.Remove(module);
                            }
                            
                            // Удаляем оценки курса
                            var courseGrades = context.course_grades.Where(cg => cg.course_ID == courseId).ToList();
                            foreach (var grade in courseGrades)
                            {
                                context.course_grades.Remove(grade);
                            }
                            
                            // Удаляем отзывы о курсе
                            var courseReviews = context.course_reviews.Where(cr => cr.course_ID == courseId).ToList();
                            foreach (var review in courseReviews)
                            {
                                context.course_reviews.Remove(review);
                            }
                            
                            // Удаляем экзамены курса
                            var exams = context.exams.Where(exam => exam.course_ID == courseId).ToList();
                            foreach (var exam in exams)
                            {
                                // Сохраняем ID экзамена локально
                                int examId = exam.exam_ID;
                                
                                // Удаляем результаты экзаменов - загружаем все и фильтруем в памяти
                                var allExamResults = context.exam_results.ToList();
                                var examResults = allExamResults.Where(er => er.exam_ID == examId).ToList();
                                foreach (var examResult in examResults)
                                {
                                    context.exam_results.Remove(examResult);
                                }
                                
                                // Удаляем сам экзамен
                                context.exams.Remove(exam);
                            }

                            // Удаляем сам курс
                            context.courses.Remove(courseToDelete);
                            context.SaveChanges();

                            MessageBox.Show("Курс успешно удален");

                            // Возвращаемся на предыдущую страницу и обеспечиваем обновление списка
                            if (NavigationService.CanGoBack)
                            {
                                // Сначала сбрасываем контекст базы данных
                                Entities.ResetContext();
                                
                                // Сохраняем ссылку на предыдущую страницу
                                var previousPage = NavigationService.Content;
                                
                                NavigationService.GoBack();
                                
                                // Принудительно обновляем страницу со списком курсов
                                if (previousPage is TeacherCoursesPage teacherPage)
                                {
                                    teacherPage.RefreshData();
                                }
                                else
                                {
                                    // Поиск страницы TeacherCoursesPage во всем дереве элементов
                                    Frame rootFrame = Application.Current.MainWindow.Content as Frame;
                                    if (rootFrame != null)
                                    {
                                        if (rootFrame.Content is TeacherCoursesPage rootTeacherPage)
                                        {
                                            rootTeacherPage.RefreshData();
                                        }
                                        else if (rootFrame.Content is Page page && 
                                                 page.NavigationService != null && 
                                                 page.NavigationService.Content is TeacherCoursesPage nestedTeacherPage)
                                        {
                                            nestedTeacherPage.RefreshData();
                                        }
                                    }
                                }
                            }
                        }
                        else
                        {
                            MessageBox.Show("Курс не найден в базе данных.");
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при удалении курса: {ex.Message}");
            }
        }

        private void AddModuleButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                // Создаем новый модуль
                var newModule = new module
                {
                    module_name = "Новый модуль",
                    module_description = "Описание модуля",
                    course_ID = _course.course_ID
                };

                module createdModule;
                using (var context = new Entities())
                {
                    context.modules.Add(newModule);
                    context.SaveChanges();
                    
                    // Получаем ID созданного модуля
                    createdModule = new module
                    {
                        module_ID = newModule.module_ID,
                        module_name = newModule.module_name,
                        module_description = newModule.module_description,
                        course_ID = newModule.course_ID
                    };
                }

                // Обновляем список модулей
                LoadData();
                
                // Показываем сообщение об успешном создании
                MessageBox.Show("Модуль успешно создан. Теперь вы можете его отредактировать.");
                
                // Переходим к редактированию созданного модуля
                NavigationService.Navigate(new ModuleEditPage(_currentUser, createdModule));
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при добавлении модуля: {ex.Message}");
            }
        }

        private void EditModuleButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (sender is Button button && button.Tag is int moduleId)
                {
                    var moduleToEdit = _modules.FirstOrDefault(m => m.module_ID == moduleId);
                    if (moduleToEdit != null)
                    {
                        // Создаем копию модуля для редактирования
                        var moduleCopy = new module
                        {
                            module_ID = moduleToEdit.module_ID,
                            module_name = moduleToEdit.module_name,
                            module_description = moduleToEdit.module_description,
                            course_ID = moduleToEdit.course_ID
                        };

                        NavigationService.Navigate(new ModuleEditPage(_currentUser, moduleCopy));
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при редактировании модуля: {ex.Message}");
            }
        }

        private void EditExamButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                // Извлекаем ID курса в локальную переменную
                int courseId = _course.course_ID;
                
                using (var context = new Entities())
                {
                    var exam = context.exams.FirstOrDefault(ex => ex.course_ID == courseId);
                    
                    if (exam == null)
                    {
                        // Создаем новый экзамен
                        exam = new exam
                        {
                            course_ID = courseId,
                            duration = 60,          // Длительность в минутах
                            attempts = 1            // Количество попыток сдачи
                        };
                        context.exams.Add(exam);
                        context.SaveChanges();
                    }

                    // Создаем копию экзамена для редактирования
                    var examCopy = new exam
                    {
                        exam_ID = exam.exam_ID,
                        course_ID = exam.course_ID,
                        duration = exam.duration,
                        attempts = exam.attempts,
                        exam_date = exam.exam_date
                    };

                    // Переходим на страницу редактирования экзамена
                    NavigationService.Navigate(new ExamPage(_currentUser, examCopy));
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при работе с экзаменом: {ex.Message}");
            }
        }

        private void DeleteModuleButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                var button = sender as Button;
                if (button != null && button.Tag != null)
                {
                    int moduleId = (int)button.Tag;
                    
                    // Запрашиваем подтверждение удаления
                    var result = MessageBox.Show(
                        "Вы действительно хотите удалить этот модуль? Будут также удалены все связанные тесты и результаты. Это действие нельзя отменить.",
                        "Подтверждение удаления",
                        MessageBoxButton.YesNo,
                        MessageBoxImage.Warning);
                    
                    if (result == MessageBoxResult.Yes)
                    {
                        using (var context = new Entities())
                        {
                            // Находим модуль в базе данных
                            var moduleToDelete = context.modules.FirstOrDefault(m => m.module_ID == moduleId);
                            if (moduleToDelete != null)
                            {
                                // Находим связанные тесты
                                var tests = context.tests.Where(t => t.module_ID == moduleId).ToList();
                                
                                // Удаляем результаты тестов
                                foreach (var test in tests)
                                {
                                    var testResults = context.test_results.Where(tr => tr.test_ID == test.test_ID).ToList();
                                    foreach (var testResult in testResults)
                                    {
                                        context.test_results.Remove(testResult);
                                    }
                                    
                                    // Удаляем сам тест
                                    context.tests.Remove(test);
                                }
                                
                                // Удаляем модуль
                                context.modules.Remove(moduleToDelete);
                                context.SaveChanges();
                                
                                // Обновляем список
                                LoadData();
                                
                                MessageBox.Show("Модуль успешно удален");
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при удалении модуля: {ex.Message}");
            }
        }
    }
} 