using System;
using System.Windows;
using System.Windows.Controls;

namespace online_courses
{
    public partial class SupportPage : Window
    {
        private user _currentUser;

        public SupportPage(user user)
        {
            InitializeComponent();
            _currentUser = user;
            Title = $"Личный кабинет оператора технической поддержки: {_currentUser.users_login}";
            
            // По умолчанию показываем страницу с чатами поддержки
            MainFrame.Navigate(new SupportChatsPage(_currentUser));
        }

        private void MainFrame_IsVisibleChanged(object sender, DependencyPropertyChangedEventArgs e)
        {
            if (MainFrame.Content is Page currentPage && currentPage is IPageRefresh pageWithRefresh)
            {
                pageWithRefresh.RefreshData();
            }
        }

        private void ChatsButton_Click(object sender, RoutedEventArgs e)
        {
            MainFrame.Navigate(new SupportChatsPage(_currentUser));
        }

        private void IssuesButton_Click(object sender, RoutedEventArgs e)
        {
            MainFrame.Navigate(new SupportIssuesPage(_currentUser));
        }

        private void ProfileButton_Click(object sender, RoutedEventArgs e)
        {
            MainFrame.Navigate(new ProfilePage(_currentUser));
        }

        private void LogoutButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                LoginPage loginPage = new LoginPage();
                loginPage.Show();
                this.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при выходе из системы: {ex.Message}");
            }
        }
    }
} 