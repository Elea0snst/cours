using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Controls;

namespace online_courses
{
    public partial class CoursesPage : Page, IPageRefresh
    {
        private user _currentUser;
        private List<cours> _allCourses;
        
        // Класс для отображения курса с рейтингом
        private class CourseWithRating
        {
            public cours Course { get; set; }
            public double Rating { get; set; }
            public string RatingText { get; set; }
            public bool IsEnrolled { get; set; }
            public double Progress { get; set; }
            public string ProgressText { get; set; }
        }

        public CoursesPage(user user)
        {
            InitializeComponent();
            _currentUser = user;
            
            // Инициализация списка курсов пустым списком, чтобы избежать null
            _allCourses = new List<cours>();
            
            // Очищаем контекст для получения свежих данных
            Entities.ResetContext();
            
            // Сначала загружаем курсы, потом категории
            LoadCourses();
            LoadCategories();
        }

        public void RefreshData()
        {
            // Очищаем контекст для получения свежих данных
            Entities.ResetContext();
            LoadCourses();
        }
        
        private void LoadCourses()
        {
            try
            {
                // Получаем все курсы из базы данных
                using (var context = new Entities())
                {
                    _allCourses = context.courses.ToList();
                    
                    // Применяем фильтры для отображения курсов
                    ApplyFilters();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при загрузке курсов: {ex.Message}");
            }
        }

        private void LoadCategories()
        {
            try
            {
                using (var context = new Entities())
                {
                    var categories = context.categories.ToList();
                    categories.Insert(0, new category { category_ID = 0, category_name = "Все категории" });
                    categoryComboBox.ItemsSource = categories;
                    categoryComboBox.SelectedIndex = 0;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при загрузке категорий: {ex.Message}");
            }
        }

        private void ApplyFilters()
        {
            try
            {
                // Проверка на null входных данных
                if (_allCourses == null)
                {
                    _allCourses = new List<cours>();
                    MessageBox.Show("Список курсов не загружен. Попробуйте обновить страницу.");
                    return;
                }

                if (_currentUser == null)
                {
                    MessageBox.Show("Информация о пользователе не доступна. Попробуйте перезайти в систему.");
                    return;
                }

                var filteredCourses = _allCourses;

                // Фильтр по поисковому запросу
                string searchText = searchTextBox?.Text?.ToLower() ?? string.Empty;
                if (!string.IsNullOrWhiteSpace(searchText))
                {
                    filteredCourses = filteredCourses.Where(c => 
                        (c?.course_name != null && c.course_name.ToLower().Contains(searchText)) || 
                        (c?.course_description != null && c.course_description.ToLower().Contains(searchText))).ToList();
                }

                // Фильтр по категории
                if (categoryComboBox?.SelectedIndex > 0 && categoryComboBox.SelectedItem is category selectedCategory && selectedCategory != null)
                {
                    int categoryId = selectedCategory.category_ID;
                    filteredCourses = filteredCourses.Where(c => c != null && c.course_category == categoryId).ToList();
                }

                // Добавляем рейтинги к курсам
                var coursesWithRatings = new List<CourseWithRating>();
                
                // Создаем новый контекст для обеспечения свежих данных
                using (var context = new Entities())
                {
                    foreach (var course in filteredCourses?.Where(c => c != null) ?? Enumerable.Empty<cours>())
                    {
                        try
                        {
                            string ratingText = "Нет оценок";
                            double rating = 0;
                            bool isEnrolled = false;
                            double progress = 0;
                            string progressText = "Не записан";

                            // Получаем рейтинг
                            var reviews = context.course_reviews
                                ?.Where(r => r != null && r.course_ID == course.course_ID)
                                ?.ToList();

                            if (reviews != null && reviews.Any())
                            {
                                rating = reviews.Average(r => r.rating);
                                ratingText = rating.ToString("0.0");
                            }

                            // Определяем, записан ли студент на курс и получаем прогресс
                            var courseGrade = context.course_grades
                                ?.FirstOrDefault(cg => cg != null && cg.course_ID == course.course_ID && cg.users_ID == _currentUser.users_ID);

                            if (courseGrade != null)
                            {
                                isEnrolled = true;

                                // Используем CourseGradeHelper для вычисления прогресса
                                var helper = new CourseGradeHelper(context);
                                var progressInfo = helper.CalculateCourseProgress(course.course_ID, _currentUser.users_ID);
                                
                                progress = progressInfo.ProgressPercentage;
                                progressText = $"{progress:F1}% ({progressInfo.CompletedModules}/{progressInfo.TotalModules})";
                                
                                System.Diagnostics.Debug.WriteLine($"[CoursesPage] Курс {course.course_name}: " +
                                    $"Прогресс {progress:F1}%, Завершено модулей: {progressInfo.CompletedModules}/{progressInfo.TotalModules}");
                            }

                            // Создаем локальную копию курса с загруженными навигационными свойствами
                            var courseWithDetails = new cours
                            {
                                course_ID = course.course_ID,
                                course_name = course.course_name,
                                course_description = course.course_description,
                                course_author = course.course_author,
                                course_category = course.course_category
                            };
                            
                            // Загружаем автора курса
                            if (course.course_author.HasValue)
                            {
                                var author = context.users.FirstOrDefault(u => u.users_ID == course.course_author);
                                if (author != null)
                                {
                                    // Создаем копию для предотвращения проблем с контекстом
                                    courseWithDetails.user = new user
                                    {
                                        users_ID = author.users_ID,
                                        users_login = author.users_login
                                    };
                                }
                            }
                            
                            // Загружаем категорию курса
                            if (course.course_category.HasValue)
                            {
                                var cat = context.categories.FirstOrDefault(c => c.category_ID == course.course_category);
                                if (cat != null)
                                {
                                    // Создаем копию для предотвращения проблем с контекстом
                                    courseWithDetails.category = new category
                                    {
                                        category_ID = cat.category_ID,
                                        category_name = cat.category_name
                                    };
                                }
                            }

                            coursesWithRatings.Add(new CourseWithRating
                            {
                                Course = courseWithDetails,
                                Rating = rating,
                                RatingText = ratingText,
                                IsEnrolled = isEnrolled,
                                Progress = progress,
                                ProgressText = progressText
                            });
                        }
                        catch (Exception ex)
                        {
                            System.Diagnostics.Debug.WriteLine($"Ошибка при обработке курса {course?.course_ID}: {ex.Message}");
                        }
                    }
                }

                // Назначаем источник данных
                if (coursesListView != null)
                {
                    coursesListView.ItemsSource = coursesWithRatings;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при применении фильтров: {ex.Message}");
                System.Diagnostics.Debug.WriteLine($"Детали ошибки: {ex}");
            }
        }

        private void SearchTextBox_TextChanged(object sender, TextChangedEventArgs e)
        {
            ApplyFilters();
        }

        private void CategoryComboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            ApplyFilters();
        }

        private void SearchButton_Click(object sender, RoutedEventArgs e)
        {
            ApplyFilters();
        }

        private void CoursesListView_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            // Обработка выбора курса в списке
        }

        private void ViewCourseButton_Click(object sender, RoutedEventArgs e)
        {
            if (sender is Button button && button.Tag is int courseId)
            {
                try
                {
                    // Используем новый контекст для получения свежих данных
                    cours courseToNavigate = null;
                    
                    using (var context = new Entities())
                    {
                        // Загружаем курс из базы данных вместо использования кэшированного списка
                        var dbCourse = context.courses.FirstOrDefault(c => c.course_ID == courseId);
                        
                        // Если курс найден, предварительно загружаем связанные данные
                        if (dbCourse != null)
                        {
                            // Предзагружаем данные о модулях
                            var modules = context.modules
                                .Where(m => m.course_ID == dbCourse.course_ID)
                                .ToList();
                                
                            // Предзагружаем отзывы
                            var reviews = context.course_reviews
                                .Where(r => r.course_ID == dbCourse.course_ID)
                                .ToList();
                                
                            // Проверяем статус записи
                            var enrollment = context.course_grades
                                .FirstOrDefault(cg => cg.course_ID == dbCourse.course_ID && cg.users_ID == _currentUser.users_ID);
                            
                            // Создаем копию курса
                            courseToNavigate = new cours
                            {
                                course_ID = dbCourse.course_ID,
                                course_name = dbCourse.course_name,
                                course_description = dbCourse.course_description,
                                course_author = dbCourse.course_author,
                                course_category = dbCourse.course_category
                            };
                        }
                    }
                    
                    // Сбрасываем контекст перед навигацией
                    Entities.ResetContext();
                    
                    // Навигация только после закрытия контекста
                    if (courseToNavigate != null)
                    {
                        NavigationService.Navigate(new CourseDetailsPage(_currentUser, courseToNavigate));
                    }
                    else
                    {
                        MessageBox.Show("Курс не найден.");
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Ошибка при открытии курса: {ex.Message}\n\nStackTrace: {ex.StackTrace}");
                }
            }
        }
    }
} 