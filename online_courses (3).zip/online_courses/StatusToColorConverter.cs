using System;
using System.Globalization;
using System.Windows.Data;
using System.Windows.Media;

namespace online_courses
{
    /// <summary>
    /// Конвертер для преобразования статуса модуля или курса в соответствующий цвет
    /// </summary>
    public class StatusToColorConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            if (value is string status)
            {
                switch (status.ToLower())
                {
                    case "completed":
                    case "завершен":
                    case "пройден":
                    case "✓":
                        return new SolidColorBrush(Colors.Green);
                    
                    case "in progress":
                    case "в процессе":
                        return new SolidColorBrush(Colors.Orange);
                    
                    case "not started":
                    case "не начат":
                    case "ожидает":
                        return new SolidColorBrush(Colors.Gray);
                        
                    case "failed":
                    case "провален":
                        return new SolidColorBrush(Colors.Red);
                        
                    default:
                        return new SolidColorBrush(Colors.Black);
                }
            }
            
            return new SolidColorBrush(Colors.Black);
        }

        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            throw new NotImplementedException();
        }
    }
} 