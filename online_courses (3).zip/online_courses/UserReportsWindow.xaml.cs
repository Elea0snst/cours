using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;

namespace online_courses
{
    public partial class UserReportsWindow : Window
    {
        private user _currentUser;
        private List<ReportType> _reportTypes;
        private ReportType _selectedReportType;

        public class ReportType
        {
            public int ID { get; set; }
            public string Name { get; set; }
            public string Description { get; set; }
            public Func<Entities, object> ReportGenerator { get; set; }
        }

        public UserReportsWindow(user currentUser)
        {
            InitializeComponent();
            
            _currentUser = currentUser;
            
            // Инициализируем типы отчетов
            InitializeReportTypes();
            
            // Настраиваем комбобокс с типами отчетов
            reportTypeComboBox.ItemsSource = _reportTypes;
            reportTypeComboBox.SelectedIndex = 0;
        }

        private void InitializeReportTypes()
        {
            _reportTypes = new List<ReportType>
            {
                new ReportType 
                { 
                    ID = 1, 
                    Name = "Пользователи по ролям", 
                    Description = "Количество пользователей по ролям",
                    ReportGenerator = (context) => 
                        context.users
                            .GroupBy(u => u.role.role_name)
                            .Select(g => new { Роль = g.Key, Количество_пользователей = g.Count() })
                            .ToList()
                },
                new ReportType 
                { 
                    ID = 2, 
                    Name = "Активность пользователей", 
                    Description = "Статистика активности пользователей в системе",
                    ReportGenerator = (context) => 
                    {
                        // Загружаем пользователей и результаты тестов в память
                        var users = context.users.ToList();
                        var testResults = context.test_results.ToList();
                        
                        // Создаем результаты в памяти
                        return users.Select(user => {
                            // Находим результаты тестов для этого пользователя
                            var userResults = testResults.Where(r => r.users_ID == user.users_ID).ToList();
                            
                            // Создаем объект отчета
                            return new {
                                ID = user.users_ID,
                                Логин = user.users_login,
                                Роль = user.role?.role_name ?? "Не указана",
                                Количество_тестов = userResults.Count,
                                Последняя_активность = userResults.Any() ? 
                                    userResults.Max(r => r.result_date) : (DateTime?)null
                            };
                        }).ToList();
                    }
                },
                new ReportType 
                { 
                    ID = 3, 
                    Name = "Успеваемость студентов", 
                    Description = "Статистика успеваемости студентов по тестам",
                    ReportGenerator = (context) => 
                    {
                        try
                        {
                            System.Diagnostics.Debug.WriteLine("Начало формирования отчета по успеваемости студентов");
                            
                            // Загружаем нужные данные в память
                            var users = context.users.Where(u => u.users_role_ID == 5).ToList();
                            System.Diagnostics.Debug.WriteLine($"Загружено {users.Count} пользователей с ролью студента");
                            
                            var testResults = context.test_results
                                .OrderByDescending(tr => tr.result_date)
                                .ToList();
                                
                            var tests = context.tests.ToList();
                            var modules = context.modules.ToList();
                            var courses = context.courses.ToList();
                            
                            if (users.Count == 0)
                            {
                                System.Diagnostics.Debug.WriteLine("Нет пользователей с ролью студента");
                                return new List<object>(); // Пустой список, если нет студентов
                            }
                            
                            // Создаем отчет на основе реальных данных о результатах тестов
                            var result = (from tr in testResults
                                         join test in tests on tr.test_ID equals test.test_ID into testJoin
                                         from t in testJoin.DefaultIfEmpty()
                                         join module in modules on t?.module_ID equals module.module_ID into moduleJoin
                                         from m in moduleJoin.DefaultIfEmpty()
                                         join course in courses on m?.course_ID equals course.course_ID into courseJoin
                                         from c in courseJoin.DefaultIfEmpty()
                                         join user in users on tr.users_ID equals user.users_ID
                                         select new
                                         {
                                             СтудентID = user.users_ID,
                                             Студент = user.users_login,
                                             КурсID = c?.course_ID,
                                             Курс = c?.course_name ?? "Не указан",
                                             МодульID = m?.module_ID,
                                             Модуль = m?.module_name ?? "Не указан",
                                             ТестID = t?.test_ID,
                                             Тест = t?.question?.Substring(0, Math.Min(t.question.Length, 30)) + "..." ?? "Не указан",
                                             Оценка = tr.score ?? 0,
                                             Пройден = tr.is_passed ?? false ? "Да" : "Нет",
                                             Дата_прохождения = tr.result_date
                                         }).ToList();
                            
                            System.Diagnostics.Debug.WriteLine($"Сформировано {result.Count} записей успеваемости");
                            return result;
                        }
                        catch (Exception ex)
                        {
                            System.Diagnostics.Debug.WriteLine($"Ошибка в отчете успеваемости: {ex.Message}");
                            // В случае ошибки возвращаем пустой список
                            return new List<object>();
                        }
                    }
                },
                new ReportType 
                { 
                    ID = 4, 
                    Name = "Новые пользователи", 
                    Description = "Список новых пользователей за последний месяц",
                    ReportGenerator = (context) => 
                    {
                        // Получаем дату месяц назад
                        var monthAgo = DateTime.Now.AddMonths(-1);
                        
                        // Ищем пользователей, у которых есть активность за последний месяц
                        return from user in context.users
                               join profile in context.user_profiles on user.users_ID equals profile.users_ID into profiles
                               from p in profiles.DefaultIfEmpty()
                               join result in context.test_results on user.users_ID equals result.users_ID into results
                               where results.Any(r => r.result_date >= monthAgo) || user.users_ID > 100 // Для примера добавляем ID > 100
                               select new
                               {
                                   ID = user.users_ID,
                                   Логин = user.users_login,
                                   Роль = user.role.role_name,
                                   Email = p != null ? p.users_email : "Не указан",
                                   Имя = p != null ? p.users_name : "Не указано",
                                   Фамилия = p != null ? p.users_surname : "Не указано",
                                   Последняя_активность = results.Any() ? results.Max(r => r.result_date) : (DateTime?)null
                               };
                    }
                }
            };
        }

        private void ReportTypeComboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            _selectedReportType = reportTypeComboBox.SelectedItem as ReportType;
            
            // Очищаем предыдущие данные
            reportDataGrid.ItemsSource = null;
            statisticsTextBlock.Text = "";
        }

        private void GenerateButton_Click(object sender, RoutedEventArgs e)
        {
            if (_selectedReportType == null)
            {
                MessageBox.Show("Пожалуйста, выберите тип отчета.", "Информация", MessageBoxButton.OK, MessageBoxImage.Information);
                return;
            }
            
            try
            {
                Cursor = System.Windows.Input.Cursors.Wait;
                
                // Вывод отладочных данных
                System.Diagnostics.Debug.WriteLine($"Формирование отчета '{_selectedReportType.Name}' (ID: {_selectedReportType.ID})");
                
                // Сбрасываем контекст перед генерацией отчета
                Entities.ResetContext();
                
                using (var context = new Entities())
                {
                    try
                    {
                        // Генерируем отчет
                        var reportData = _selectedReportType.ReportGenerator(context);
                        
                        // Проверяем данные на null
                        if (reportData == null)
                        {
                            throw new InvalidOperationException("Результат отчета пустой");
                        }
                        
                        System.Diagnostics.Debug.WriteLine($"Отчет сформирован: {reportData.GetType().FullName}");
                        
                        // Отображаем данные
                        try
                        {
                            reportDataGrid.ItemsSource = (System.Collections.IEnumerable)reportData;
                            System.Diagnostics.Debug.WriteLine("Данные отображены в DataGrid");
                        }
                        catch (Exception castEx)
                        {
                            System.Diagnostics.Debug.WriteLine($"Ошибка приведения типов: {castEx.Message}");
                            MessageBox.Show($"Ошибка при отображении данных: {castEx.Message}", 
                                           "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                            return;
                        }
                        
                        // Получаем статистику
                        int rowCount = 0;
                        if (reportData is IEnumerable<object> collection)
                        {
                            rowCount = collection.Count();
                        }
                        
                        statisticsTextBlock.Text = $"Всего записей: {rowCount}";
                        
                        if (rowCount == 0)
                        {
                            MessageBox.Show("По вашему запросу не найдено данных.", 
                                           "Информация", MessageBoxButton.OK, MessageBoxImage.Information);
                        }
                        else
                        {
                            System.Diagnostics.Debug.WriteLine($"Отчет успешно сформирован, записей: {rowCount}");
                        }
                    }
                    catch (Exception innerEx)
                    {
                        System.Diagnostics.Debug.WriteLine($"Ошибка при формировании отчета: {innerEx.Message}\nStackTrace: {innerEx.StackTrace}");
                        
                        MessageBox.Show($"Ошибка при формировании отчета: {innerEx.Message}\n\nВозможно, для отчета '{_selectedReportType.Name}' в базе данных отсутствуют необходимые записи.", 
                                       "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                    }
                }
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine($"Ошибка при формировании отчета: {ex.Message}\nStackTrace: {ex.StackTrace}");
                
                MessageBox.Show($"Ошибка при формировании отчета: {ex.Message}", 
                               "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
            finally
            {
                Cursor = System.Windows.Input.Cursors.Arrow;
            }
        }

        private void CloseButton_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }
    }
} 