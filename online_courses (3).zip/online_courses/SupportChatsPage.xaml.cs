using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Diagnostics;

namespace online_courses
{
    public partial class SupportChatsPage : Page, IPageRefresh
    {
        private user _currentUser;
        private ObservableCollection<ChatMessage> _messages = new ObservableCollection<ChatMessage>();
        private ObservableCollection<ChatInfo> _chats = new ObservableCollection<ChatInfo>();
        private user _selectedChatUser;
        private string _searchText = "";
        private int? _lastSelectedUserId; // Добавляем для сохранения выбранного пользователя

        // Класс для представления информации о чате
        private class ChatInfo
        {
            public int UserId { get; set; }
            public string UserName { get; set; }
            public string LastMessage { get; set; }
            public DateTime LastMessageTime { get; set; }
        }

        // Класс для представления сообщения в чате
        private class ChatMessage
        {
            public string SenderName { get; set; }
            public string Message { get; set; }
            public DateTime DateTime { get; set; }
            public bool IsOwn { get; set; }
            public Brush MessageBackground => IsOwn ? Brushes.LightBlue : Brushes.LightGray;
            public HorizontalAlignment MessageAlignment => IsOwn ? HorizontalAlignment.Right : HorizontalAlignment.Left;
        }

        public SupportChatsPage(user user)
        {
            InitializeComponent();
            _currentUser = user;
            Debug.WriteLine($"SupportChatsPage initialized for user: {user.users_login} (ID: {user.users_ID}, Role: {user.users_role_ID})");
            
            messagesListView.ItemsSource = _messages;
            chatsListView.ItemsSource = _chats;

            if (_currentUser.users_role_ID != 5) // если не support
            {
                chatsListView.Visibility = Visibility.Collapsed;
                searchTextBox.Visibility = Visibility.Collapsed;
                refreshButton.Visibility = Visibility.Collapsed;
            }
            // Начальное состояние интерфейса
            chatUserInfoTextBlock.Text = "Выберите чат для начала общения";
            messageTextBox.IsEnabled = false;
            sendButton.IsEnabled = false;
        }

        private void Page_Loaded(object sender, RoutedEventArgs e)
        {
            if (_currentUser.users_role_ID == 5)
            {
                RefreshData();
            }
            else
            {
                // Для обычного пользователя сразу ищем support
                using (var context = Entities.GetContext())
                {
                    var supportUser = context.users.FirstOrDefault(u => u.users_role_ID == 5);
                    if (supportUser != null)
                    {
                        _selectedChatUser = supportUser;
                        chatUserInfoTextBlock.Text = $"Чат с поддержкой: {supportUser.users_login}";
                        messageTextBox.IsEnabled = true;
                        sendButton.IsEnabled = true;
                        LoadChatMessages(_selectedChatUser);
                    }
                    else
                    {
                        chatUserInfoTextBlock.Text = "Нет доступного оператора поддержки.";
                        messageTextBox.IsEnabled = false;
                        sendButton.IsEnabled = false;
                    }
                }
            }
        }

        public void RefreshData()
        {
            try
            {
                LoadChats();
                
                // Если был выбран чат, перезагружаем сообщения
                if (_selectedChatUser != null)
                {
                    LoadChatMessages(_selectedChatUser);
                }
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"Error in RefreshData: {ex.Message}");
                MessageBox.Show($"Ошибка при обновлении данных: {ex.Message}");
            }
        }

        private void LoadChats()
        {
            if (_currentUser.users_role_ID != 5)
            {
                // Для обычного пользователя не формируем список чатов
                return;
            }
            try
            {
                using (var context = Entities.GetContext())
                {
                    var chatUsers = context.chat_messages
                        .Where(m => m.support_ID == _currentUser.users_ID || m.users_ID == _currentUser.users_ID)
                        .GroupBy(m => m.users_ID == _currentUser.users_ID ? m.support_ID.Value : m.users_ID)
                        .Select(g => new 
                        {
                            UserId = g.Key,
                            // Находим последнее сообщение в чате
                            LastMessage = g.OrderByDescending(m => m.message_date).FirstOrDefault()
                        })
                        .ToList();

                    // Очищаем текущий список
                    _chats.Clear();

                    // Заполняем список чатов
                    foreach (var chatUser in chatUsers)
                    {
                        // Получаем данные пользователя
                        var user = context.users.FirstOrDefault(u => u.users_ID == chatUser.UserId);
                        if (user == null) continue;

                        // Применяем фильтрацию по поисковому запросу
                        if (!string.IsNullOrEmpty(_searchText) && 
                            !user.users_login.Contains(_searchText))
                        {
                            continue;
                        }

                        var lastMessage = chatUser.LastMessage;
                        bool isFromCurrentUser = lastMessage.users_ID == _currentUser.users_ID;
                        
                        _chats.Add(new ChatInfo
                        {
                            UserId = user.users_ID,
                            UserName = user.users_login, // Упрощаем отображение имени пользователя
                            LastMessage = (isFromCurrentUser ? "Вы: " : "") + lastMessage.message_text,
                            LastMessageTime = lastMessage.message_date
                        });
                    }

                    // Сортируем по времени последнего сообщения (свежие сверху)
                    var sortedChats = _chats.OrderByDescending(c => c.LastMessageTime).ToList();
                    _chats.Clear();
                    foreach (var chat in sortedChats)
                    {
                        _chats.Add(chat);
                    }

                    // Восстанавливаем выбранный чат
                    if (_lastSelectedUserId.HasValue)
                    {
                        var selectedChat = _chats.FirstOrDefault(c => c.UserId == _lastSelectedUserId.Value);
                        if (selectedChat != null)
                        {
                            chatsListView.SelectedItem = selectedChat;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"Error loading chats: {ex.Message}");
                MessageBox.Show($"Ошибка при загрузке списка чатов: {ex.Message}");
            }
        }

        private void LoadChatMessages(user chatUser)
        {
            try
            {
                using (var context = Entities.GetContext())
                {
                    // Диагностика
                    Debug.WriteLine($"[DEBUG] LoadChatMessages: _currentUser: ID={_currentUser.users_ID}, Role={_currentUser.users_role_ID}");
                    Debug.WriteLine($"[DEBUG] LoadChatMessages: _selectedChatUser: ID={chatUser.users_ID}, Role={chatUser.users_role_ID}");

                    // Очищаем предыдущие сообщения
                    _messages.Clear();

                    // Загружаем сообщения текущего чата
                    var messages = context.chat_messages
                        .Where(m => (m.users_ID == _currentUser.users_ID && m.support_ID == chatUser.users_ID) ||
                                    (m.users_ID == chatUser.users_ID && m.support_ID == _currentUser.users_ID))
                        .OrderBy(m => m.message_date)
                        .ToList();

                    foreach (var msg in messages)
                    {
                        Debug.WriteLine($"[DEBUG] Message: message_ID={msg.message_ID}, users_ID={msg.users_ID}, support_ID={msg.support_ID}, text={msg.message_text}");
                    }

                    // Добавляем сообщения в коллекцию
                    foreach (var msg in messages)
                    {
                        bool isFromCurrentUser = msg.users_ID == _currentUser.users_ID;
                        string senderName;
                        if (isFromCurrentUser)
                            senderName = "Вы";
                        else
                            senderName = _selectedChatUser.users_login;
                        Debug.WriteLine($"[DEBUG] Message: message_ID={msg.message_ID}, users_ID={msg.users_ID}, support_ID={msg.support_ID}, isFromCurrentUser={isFromCurrentUser}, senderName={senderName}, text={msg.message_text}");
                        _messages.Add(new ChatMessage
                        {
                            SenderName = senderName,
                            Message = msg.message_text,
                            DateTime = msg.message_date,
                            IsOwn = isFromCurrentUser
                        });
                    }

                    // Прокручиваем список к последнему сообщению
                    if (messagesListView.Items.Count > 0)
                    {
                        messagesListView.ScrollIntoView(messagesListView.Items[messagesListView.Items.Count - 1]);
                    }
                }
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"Error loading messages: {ex.Message}");
                MessageBox.Show($"Ошибка при загрузке сообщений: {ex.Message}");
            }
        }

        private void SendMessage()
        {
            if (_selectedChatUser == null || string.IsNullOrWhiteSpace(messageTextBox.Text))
                return;

            try
            {
                using (var context = Entities.GetContext())
                {
                    // Создаем новое сообщение
                    var message = new chat_messages
                    {
                        users_ID = _currentUser.users_ID,
                        support_ID = _selectedChatUser.users_ID,
                        message_text = messageTextBox.Text.Trim(),
                        message_date = DateTime.Now,
                        is_read = false
                    };

                    // Сохраняем в базу данных
                    context.chat_messages.Add(message);
                    context.SaveChanges();

                    // Очищаем поле ввода
                    messageTextBox.Text = "";

                    // Обновляем только сообщения текущего чата
                    LoadChatMessages(_selectedChatUser);
                    
                    // Обновляем список чатов, сохраняя выбранный чат
                    LoadChats();
                }
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"Error sending message: {ex.Message}");
                MessageBox.Show($"Ошибка при отправке сообщения: {ex.Message}");
            }
        }

        private void ChatsListView_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (_currentUser.users_role_ID != 5)
            {
                // Для обычного пользователя не должно быть выбора чата
                return;
            }
            var selectedChatInfo = chatsListView.SelectedItem as ChatInfo;
            if (selectedChatInfo == null)
            {
                // Если ничего не выбрано, деактивируем поле ввода
                _selectedChatUser = null;
                chatUserInfoTextBlock.Text = "Выберите чат для начала общения";
                messageTextBox.IsEnabled = false;
                sendButton.IsEnabled = false;
                _messages.Clear();
                return;
            }

            using (var context = Entities.GetContext())
            {
                // Находим пользователя по ID
                _selectedChatUser = context.users.FirstOrDefault(u => u.users_ID == selectedChatInfo.UserId);
                if (_selectedChatUser == null)
                    return;

                _lastSelectedUserId = _selectedChatUser.users_ID;

                // Обновляем интерфейс
                chatUserInfoTextBlock.Text = $"Чат с пользователем: {_selectedChatUser.users_login}";
                messageTextBox.IsEnabled = true;
                sendButton.IsEnabled = true;
                messageTextBox.Focus();

                // Загружаем сообщения
                LoadChatMessages(_selectedChatUser);
            }
        }

        private void SearchTextBox_TextChanged(object sender, TextChangedEventArgs e)
        {
            _searchText = searchTextBox.Text.Trim();
            LoadChats(); // Перезагружаем список чатов с учетом фильтра
        }

        private void MessageTextBox_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Enter && !Keyboard.Modifiers.HasFlag(ModifierKeys.Shift))
            {
                SendMessage();
                e.Handled = true; // Предотвращаем добавление новой строки
            }
        }

        private void SendButton_Click(object sender, RoutedEventArgs e)
        {
            SendMessage();
        }

        private void RefreshButton_Click(object sender, RoutedEventArgs e)
        {
            RefreshData();
        }
    }
} 
