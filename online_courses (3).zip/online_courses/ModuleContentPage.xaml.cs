using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;

namespace online_courses
{
    public partial class ModuleContentPage : Page
    {
        private user _currentUser;
        private cours _course;
        private module _currentModule;
        private module _prevModule;
        private module _nextModule;
        private List<test> _moduleTests = new List<test>();
        private bool _hasCompletedModule = false;

        public ModuleContentPage(user user, cours course, module currentModule)
        {
            InitializeComponent();
            
            // Создаем защищенные копии объектов
            _currentUser = new user
            {
                users_ID = user.users_ID,
                users_login = user.users_login,
                users_password = user.users_password,
                users_role_ID = user.users_role_ID
            };
            
            _course = new cours
            {
                course_ID = course.course_ID,
                course_name = course.course_name,
                course_description = course.course_description,
                course_author = course.course_author,
                course_category = course.course_category
            };
            
            _currentModule = new module
            {
                module_ID = currentModule.module_ID,
                module_name = currentModule.module_name,
                module_description = currentModule.module_description,
                course_ID = currentModule.course_ID
            };
            
            // Сбрасываем контекст
            Entities.ResetContext();
            
            // Загружаем данные в определенном порядке
            LoadModuleData();
            LoadAdjacentModules();
            LoadModuleTests();
            UpdateModuleProgress();
            UpdateNavigationButtons();
        }

        private void LoadModuleData()
        {
            try
            {
                courseNameTextBlock.Text = _course.course_name;
                moduleNameTextBlock.Text = _currentModule.module_name;
                moduleContentTextBlock.Text = _currentModule.module_description;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при загрузке данных модуля: {ex.Message}\n\nStackTrace: {ex.StackTrace}");
            }
        }

        private void LoadAdjacentModules()
        {
            try
            {
                // Очищаем предыдущие значения
                _prevModule = null;
                _nextModule = null;
                
                int courseId = _course.course_ID;
                int currentModuleId = _currentModule.module_ID;
                
                using (var context = new Entities())
                {
                    // Получаем все модули курса сразу, отсортированные по ID
                    var allModules = context.modules
                        .Where(m => m.course_ID == courseId)
                        .OrderBy(m => m.module_ID)
                        .ToList();

                    // Если нашли модули, ищем индекс текущего
                    if (allModules.Any())
                    {
                        int currentIndex = allModules.FindIndex(m => m.module_ID == currentModuleId);
                        
                        if (currentIndex >= 0)
                        {
                            // Определяем предыдущий и следующий модули
                            if (currentIndex > 0)
                            {
                                var prevDbModule = allModules[currentIndex - 1];
                                // Создаем копию предыдущего модуля
                                _prevModule = new module
                                {
                                    module_ID = prevDbModule.module_ID,
                                    module_name = prevDbModule.module_name,
                                    module_description = prevDbModule.module_description,
                                    course_ID = prevDbModule.course_ID
                                };
                            }
                            
                            if (currentIndex < allModules.Count - 1)
                            {
                                var nextDbModule = allModules[currentIndex + 1];
                                // Создаем копию следующего модуля
                                _nextModule = new module
                                {
                                    module_ID = nextDbModule.module_ID,
                                    module_name = nextDbModule.module_name,
                                    module_description = nextDbModule.module_description,
                                    course_ID = nextDbModule.course_ID
                                };
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при определении соседних модулей: {ex.Message}\n\nStackTrace: {ex.StackTrace}");
            }
        }

        private void LoadModuleTests()
        {
            try
            {
                // Очищаем предыдущие значения
                _moduleTests.Clear();
                testsListView.Items.Clear();
                
                int moduleId = _currentModule.module_ID;
                
                using (var context = new Entities())
                {
                    // Загружаем все тесты для текущего модуля
                    var dbTests = context.tests
                        .Where(t => t.module_ID == moduleId)
                        .ToList();
                    
                    if (dbTests != null && dbTests.Count > 0)
                    {
                        foreach (var dbTest in dbTests)
                        {
                            // Создаем копию теста
                            var testCopy = new test
                            {
                                test_ID = dbTest.test_ID,
                                module_ID = dbTest.module_ID,
                                question = dbTest.question,
                                answer_options = dbTest.answer_options,
                                correct_answer = dbTest.correct_answer
                            };
                            
                            // Добавляем в список тестов модуля
                            _moduleTests.Add(testCopy);
                            
                            // Получаем последний результат теста
                            var latestResult = context.test_results
                                .Where(tr => tr.users_ID == _currentUser.users_ID && tr.test_ID == dbTest.test_ID)
                                .OrderByDescending(tr => tr.result_date)
                                .FirstOrDefault();
                            
                            bool isPassed = false;
                            decimal? score = null;
                            DateTime? completionDate = null;
                            
                            if (latestResult != null)
                            {
                                // Проверяем, пройден ли тест
                                if (latestResult.is_passed.HasValue)
                                {
                                    isPassed = latestResult.is_passed.Value;
                                }
                                else if (latestResult.score.HasValue && latestResult.score.Value >= 70)
                                {
                                    isPassed = true;
                                }
                                
                                // Сохраняем дополнительную информацию
                                score = latestResult.score;
                                completionDate = latestResult.result_date;
                            }
                            
                            // Создаем элемент для списка тестов
                            AddTestToListView(testCopy, isPassed, score, completionDate);
                        }
                    }
                }
                
                // Показываем или скрываем панель списка тестов
                testsPanel.Visibility = _moduleTests.Count > 0 ? Visibility.Visible : Visibility.Collapsed;
                
                // Если все тесты пройдены - модуль считается завершенным
                if (_moduleTests.Count > 0)
                {
                    int completedTests = testsListView.Items.Cast<ListViewItem>()
                        .Count(item => item.Tag != null && (bool)item.Tag);
                    
                    // Обновляем текст прогресса тестов
                    testsProgressText.Text = $"{completedTests}/{_moduleTests.Count} пройдено";
                    
                    if (completedTests == _moduleTests.Count)
                    {
                        _hasCompletedModule = true;
                    }
                }
                else
                {
                    // Если тестов нет, модуль автоматически считается пройденным
                    _hasCompletedModule = true;
                    testsProgressText.Text = "Нет тестов";
                }
                
                // Обновляем прогресс модуля
                UpdateModuleProgress();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при загрузке тестов модуля: {ex.Message}\n\nStackTrace: {ex.StackTrace}");
            }
        }
        
        private void AddTestToListView(test testItem, bool isPassed, decimal? score = null, DateTime? completionDate = null)
        {
            // Создаем элемент списка
            var item = new ListViewItem();
            item.Tag = isPassed; // Сохраняем информацию о прохождении в теге
            
            // Создаем панель с содержимым
            var panel = new Grid();
            panel.Margin = new Thickness(5);
            
            // Определяем строки и столбцы
            panel.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
            panel.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
            
            panel.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
            panel.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
            
            // Текст вопроса
            var questionText = new TextBlock
            {
                Text = testItem.question,
                TextWrapping = TextWrapping.Wrap,
                VerticalAlignment = VerticalAlignment.Center,
                FontWeight = FontWeights.SemiBold,
                FontSize = 14
            };
            Grid.SetColumn(questionText, 0);
            Grid.SetRow(questionText, 0);
            
            // Информация о прохождении теста
            var infoPanel = new StackPanel
            {
                Orientation = Orientation.Horizontal,
                Margin = new Thickness(0, 5, 0, 0)
            };
            Grid.SetColumn(infoPanel, 0);
            Grid.SetRow(infoPanel, 1);
            
            if (score.HasValue || completionDate.HasValue)
            {
                // Добавляем информацию о баллах
                if (score.HasValue)
                {
                    var scoreText = new TextBlock
                    {
                        Text = $"Результат: {score.Value:F1}%",
                        Foreground = score.Value >= 70 ? Brushes.Green : Brushes.Red,
                        FontWeight = FontWeights.SemiBold,
                        Margin = new Thickness(0, 0, 15, 0)
                    };
                    infoPanel.Children.Add(scoreText);
                }
                
                // Добавляем информацию о дате прохождения
                if (completionDate.HasValue)
                {
                    var dateText = new TextBlock
                    {
                        Text = $"Дата: {completionDate.Value.ToString("dd.MM.yyyy HH:mm")}",
                        Foreground = Brushes.Gray,
                        FontStyle = FontStyles.Italic
                    };
                    infoPanel.Children.Add(dateText);
                }
            }
            else
            {
                var notCompletedText = new TextBlock
                {
                    Text = "Тест еще не пройден",
                    Foreground = Brushes.Gray,
                    FontStyle = FontStyles.Italic
                };
                infoPanel.Children.Add(notCompletedText);
            }
            
            // Кнопка прохождения теста
            var testButton = new Button
            {
                Width = 150,
                Height = 30,
                Margin = new Thickness(10, 0, 0, 0),
                Tag = testItem.test_ID,
                BorderThickness = new Thickness(0)
            };
            
            if (isPassed)
            {
                testButton.Content = "Пройден ✓";
                testButton.Background = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#27ae60"));
                testButton.Foreground = Brushes.White;
            }
            else
            {
                testButton.Content = "Пройти тест";
                testButton.Background = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#e74c3c"));
                testButton.Foreground = Brushes.White;
            }
            
            testButton.Click += TestListItem_Click;
            Grid.SetColumn(testButton, 1);
            Grid.SetRow(testButton, 0);
            Grid.SetRowSpan(testButton, 2);
            
            // Добавляем элементы в панель
            panel.Children.Add(questionText);
            panel.Children.Add(infoPanel);
            panel.Children.Add(testButton);
            
            // Устанавливаем панель как содержимое элемента списка
            item.Content = panel;
            
            // Добавляем элемент в список
            testsListView.Items.Add(item);
        }
        
        private void UpdateModuleProgress()
        {
            try
            {
                int progressValue = 0;
                
                // Если тестов нет, автоматически считаем модуль завершенным на 100%
                if (_moduleTests.Count == 0)
                {
                    progressValue = 100;
                    _hasCompletedModule = true;
                }
                // Если есть тесты
                else
                {
                    // Вычисляем процент пройденных тестов
                    int totalTests = _moduleTests.Count;
                    int completedTests = testsListView.Items.Cast<ListViewItem>()
                        .Count(item => item.Tag != null && (bool)item.Tag);
                    
                    // Обновляем текст прогресса тестов
                    testsProgressText.Text = $"{completedTests}/{totalTests} пройдено";
                    
                    if (totalTests > 0)
                    {
                        // Модуль считается полностью пройденным только если пройдены все тесты
                        _hasCompletedModule = (completedTests == totalTests);
                        
                        // Расчет прогресса: 50% за просмотр содержимого + до 50% за тесты
                        double testsPortion = (double)completedTests / totalTests * 50;
                        progressValue = 50 + (int)testsPortion;
                    }
                    else
                    {
                        progressValue = 50;
                        _hasCompletedModule = false;
                    }
                }
                
                // Устанавливаем значение прогресса
                moduleProgressBar.Value = progressValue;
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine($"Ошибка при обновлении прогресса: {ex.Message}");
            }
        }

        private void UpdateNavigationButtons()
        {
            prevModuleButton.IsEnabled = _prevModule != null;
            nextModuleButton.IsEnabled = _nextModule != null;
        }

        private void BackButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                // Сбрасываем контекст перед навигацией
                Entities.ResetContext();
                
                // Создаем новую страницу курса, передавая копии объектов
                var courseContentPage = new CourseContentPage(_currentUser, _course);
                NavigationService.Navigate(courseContentPage);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при возврате к содержанию курса: {ex.Message}\n\nStackTrace: {ex.StackTrace}");
            }
        }

        private void PrevModuleButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (_prevModule != null)
                {
                    // Сбрасываем контекст перед навигацией
                    Entities.ResetContext();
                    
                    // Создаем новую страницу модуля
                    var modulePage = new ModuleContentPage(_currentUser, _course, _prevModule);
                    NavigationService.Navigate(modulePage);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при переходе к предыдущему модулю: {ex.Message}\n\nStackTrace: {ex.StackTrace}");
            }
        }

        private void NextModuleButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (_nextModule != null)
                {
                    // Сбрасываем контекст перед навигацией
                    Entities.ResetContext();
                    
                    // Создаем новую страницу модуля
                    var modulePage = new ModuleContentPage(_currentUser, _course, _nextModule);
                    NavigationService.Navigate(modulePage);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при переходе к следующему модулю: {ex.Message}\n\nStackTrace: {ex.StackTrace}");
            }
        }

        private void TestListItem_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (sender is Button button && button.Tag is int testId)
                {
                    // Находим тест в списке
                    var selectedTest = _moduleTests.FirstOrDefault(t => t.test_ID == testId);
                    
                    if (selectedTest != null)
                    {
                        // Сбрасываем контекст перед навигацией
                        Entities.ResetContext();
                        
                        // Создаем новый экземпляр страницы теста
                        var testPage = new TestPage(_currentUser, _course, _currentModule, selectedTest);
                        NavigationService.Navigate(testPage);
                    }
                    else
                    {
                        MessageBox.Show("Тест не найден.");
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при открытии теста: {ex.Message}\n\nStackTrace: {ex.StackTrace}");
            }
        }
    }
} 