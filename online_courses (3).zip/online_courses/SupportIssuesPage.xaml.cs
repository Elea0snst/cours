using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Windows;
using System.Windows.Controls;

namespace online_courses
{
    public partial class SupportIssuesPage : Page, IPageRefresh
    {
        private user _currentUser;
        private ObservableCollection<TechnicalIssue> _issues = new ObservableCollection<TechnicalIssue>();
        private TechnicalIssue _selectedIssue;

        // Класс для представления технических проблем
        private class TechnicalIssue
        {
            public int IssueId { get; set; }
            public int UserId { get; set; }
            public string Username { get; set; }
            public DateTime Date { get; set; }
            public string Status { get; set; }
            public string Type { get; set; }
            public string Subject { get; set; }
            public string Description { get; set; }
            public List<IssueMessage> Messages { get; set; } = new List<IssueMessage>();
        }

        // Класс для представления сообщений проблемы
        private class IssueMessage
        {
            public int MessageId { get; set; }
            public int SenderId { get; set; }
            public string SenderName { get; set; }
            public DateTime Date { get; set; }
            public string Text { get; set; }
        }

        public SupportIssuesPage(user user)
        {
            InitializeComponent();
            _currentUser = user;
            
            // Устанавливаем источник данных
            issuesDataGrid.ItemsSource = _issues;
            
            // Устанавливаем начальное состояние фильтра
            statusFilterComboBox.SelectedIndex = 0;
            
            // Начальное состояние кнопок
            UpdateButtonsState();
        }

        private void Page_Loaded(object sender, RoutedEventArgs e)
        {
            RefreshData();
        }

        public void RefreshData()
        {
            try
            {
                // Загружаем технические проблемы
                LoadIssues();
                
                // Обновляем состояние кнопок
                UpdateButtonsState();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при загрузке данных: {ex.Message}");
            }
        }

        private void LoadIssues()
        {
            try
            {
                // В реальном приложении здесь будет загрузка из базы данных
                // Для примера создадим тестовые данные
                _issues.Clear();

                // Имитация загрузки данных (в реальном приложении будет загрузка из базы)
                var testIssues = new List<TechnicalIssue>
                {
                    new TechnicalIssue 
                    { 
                        IssueId = 1, 
                        UserId = 10, 
                        Username = "student1", 
                        Date = DateTime.Now.AddDays(-3), 
                        Status = "new", 
                        Type = "Ошибка в системе", 
                        Subject = "Не открывается тест",
                        Description = "При попытке открыть тест по модулю 3 курса 'Программирование на C#' появляется ошибка."
                    },
                    new TechnicalIssue 
                    { 
                        IssueId = 2, 
                        UserId = 15, 
                        Username = "teacher2", 
                        Date = DateTime.Now.AddDays(-1), 
                        Status = "in_progress", 
                        Type = "Проблема с интерфейсом", 
                        Subject = "Не отображаются оценки студентов",
                        Description = "В отчете по курсу не отображаются оценки студентов за последний месяц."
                    },
                    new TechnicalIssue 
                    { 
                        IssueId = 3, 
                        UserId = 8, 
                        Username = "student3", 
                        Date = DateTime.Now.AddDays(-5), 
                        Status = "resolved", 
                        Type = "Доступ к курсу", 
                        Subject = "Нет доступа к купленному курсу",
                        Description = "Я оплатил курс 'Web-разработка', но он не отображается в моем списке курсов."
                    }
                };

                // Применяем фильтр по статусу
                string statusFilter = GetSelectedStatusFilter();
                if (statusFilter != "all")
                {
                    testIssues = testIssues.Where(i => i.Status == statusFilter).ToList();
                }

                // Добавляем отфильтрованные проблемы в коллекцию
                foreach (var issue in testIssues)
                {
                    _issues.Add(issue);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при загрузке технических проблем: {ex.Message}");
            }
        }

        private string GetSelectedStatusFilter()
        {
            switch (statusFilterComboBox.SelectedIndex)
            {
                case 1: return "new";
                case 2: return "in_progress";
                case 3: return "resolved";
                case 4: return "closed";
                default: return "all";
            }
        }

        private void UpdateButtonsState()
        {
            bool isIssueSelected = _selectedIssue != null;
            
            viewButton.IsEnabled = isIssueSelected;
            replyButton.IsEnabled = isIssueSelected && _selectedIssue.Status != "closed";
            
            inProgressButton.IsEnabled = isIssueSelected && _selectedIssue.Status == "new";
            resolvedButton.IsEnabled = isIssueSelected && _selectedIssue.Status == "in_progress";
            closedButton.IsEnabled = isIssueSelected && (_selectedIssue.Status == "resolved" || _selectedIssue.Status == "in_progress");
        }

        private void IssuesDataGrid_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            _selectedIssue = issuesDataGrid.SelectedItem as TechnicalIssue;
            UpdateButtonsState();
        }

        private void StatusFilterComboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            RefreshData();
        }

        private void ViewButton_Click(object sender, RoutedEventArgs e)
        {
            if (_selectedIssue == null)
                return;

            // Отображаем детали проблемы
            MessageBox.Show($"Проблема №{_selectedIssue.IssueId}\n\n" +
                           $"Пользователь: {_selectedIssue.Username}\n" +
                           $"Дата: {_selectedIssue.Date:dd.MM.yyyy HH:mm}\n" +
                           $"Статус: {TranslateStatus(_selectedIssue.Status)}\n" +
                           $"Тип: {_selectedIssue.Type}\n" +
                           $"Тема: {_selectedIssue.Subject}\n\n" +
                           $"Описание:\n{_selectedIssue.Description}",
                           "Детали обращения", MessageBoxButton.OK, MessageBoxImage.Information);
        }

        private string TranslateStatus(string status)
        {
            switch (status)
            {
                case "new": return "Новое";
                case "in_progress": return "В работе";
                case "resolved": return "Решено";
                case "closed": return "Закрыто";
                default: return status;
            }
        }

        private void ReplyButton_Click(object sender, RoutedEventArgs e)
        {
            if (_selectedIssue == null)
                return;

            // Вместо Microsoft.VisualBasic.Interaction.InputBox используем стандартный диалог
            // Создаем простое окно ввода с TextBox
            var inputDialog = new Window
            {
                Title = "Отправка ответа",
                Width = 400,
                Height = 200,
                WindowStartupLocation = WindowStartupLocation.CenterScreen,
                ResizeMode = ResizeMode.NoResize
            };

            var grid = new Grid();
            inputDialog.Content = grid;
            
            // Добавляем строки для элементов
            grid.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
            grid.RowDefinitions.Add(new RowDefinition { Height = new GridLength(1, GridUnitType.Star) });
            grid.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
            
            // Заголовок
            var label = new TextBlock
            {
                Text = $"Ответ на обращение №{_selectedIssue.IssueId} от пользователя {_selectedIssue.Username}:",
                Margin = new Thickness(10)
            };
            Grid.SetRow(label, 0);
            grid.Children.Add(label);
            
            // Текстовое поле для ввода
            var textBox = new TextBox
            {
                Margin = new Thickness(10),
                AcceptsReturn = true,
                TextWrapping = TextWrapping.Wrap,
                VerticalAlignment = VerticalAlignment.Stretch,
                HorizontalAlignment = HorizontalAlignment.Stretch
            };
            Grid.SetRow(textBox, 1);
            grid.Children.Add(textBox);
            
            // Панель кнопок
            var buttonPanel = new StackPanel
            {
                Orientation = Orientation.Horizontal,
                HorizontalAlignment = HorizontalAlignment.Right,
                Margin = new Thickness(10)
            };
            Grid.SetRow(buttonPanel, 2);
            grid.Children.Add(buttonPanel);
            
            // Кнопка OK
            var okButton = new Button
            {
                Content = "Отправить",
                Width = 80,
                Height = 30,
                Margin = new Thickness(5)
            };
            okButton.Click += (s, args) => 
            { 
                inputDialog.DialogResult = true;
                inputDialog.Close();
            };
            buttonPanel.Children.Add(okButton);
            
            // Кнопка Отмена
            var cancelButton = new Button
            {
                Content = "Отмена",
                Width = 80,
                Height = 30,
                Margin = new Thickness(5)
            };
            cancelButton.Click += (s, args) => inputDialog.Close();
            buttonPanel.Children.Add(cancelButton);
            
            // Показываем диалог и проверяем результат
            bool? dialogResult = inputDialog.ShowDialog();
            string responseText = "";
            
            if (dialogResult == true)
            {
                responseText = textBox.Text;
                
                if (!string.IsNullOrWhiteSpace(responseText))
                {
                    // В реальном приложении здесь будет сохранение ответа в базу данных
                    // и отправка уведомления пользователю
                    MessageBox.Show("Ответ успешно отправлен пользователю.", 
                        "Отправка ответа", MessageBoxButton.OK, MessageBoxImage.Information);
                }
            }
        }

        private void UpdateIssueStatus(string newStatus)
        {
            if (_selectedIssue == null)
                return;

            try
            {
                // Обновляем статус проблемы
                _selectedIssue.Status = newStatus;
                
                // В реальном приложении здесь будет обновление статуса в базе данных
                
                MessageBox.Show($"Статус обращения №{_selectedIssue.IssueId} успешно изменен на '{TranslateStatus(newStatus)}'.", 
                    "Обновление статуса", MessageBoxButton.OK, MessageBoxImage.Information);
                
                // Обновляем данные в интерфейсе
                RefreshData();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при обновлении статуса: {ex.Message}");
            }
        }

        private void InProgressButton_Click(object sender, RoutedEventArgs e)
        {
            UpdateIssueStatus("in_progress");
        }

        private void ResolvedButton_Click(object sender, RoutedEventArgs e)
        {
            UpdateIssueStatus("resolved");
        }

        private void ClosedButton_Click(object sender, RoutedEventArgs e)
        {
            UpdateIssueStatus("closed");
        }

        private void RefreshButton_Click(object sender, RoutedEventArgs e)
        {
            RefreshData();
        }
    }
} 