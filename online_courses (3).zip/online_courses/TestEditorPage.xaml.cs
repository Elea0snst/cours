using System;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using Microsoft.Win32;
using System.Windows.Media.Imaging;
using System.IO;

namespace online_courses
{
    public partial class TestEditorPage : Page
    {
        private readonly user _currentUser;
        private readonly module _module;
        private readonly test _test;

        public TestEditorPage(user currentUser, test testData, module module = null)
        {
            InitializeComponent();
            _currentUser = currentUser ?? throw new ArgumentNullException(nameof(currentUser));
            _test = testData ?? throw new ArgumentNullException(nameof(testData));
            _module = module; // Может быть null при редактировании отдельного теста

            LoadTestData();
        }

        private void LoadTestData()
        {
            try
            {
                // Загружаем текст вопроса
                questionTextBox.Text = _test.question ?? "";

                // Загружаем варианты ответов
                if (!string.IsNullOrEmpty(_test.answer_options))
                {
                    // Варианты разделены точкой с запятой
                    answerOptionsTextBox.Text = _test.answer_options.Replace(";", Environment.NewLine);
                }

                // Загружаем правильный ответ
                correctAnswerTextBox.Text = _test.correct_answer ?? "";
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при загрузке данных теста: {ex.Message}");
            }
        }

        private void SaveButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(questionTextBox.Text))
                {
                    MessageBox.Show("Введите текст вопроса");
                    return;
                }

                if (string.IsNullOrWhiteSpace(answerOptionsTextBox.Text))
                {
                    MessageBox.Show("Введите варианты ответов");
                    return;
                }

                if (string.IsNullOrWhiteSpace(correctAnswerTextBox.Text))
                {
                    MessageBox.Show("Введите правильный ответ");
                    return;
                }

                // Проверяем, что правильный ответ есть среди вариантов
                var answerOptions = answerOptionsTextBox.Text
                    .Split(new[] { Environment.NewLine }, StringSplitOptions.RemoveEmptyEntries)
                    .Select(option => option.Trim())
                    .Where(option => !string.IsNullOrWhiteSpace(option))
                    .ToList();

                if (answerOptions.Count < 2)
                {
                    MessageBox.Show("Введите минимум два варианта ответа");
                    return;
                }

                var correctAnswer = correctAnswerTextBox.Text.Trim();
                
                // Проверяем соответствие правильного ответа вариантам
                if (!string.IsNullOrEmpty(correctAnswer) && !answerOptions.Contains(correctAnswer))
                {
                    // Если правильного ответа нет среди вариантов, используем индекс
                    if (int.TryParse(correctAnswer, out int answerIndex) && 
                        answerIndex > 0 && answerIndex <= answerOptions.Count)
                    {
                        // Используем индекс как есть
                    }
                    else
                    {
                        MessageBox.Show("Правильный ответ должен совпадать с одним из вариантов или быть индексом варианта (1, 2, 3...)");
                        return;
                    }
                }

                // Форматируем варианты ответов в строку с разделителями
                var optionsString = string.Join(";", answerOptions);

                using (var context = new Entities())
                {
                    // Проверяем, новый это вопрос или существующий
                    if (_test.test_ID < 0) // Если ID отрицательный, значит это новый вопрос
                    {
                        // Создаем новый вопрос
                        var newQuestion = new test
                        {
                            module_ID = _test.module_ID,
                            question = questionTextBox.Text.Trim(),
                            answer_options = optionsString,
                            correct_answer = correctAnswer
                        };
                        
                        context.tests.Add(newQuestion);
                        context.SaveChanges();
                        
                        // Обновляем ID теста
                        _test.test_ID = newQuestion.test_ID;
                        
                        MessageBox.Show("Новый вопрос успешно добавлен");
                    }
                    else
                    {
                        // Получаем тест из базы данных
                        var testToUpdate = context.tests.FirstOrDefault(t => t.test_ID == _test.test_ID);
                        if (testToUpdate != null)
                        {
                            // Обновляем данные теста
                            testToUpdate.question = questionTextBox.Text.Trim();
                            testToUpdate.answer_options = optionsString;
                            testToUpdate.correct_answer = correctAnswer;

                            try
                            {
                                // Сохраняем изменения
                                context.SaveChanges();
                                MessageBox.Show("Вопрос успешно обновлен");
                            }
                            catch (System.Data.Entity.Validation.DbEntityValidationException ex)
                            {
                                var errorMessage = new StringBuilder("Ошибка валидации при сохранении вопроса:");
                                
                                foreach (var validationErrors in ex.EntityValidationErrors)
                                {
                                    foreach (var validationError in validationErrors.ValidationErrors)
                                    {
                                        errorMessage.AppendLine($" - {validationError.PropertyName}: {validationError.ErrorMessage}");
                                    }
                                }
                                
                                MessageBox.Show(errorMessage.ToString());
                                return;
                            }
                        }
                    }
                    
                    // Возвращаемся на предыдущую страницу
                    if (NavigationService != null && NavigationService.CanGoBack)
                    {
                        Entities.ResetContext();
                        NavigationService.GoBack();
                        
                        // Обновляем страницу модуля, если это возможно
                        if (NavigationService.Content is ModuleEditPage moduleEditPage)
                        {
                            moduleEditPage.LoadData();
                        }
                    }
                    else
                    {
                        // Если мы находимся в окне, а не странице навигации,
                        // закрываем окно
                        Window.GetWindow(this)?.Close();
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при сохранении вопроса: {ex.Message}\nStackTrace: {ex.StackTrace}");
            }
        }

        private void CancelButton_Click(object sender, RoutedEventArgs e)
        {
            if (NavigationService.CanGoBack)
            {
                NavigationService.GoBack();
            }
        }

        private void DeleteButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                // Запрашиваем подтверждение удаления
                var confirmResult = MessageBox.Show(
                    "Вы действительно хотите удалить этот вопрос? Это действие нельзя отменить.",
                    "Подтверждение удаления",
                    MessageBoxButton.YesNo,
                    MessageBoxImage.Warning);

                if (confirmResult == MessageBoxResult.Yes)
                {
                    using (var context = new Entities())
                    {
                        // Находим тест в базе данных
                        var testToDelete = context.tests.FirstOrDefault(t => t.test_ID == _test.test_ID);
                        if (testToDelete != null)
                        {
                            // Удаляем результаты теста
                            var testResults = context.test_results.Where(tr => tr.test_ID == _test.test_ID).ToList();
                            foreach (var testResult in testResults)
                            {
                                context.test_results.Remove(testResult);
                            }

                            // Удаляем сам тест
                            context.tests.Remove(testToDelete);
                            context.SaveChanges();

                            MessageBox.Show("Вопрос успешно удален");

                            // Возвращаемся на предыдущую страницу и обеспечиваем обновление
                            if (NavigationService.CanGoBack)
                            {
                                // Сначала сбрасываем контекст базы данных
                                Entities.ResetContext();
                                
                                NavigationService.GoBack();
                                
                                // Обновляем страницу модуля, если это возможно
                                if (NavigationService.Content is ModuleEditPage moduleEditPage)
                                {
                                    moduleEditPage.LoadData();
                                }
                            }
                        }
                        else
                        {
                            MessageBox.Show("Тест не найден в базе данных.");
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при удалении теста: {ex.Message}");
            }
        }

        private void AddImageButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                // Создаем диалог выбора файла
                var openFileDialog = new OpenFileDialog
                {
                    Filter = "Изображения|*.jpg;*.jpeg;*.png;*.gif|Все файлы|*.*",
                    Title = "Выберите изображение"
                };

                // Показываем диалог
                if (openFileDialog.ShowDialog() == true)
                {
                    // Загружаем изображение
                    var bitmap = new BitmapImage(new Uri(openFileDialog.FileName));
                    questionImage.Source = bitmap;
                    
                    // Показываем изображение и кнопку удаления
                    questionImage.Visibility = Visibility.Visible;
                    removeImageButton.Visibility = Visibility.Visible;
                    
                    // Здесь можно добавить код для сохранения изображения в базу данных
                    // Например, конвертировать в массив байтов и сохранить в свойстве _test.image_data
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при загрузке изображения: {ex.Message}");
            }
        }

        private void RemoveImageButton_Click(object sender, RoutedEventArgs e)
        {
            // Удаляем источник изображения
            questionImage.Source = null;
            
            // Скрываем изображение и кнопку удаления
            questionImage.Visibility = Visibility.Collapsed;
            removeImageButton.Visibility = Visibility.Collapsed;
            
            // Здесь можно добавить код для удаления изображения из базы данных
            // Например, установить _test.image_data = null
        }
    }
} 
