# PowerShell скрипт для добавления файлов в проект Visual Studio

# Пути к файлам
$UserEditWindowXaml = "UserEditWindow.xaml"
$UserEditWindowCs = "UserEditWindow.xaml.cs"
$UserReportsWindowXaml = "UserReportsWindow.xaml"
$UserReportsWindowCs = "UserReportsWindow.xaml.cs"

# Проверяем существование файлов
$allFilesExist = $true
foreach ($file in @($UserEditWindowXaml, $UserEditWindowCs, $UserReportsWindowXaml, $UserReportsWindowCs)) {
    if (-not (Test-Path $file)) {
        Write-Error "Файл $file не найден!"
        $allFilesExist = $false
    }
}

if (-not $allFilesExist) {
    exit 1
}

# Загружаем проектный файл
$projectFile = "online_courses.csproj"
[xml]$project = Get-Content $projectFile

# Добавляем файлы XAML как Page
$pageItemGroup = $project.Project.ItemGroup | Where-Object { $_.Page -ne $null } | Select-Object -First 1

# Добавляем UserEditWindow.xaml
$userEditWindowXamlElement = $project.CreateElement("Page", $project.Project.xmlns)
$userEditWindowXamlElement.SetAttribute("Include", $UserEditWindowXaml)
$subTypeElement = $project.CreateElement("SubType", $project.Project.xmlns)
$subTypeElement.InnerText = "Designer"
$generatorElement = $project.CreateElement("Generator", $project.Project.xmlns)
$generatorElement.InnerText = "MSBuild:Compile"
$userEditWindowXamlElement.AppendChild($subTypeElement)
$userEditWindowXamlElement.AppendChild($generatorElement)
$pageItemGroup.AppendChild($userEditWindowXamlElement)

# Добавляем UserReportsWindow.xaml
$userReportsWindowXamlElement = $project.CreateElement("Page", $project.Project.xmlns)
$userReportsWindowXamlElement.SetAttribute("Include", $UserReportsWindowXaml)
$subTypeElement = $project.CreateElement("SubType", $project.Project.xmlns)
$subTypeElement.InnerText = "Designer"
$generatorElement = $project.CreateElement("Generator", $project.Project.xmlns)
$generatorElement.InnerText = "MSBuild:Compile"
$userReportsWindowXamlElement.AppendChild($subTypeElement)
$userReportsWindowXamlElement.AppendChild($generatorElement)
$pageItemGroup.AppendChild($userReportsWindowXamlElement)

# Добавляем файлы CS как Compile
$compileItemGroup = $project.Project.ItemGroup | Where-Object { $_.Compile -ne $null } | Select-Object -First 1

# Добавляем UserEditWindow.xaml.cs
$userEditWindowCsElement = $project.CreateElement("Compile", $project.Project.xmlns)
$userEditWindowCsElement.SetAttribute("Include", $UserEditWindowCs)
$dependentUponElement = $project.CreateElement("DependentUpon", $project.Project.xmlns)
$dependentUponElement.InnerText = $UserEditWindowXaml
$userEditWindowCsElement.AppendChild($dependentUponElement)
$compileItemGroup.AppendChild($userEditWindowCsElement)

# Добавляем UserReportsWindow.xaml.cs
$userReportsWindowCsElement = $project.CreateElement("Compile", $project.Project.xmlns)
$userReportsWindowCsElement.SetAttribute("Include", $UserReportsWindowCs)
$dependentUponElement = $project.CreateElement("DependentUpon", $project.Project.xmlns)
$dependentUponElement.InnerText = $UserReportsWindowXaml
$userReportsWindowCsElement.AppendChild($dependentUponElement)
$compileItemGroup.AppendChild($userReportsWindowCsElement)

# Сохраняем проектный файл
$project.Save($projectFile)

Write-Host "Файлы успешно добавлены в проект!" 