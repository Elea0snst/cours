using System;
using System.Collections.ObjectModel;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Data.Entity;
using System.Diagnostics;

namespace online_courses
{
    public partial class SupportChatPage : Page, IPageRefresh
    {
        private user _currentUser;
        private ObservableCollection<ChatMessage> _messages = new ObservableCollection<ChatMessage>();
        private ObservableCollection<user> _chatUsers = new ObservableCollection<user>();
        private user _selectedChatUser;
        private int? _lastSelectedUserId;

        // Класс для хранения сообщений чата
        private class ChatMessage
        {
            public string SenderName { get; set; }
            public string Message { get; set; }
            public DateTime DateTime { get; set; }
            public bool IsOwn { get; set; }
            public string Role { get; set; }
        }

        public SupportChatPage(user user)
        {
            InitializeComponent();
            _currentUser = user;
            Debug.WriteLine($"SupportChatPage initialized for user: {user.users_login} (ID: {user.users_ID}, Role: {user.users_role_ID})");
            
            messagesListView.ItemsSource = _messages;
            
            if (_currentUser.users_role_ID == 5) // Support operator
            {
                LoadSupportUsers();
            }
            else // Regular user
            {
                LoadSupportOperator();
            }
            RefreshData();
        }

        private void LoadSupportUsers()
        {
            try
            {
                using (var context = Entities.GetContext())
                {
                    var users = context.users
                        .Where(u => u.users_role_ID != 5)
                        .ToList();
                    
                    Debug.WriteLine($"Found {users.Count} users for support operator");
                    
                    _chatUsers = new ObservableCollection<user>(users);
                    usersListBox.ItemsSource = _chatUsers;
                    usersListBox.SelectionChanged += UsersListBox_SelectionChanged;
                    
                    if (_chatUsers.Count > 0)
                    {
                        if (_lastSelectedUserId.HasValue)
                        {
                            var savedUser = _chatUsers.FirstOrDefault(u => u.users_ID == _lastSelectedUserId.Value);
                            if (savedUser != null)
                            {
                                usersListBox.SelectedItem = savedUser;
                                _selectedChatUser = savedUser;
                            }
                            else
                            {
                                usersListBox.SelectedIndex = 0;
                            }
                        }
                        else
                        {
                            usersListBox.SelectedIndex = 0;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"Error loading support users: {ex.Message}");
                MessageBox.Show("Ошибка при загрузке списка пользователей");
            }
        }

        private void LoadSupportOperator()
        {
            try
            {
                using (var context = Entities.GetContext())
                {
                    var supportOperator = context.users
                        .FirstOrDefault(u => u.users_role_ID == 5);
                    
                    if (supportOperator != null)
                    {
                        _selectedChatUser = supportOperator;
                        Debug.WriteLine($"Found support operator: {supportOperator.users_login}");
                    }
                    else
                    {
                        Debug.WriteLine("No support operator found");
                        MessageBox.Show("Нет доступного оператора поддержки");
                    }
                }
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"Error loading support operator: {ex.Message}");
                MessageBox.Show("Ошибка при загрузке оператора поддержки");
            }
        }

        private void UsersListBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            _selectedChatUser = usersListBox.SelectedItem as user;
            if (_selectedChatUser != null)
            {
                _lastSelectedUserId = _selectedChatUser.users_ID;
                Debug.WriteLine($"Selected chat user changed to: {_selectedChatUser.users_login} (ID: {_selectedChatUser.users_ID})");
            }
            RefreshData();
        }

        public void RefreshData()
        {
            try
            {
                using (var context = Entities.GetContext())
                {
                    bool isSupport = _currentUser.users_role_ID == 5;
                    int interlocutorId;

                    if (isSupport)
                    {
                        if (_selectedChatUser == null)
                        {
                            Debug.WriteLine("No user selected for support operator");
                            _messages.Clear();
                            return;
                        }
                        interlocutorId = _selectedChatUser.users_ID;
                    }
                    else
                    {
                        if (_selectedChatUser == null)
                        {
                            Debug.WriteLine("No support operator available");
                            _messages.Clear();
                            return;
                        }
                        interlocutorId = _selectedChatUser.users_ID;
                    }

                    Debug.WriteLine($"Loading messages between users {_currentUser.users_ID} and {interlocutorId}");

                    var chatMessages = context.chat_messages
                        .Include(m => m.user)
                        .Include(m => m.user1)
                        .Where(m => (m.users_ID == _currentUser.users_ID && m.support_ID == interlocutorId)
                                || (m.users_ID == interlocutorId && m.support_ID == _currentUser.users_ID))
                        .OrderBy(m => m.message_date)
                        .ToList();

                    Debug.WriteLine($"Found {chatMessages.Count} messages in chat");

                    _messages.Clear();
                    foreach (var message in chatMessages)
                    {
                        bool isOwn = message.users_ID == _currentUser.users_ID;
                        string senderName;
                        if (isSupport)
                        {
                            // Для support-оператора: имя отправителя по users_login
                            var sender = isOwn ? message.user : message.user1;
                            senderName = sender?.users_login ?? "Неизвестный";
                        }
                        else
                        {
                            // Для обычного пользователя: 'Вы' или логин support
                            senderName = isOwn ? "Вы" : _selectedChatUser.users_login;
                        }
                        var role = isOwn ? (context.roles.FirstOrDefault(r => r.role_ID == _currentUser.users_role_ID)?.role_name ?? "Пользователь")
                                         : (context.roles.FirstOrDefault(r => r.role_ID == _selectedChatUser.users_role_ID)?.role_name ?? "Пользователь");
                        Debug.WriteLine($"Message: {message.message_text} from {senderName} (IsOwn: {isOwn})");
                        _messages.Add(new ChatMessage
                        {
                            SenderName = senderName,
                            Message = message.message_text,
                            DateTime = message.message_date,
                            IsOwn = isOwn,
                            Role = role
                        });
                    }

                    if (_messages.Count > 0)
                    {
                        messagesListView.ScrollIntoView(_messages[_messages.Count - 1]);
                    }
                }
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"Error in RefreshData: {ex.Message}\n{ex.StackTrace}");
                MessageBox.Show($"Ошибка при загрузке сообщений: {ex.Message}");
            }
        }

        private void SendButton_Click(object sender, RoutedEventArgs e)
        {
            SendMessage();
        }

        private void MessageTextBox_KeyDown(object sender, KeyEventArgs e)
        {
            // Отправка сообщения по нажатию Ctrl+Enter
            if (e.Key == Key.Enter && Keyboard.Modifiers == ModifierKeys.Control)
            {
                SendMessage();
            }
        }

        private void SendMessage()
        {
            try
            {
                string messageText = messageTextBox.Text.Trim();
                if (string.IsNullOrEmpty(messageText))
                {
                    MessageBox.Show("Пожалуйста, введите текст сообщения.");
                    return;
                }

                using (var context = Entities.GetContext())
                {
                    bool isSupport = _currentUser.users_role_ID == 5;
                    int interlocutorId;

                    if (isSupport)
                    {
                        if (_selectedChatUser == null)
                        {
                            MessageBox.Show("Выберите пользователя для чата.");
                            return;
                        }
                        interlocutorId = _selectedChatUser.users_ID;
                    }
                    else
                    {
                        if (_selectedChatUser == null)
                        {
                            MessageBox.Show("Нет доступного оператора поддержки.");
                            return;
                        }
                        interlocutorId = _selectedChatUser.users_ID;
                    }

                    Debug.WriteLine($"Sending message from user {_currentUser.users_ID} to {interlocutorId}: {messageText}");

                    var chatMessage = new chat_messages
                    {
                        users_ID = _currentUser.users_ID,
                        support_ID = interlocutorId,
                        message_text = messageText,
                        message_date = DateTime.Now,
                        is_read = false
                    };

                    context.chat_messages.Add(chatMessage);
                    context.SaveChanges();
                    Debug.WriteLine("Message saved successfully");

                    messageTextBox.Text = string.Empty;
                    
                    RefreshData();
                }
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"Error in SendMessage: {ex.Message}\n{ex.StackTrace}");
                MessageBox.Show($"Ошибка при отправке сообщения: {ex.Message}");
            }
        }
    }
} 