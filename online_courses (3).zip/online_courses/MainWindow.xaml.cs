﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace online_courses
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            
            // Сбрасываем контекст базы данных, чтобы начать с чистого подключения
            Entities.ResetContext();
            
            // Перенаправляем на страницу входа
            MainFrame.Navigate(new LoginPage());
            
            // Запускаем миграцию данных в фоновом режиме после отображения UI
            RunDataMigration();
        }
        
        private async void RunDataMigration()
        {
            try
            {
                // Запускаем миграцию в отдельной задаче, чтобы не блокировать UI
                await Task.Run(() => {
                    // Ждем немного, чтобы приложение успело запуститься
                    System.Threading.Thread.Sleep(1000);
                    
                    // Запускаем миграцию в UI-потоке, так как она взаимодействует с UI
                    Application.Current.Dispatcher.Invoke(() => {
                        MigrationHelper.UpdateTestResults();
                    });
                });
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при запуске миграции данных: {ex.Message}");
            }
        }
    }
}
