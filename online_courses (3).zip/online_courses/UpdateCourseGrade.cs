using System;
using System.Linq;
using System.Windows;

namespace online_courses
{
    public static class OldCourseGradeHelper
    {
        public static void UpdateCourseGrade(user currentUser, cours course, double testScore)
        {
            try
            {
                // Для расчета оценки курса нам нужно:
                // 1. Получить все модули курса
                // 2. Для каждого модуля проверить, пройден ли тест
                // 3. Рассчитать среднюю оценку на основе пройденных тестов
                
                using (var context = new Entities())
                {
                    // Получаем все модули курса
                    var modules = context.modules
                        .Where(m => m.course_ID == course.course_ID)
                        .ToList();
                    
                    // Проверяем, есть ли модули
                    if (modules.Count == 0)
                    {
                        System.Diagnostics.Debug.WriteLine("Нет модулей для расчета оценки курса");
                        return;
                    }
                    
                    // Получаем все тесты и их результаты для данного курса и студента
                    int totalModules = modules.Count;
                    int completedModules = 0;
                    decimal totalScore = 0;
                    
                    foreach (var module in modules)
                    {
                        // Получаем тест для модуля
                        var test = context.tests
                            .FirstOrDefault(t => t.module_ID == module.module_ID);
                            
                        if (test != null)
                        {
                            // Получаем результат теста для студента
                            var testResult = context.test_results
                                .Where(tr => tr.test_ID.HasValue && tr.test_ID.Value == test.test_ID && tr.users_ID == currentUser.users_ID)
                                .OrderByDescending(tr => tr.result_date)
                                .FirstOrDefault();
                                
                            if (testResult != null && testResult.is_passed == true)
                            {
                                completedModules++;
                                
                                // Если есть балл, учитываем его
                                if (testResult.score.HasValue)
                                {
                                    totalScore += testResult.score.Value;
                                }
                            }
                        }
                    }
                    
                    // Рассчитываем прогресс и оценку
                    double progress = totalModules > 0 ? (double)completedModules / totalModules * 100 : 0;
                    
                    // Шкала от 0 до 5 (в зависимости от прогресса)
                    int grade = 0;
                    
                    // Оценка зависит от прогресса
                    if (progress > 0)
                    {
                        if (completedModules > 0)
                        {
                            // Средний балл по тестам (от 0 до 100)
                            decimal averageScore = totalScore / completedModules;
                            
                            // Преобразуем в оценку (от 1 до 5)
                            // < 60% - 2, 60-70% - 3, 70-85% - 4, >85% - 5
                            if (averageScore < 60) grade = 2;
                            else if (averageScore < 70) grade = 3;
                            else if (averageScore < 85) grade = 4;
                            else grade = 5;
                            
                            System.Diagnostics.Debug.WriteLine($"Средний балл: {averageScore:F1}, Оценка: {grade}");
                        }
                    }
                    
                    // Обновляем или создаем запись о прогрессе курса
                    var courseGrade = context.course_grades
                        .FirstOrDefault(cg => cg.users_ID == currentUser.users_ID && cg.course_ID == course.course_ID);
                        
                    if (courseGrade != null)
                    {
                        // Обновляем прогресс и оценку
                        courseGrade.grade = grade;
                        
                        System.Diagnostics.Debug.WriteLine($"Обновлен прогресс курса: ID={courseGrade.grade_ID}, Прогресс={progress:F1}%, Оценка={grade}");
                    }
                    else
                    {
                        // Создаем новую запись
                        courseGrade = new course_grades
                        {
                            users_ID = currentUser.users_ID,
                            course_ID = course.course_ID,
                            grade = grade,
                            grade_date = DateTime.Now
                        };
                        
                        context.course_grades.Add(courseGrade);
                        System.Diagnostics.Debug.WriteLine($"Создана запись о курсе: Прогресс={progress:F1}%, Оценка={grade}");
                    }
                    
                    // Сохраняем изменения
                    context.SaveChanges();
                    
                    System.Diagnostics.Debug.WriteLine($"Курс ID={course.course_ID}: Прогресс={progress:F1}% ({completedModules}/{totalModules}), Оценка={grade}");
                }
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine($"Ошибка при обновлении оценки курса: {ex.Message}\n{ex.StackTrace}");
                MessageBox.Show($"Ошибка при обновлении оценки курса: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }
    }
} 