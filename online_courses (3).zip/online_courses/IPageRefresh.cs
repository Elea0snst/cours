namespace online_courses
{
    /// <summary>
    /// Интерфейс для обновления данных на страницах
    /// </summary>
    public interface IPageRefresh
    {
        void RefreshData();
    }
} 