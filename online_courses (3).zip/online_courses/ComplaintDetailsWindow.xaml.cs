using System;
using System.Linq;
using System.Windows;

namespace online_courses
{
    public partial class ComplaintDetailsWindow : Window
    {
        private complaint _complaint;
        private user _complainant;
        private object _targetObject; // Может быть user или course_reviews в зависимости от типа жалобы

        public ComplaintDetailsWindow(complaint complaint)
        {
            InitializeComponent();
            _complaint = complaint;
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            LoadComplaintDetails();
        }

        private void LoadComplaintDetails()
        {
            try
            {
                // Загружаем данные о заявителе
                _complainant = Entities.GetContext().users.FirstOrDefault(u => u.users_ID == _complaint.users_ID);
                
                // Заполняем поля интерфейса
                complaintIdTextBlock.Text = $"Жалоба №{_complaint.complaint_ID}";
                complaintTypeTextBlock.Text = GetComplaintTypeText(_complaint.complaint_type);
                complaintDateTextBlock.Text = $"Дата подачи: {_complaint.complaint_date:dd.MM.yyyy HH:mm}";
                complaintTextTextBlock.Text = _complaint.complaint_text;
                
                // Информация о заявителе
                if (_complainant != null)
                {
                    complainantTextBlock.Text = $"Заявитель: {_complainant.users_login}";
                }
                else
                {
                    complainantTextBlock.Text = "Заявитель: Не определен";
                }

                // Информация о цели жалобы (используем target_ID вместо target_id)
                LoadTargetInfo(_complaint.complaint_type, _complaint.target_ID);
                
                // Настраиваем доступность кнопок
                UpdateButtonsState();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при загрузке данных жалобы: {ex.Message}");
            }
        }

        private string GetComplaintTypeText(string type)
        {
            switch (type)
            {
                case "user": return "Жалоба на пользователя";
                case "review": return "Жалоба на отзыв";
                case "course": return "Жалоба на курс";
                default: return $"Жалоба (тип: {type})";
            }
        }

        private void LoadTargetInfo(string type, int targetId)
        {
            try
            {
                switch (type)
                {
                    case "user":
                        var targetUser = Entities.GetContext().users.FirstOrDefault(u => u.users_ID == targetId);
                        if (targetUser != null)
                        {
                            _targetObject = targetUser;
                            targetTextBlock.Text = $"Пользователь: {targetUser.users_login}"; // Упрощаем, так как у user нет свойств first_name и last_name
                        }
                        else
                        {
                            targetTextBlock.Text = "Пользователь не найден";
                        }
                        break;
                        
                    case "review":
                        var targetReview = Entities.GetContext().course_reviews.FirstOrDefault(r => r.review_ID == targetId);
                        if (targetReview != null)
                        {
                            _targetObject = targetReview;
                            var reviewAuthor = Entities.GetContext().users.FirstOrDefault(u => u.users_ID == targetReview.users_ID); // Используем users_ID вместо user_ID
                            var course = Entities.GetContext().courses.FirstOrDefault(c => c.course_ID == targetReview.course_ID);
                            
                            targetTextBlock.Text = $"Отзыв к курсу '{course?.course_name ?? "Неизвестный курс"}' " +
                                                  $"от пользователя {reviewAuthor?.users_login ?? "Неизвестный пользователь"}";
                        }
                        else
                        {
                            targetTextBlock.Text = "Отзыв не найден";
                        }
                        break;
                        
                    case "course":
                        var targetCourse = Entities.GetContext().courses.FirstOrDefault(c => c.course_ID == targetId);
                        if (targetCourse != null)
                        {
                            _targetObject = targetCourse;
                            targetTextBlock.Text = $"Курс: {targetCourse.course_name}";
                        }
                        else
                        {
                            targetTextBlock.Text = "Курс не найден";
                        }
                        break;
                        
                    default:
                        targetTextBlock.Text = $"Объект с ID {targetId}";
                        break;
                }
            }
            catch (Exception ex)
            {
                targetTextBlock.Text = $"Ошибка при загрузке данных объекта: {ex.Message}";
            }
        }

        private void UpdateButtonsState()
        {
            // Кнопки одобрения/отклонения доступны только для жалоб в статусе "На рассмотрении"
            bool isPending = _complaint.status == "На рассмотрении";
            
            approveButton.IsEnabled = isPending;
            rejectButton.IsEnabled = isPending;
        }

        private void ApproveButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                // Обновляем статус жалобы
                _complaint.status = "Одобрена";
                
                // Выполняем действия в зависимости от типа жалобы
                if (_complaint.complaint_type == "review" && _targetObject is course_reviews review)
                {
                    // Удаляем отзыв
                    Entities.GetContext().course_reviews.Remove(review);
                    MessageBox.Show("Жалоба одобрена. Отзыв будет удален.", "Одобрение жалобы", MessageBoxButton.OK, MessageBoxImage.Information);
                }
                else if (_complaint.complaint_type == "user" && _targetObject is user targetUser)
                {
                    // В модели user нет свойства is_blocked, показываем информационное сообщение
                    MessageBox.Show("Жалоба одобрена. В модели пользователя нет свойства is_blocked, " +
                                   "необходимо реализовать функционал блокировки.", 
                                   "Одобрение жалобы", MessageBoxButton.OK, MessageBoxImage.Information);
                }
                else
                {
                    MessageBox.Show("Жалоба одобрена.", "Одобрение жалобы", MessageBoxButton.OK, MessageBoxImage.Information);
                }
                
                // Сохраняем изменения
                Entities.GetContext().SaveChanges();
                
                // Обновляем интерфейс
                UpdateButtonsState();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при обработке жалобы: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void RejectButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                // Обновляем статус жалобы
                _complaint.status = "Отклонена";
                
                // Сохраняем изменения
                Entities.GetContext().SaveChanges();
                
                MessageBox.Show("Жалоба отклонена.", "Отклонение жалобы", MessageBoxButton.OK, MessageBoxImage.Information);
                
                // Обновляем интерфейс
                UpdateButtonsState();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при обработке жалобы: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void CloseButton_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }
    }
} 