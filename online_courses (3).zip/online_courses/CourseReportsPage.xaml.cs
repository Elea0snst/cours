using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using Microsoft.Win32;
using System.IO;

namespace online_courses
{
    public partial class CourseReportsPage : Page
    {
        private readonly user _currentUser;
        private readonly cours _course;

        private class StudentProgress
        {
            public string StudentName { get; set; }
            public double Progress { get; set; }
            public string ProgressText { get; set; }
            public int Grade { get; set; }
            public string LastActivity { get; set; }
        }

        public CourseReportsPage(user currentUser, cours course)
        {
            InitializeComponent();
            _currentUser = currentUser ?? throw new ArgumentNullException(nameof(currentUser));
            _course = course ?? throw new ArgumentNullException(nameof(course));
            LoadData();
        }

        private void LoadData()
        {
            try
            {
                using (var context = new Entities())
                {
                    // Устанавливаем название курса
                    courseNameTextBlock.Text = _course.course_name;

                    // Получаем всех студентов курса
                    var courseGrades = context.course_grades
                        .Where(cg => cg.course_ID == _course.course_ID)
                        .ToList();

                    // Общая статистика
                    totalStudentsTextBlock.Text = courseGrades.Count.ToString();

                    var averageRating = context.course_reviews
                        .Where(r => r.course_ID == _course.course_ID)
                        .Select(r => (double?)r.rating)
                        .DefaultIfEmpty()
                        .Average() ?? 0.0;
                    averageRatingTextBlock.Text = averageRating.ToString("F1");

                    var averageGrade = courseGrades.Any() 
                        ? courseGrades.Average(cg => cg.grade) 
                        : 0;
                    averageGradeTextBlock.Text = averageGrade.ToString("F1");

                    // Получаем прогресс каждого студента
                    var studentProgress = new List<StudentProgress>();
                    var helper = new CourseGradeHelper(context);

                    foreach (var grade in courseGrades)
                    {
                        var student = context.users.FirstOrDefault(u => u.users_ID == grade.users_ID);
                        if (student == null) continue;

                        var progressInfo = helper.CalculateCourseProgress(_course.course_ID, student.users_ID);

                        // Получаем дату последней активности
                        var lastActivity = context.test_results
                            .Where(tr => tr.users_ID == student.users_ID &&
                                       tr.test.module.course_ID == _course.course_ID)
                            .OrderByDescending(tr => tr.result_date)
                            .Select(tr => tr.result_date)
                            .FirstOrDefault();

                        studentProgress.Add(new StudentProgress
                        {
                            StudentName = student.users_login,
                            Progress = progressInfo.ProgressPercentage,
                            ProgressText = $"{progressInfo.ProgressPercentage:F1}%",
                            Grade = (int)grade.grade,
                            LastActivity = lastActivity?.ToString("dd.MM.yyyy HH:mm") ?? "Нет активности"
                        });
                    }

                    studentsListView.ItemsSource = studentProgress.OrderByDescending(sp => sp.Progress);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при загрузке данных: {ex.Message}\n\nStackTrace: {ex.StackTrace}");
            }
        }

        private void ExportToExcelButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                var saveDialog = new SaveFileDialog
                {
                    Filter = "Excel файлы (*.xlsx)|*.xlsx",
                    FileName = $"Отчет_{_course.course_name}_{DateTime.Now:yyyy-MM-dd}"
                };

                if (saveDialog.ShowDialog() == true)
                {
                    // Здесь будет код для экспорта в Excel
                    // Можно использовать библиотеку EPPlus или другую для работы с Excel
                    MessageBox.Show("Экспорт в Excel будет добавлен в следующем обновлении");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при экспорте данных: {ex.Message}");
            }
        }

        private void CloseButton_Click(object sender, RoutedEventArgs e)
        {
            if (NavigationService.CanGoBack)
            {
                NavigationService.GoBack();
            }
        }
    }
} 